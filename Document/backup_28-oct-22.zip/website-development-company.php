 <?php include('header.php'); ?>

<!--#include file="header.shtml"-->

          <div class="no-touch m-nav-menusocial">

            <div id="menusocial" class="menu--social1">

              <div class="toggle--social">

                <span class="soundspeaker-icon">

                </span>

              </div>

              <ul class="menu--sub">

                <li class="menu__item--facebook"> 

                  <a target="_blank" itemprop="samAs" class="menu-link sub-menu-link social_event_track_cls" data-title="Facebook" href="#">

                    <i>

                    </i>HB on Facebook

                  </a> 

                </li>

                <li class="menu__item--twitter"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Twitter" href="#">

                    <i>

                    </i> HB on Twitter 

                  </a> 

                </li>

                <li class="menu__item--linkdin"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="LinkedIn" href="#">

                    <i>

                    </i>HB on Linkedin

                  </a> 

                </li>

                <li class="menu__item--google-p"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Google Plus" href="#">

                    <i>

                    </i>HB on Google+

                  </a> 

                </li>

                <li class="menu__item--youtube"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="You Tube" href="#">

                    <i>

                    </i>HB on Youtube

                  </a> 

                </li>

                <li class="menu__item--blog"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Blog" href="#">

                    <i>

                    </i>HB on Blog

                  </a> 

                </li>

              </ul>

            </div>

          </div>

        </div>

        <div id="top-container" style="display:none;">

          <div class="centerdiv">

            <div class="left"> 

              <a href="#" title=""> 

                <img src="images/logo.png" width="261" height="51" alt="" class="logo" /> 

              </a> 

            </div>

            <div class="right" style="width:72%;">

              <div class="r-clear menu-display">

                <div class="search-div">

                  <input type="search" placeholder="Search" name="" />

                </div>

                <span class="link-area">

                  <a target="_blank" title="" href="#">Blog

                  </a>

                  <a title="" href="#" target="_blank">Articles

                  </a>

                  <a title="" href="#">FAQ

                  </a>

                  <a title="" href="#">Careers

                  </a> 

                  <a title="Contact" href="#">Contact

                  </a> 

                  <a title="" href="#">Partnership

                  </a>

                </span> 

              </div>

              <div class="r-clear topmenu">

                <div class="mobile-tablet-menu">

                  <a href="#" class="mobile-menu-home-iclass" id="mobile-menu-home-icon">

                  </a>

                  <div class="mobile-menu-home-contner" id="mobile-menu-home">

                    <ul>

                      <li>

                        <a title="Company" href="#">Company

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Services

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Technology

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Products

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Client

                        </a>

                      </li>

                      <li>

                        <a title="Work" class="work-menu" href="#">Work

                        </a>

                      </li>

                      <li>

                        <a title="Inquiry" href="#" id="inquiry-pop-up" class="active">Get Quote

                        </a>

                      </li>

                    </ul>

                  </div>

                </div>

                <ul class="menu-t-menu-new">

                  <li>

                    <a title="startdesigns InfoTech" href="#">

                      <span class="home">

                      </span>

                    </a> 

                  </li>

                  <li>

                    <a title="Company" href="#">Company

                    </a> 

                  </li>

                  <li>

                    <a title="Services" href="#">Services

                    </a> 

                  </li>

                  <li>

                    <a title="Technology" href="#">Technology

                    </a> 

                  </li>

                  <li>

                    <a href="#">Products

                    </a> 

                  </li>

                  <li>

                    <a title="Work" href="#">Work

                    </a> 

                  </li>

                  <li>

                    <a title="Inquiry" href="#">Get Quote

                    </a> 

                  </li>

                </ul>

              </div>

            </div>

          </div>

        </div>

      </div>

    </header>



    <!-- Banner top- contact end -->



    <section class="service-topbanner webdevelopbannerbg">      

      <div class="container">

          <div class="row service-flex">

              <div class="col-md-6">

                <div class="mainservicetopbanner">

                  <h3>A Certified Website Development Company</h3>

                  <h1 class="wordpress_head">Website Development Company</h1>

                  <p>Start Designs is an emerging web development company. We providing services for web design and development at an 

                    affordable cost. We have an in-house team of experienced and professional web developers that build your business online using 

                    newly coming technologies.</p>

                  <div class="dflex">

                    <a href="#foooter_form" class="btn btn-contactsupport">Contact Support →</a>

                    <a href="#" class="btn btn-startproject" id="projectmodel" data-toggle="modal" data-target="#startproject">Start Project →</a>

                  </div>                  

                </div>

              </div>

              <div class="col-md-6">

                <div class="rightside-topbanner wpbanner-top">

                  <img src="images/webb-develop.png" alt="banner-img">

                </div>

              </div>

          </div>

      </div>     

    </section>





        <!-- About web development  start -->

    <section class="about-reactjs web3-page webdevelop-page">

      <div class="container">

        <div class="title">            

          <h2>Custom Web Development Agency in          

            <a href="" class="typewrite" data-period="2000" data-type='[  "USA | UK | India " ]'> 

            </a>

          </h2>

        </div>

        <div class="row row-waffer">           



          <div class="col-md-6 web3-contents">     

          <h3>One Palace for Complete Web Development Solutions</h3>       

            <p class="para">As a reputed website development agency we are providing solutions that empower your business globally and help to reach your business goals. Our team of dedicated web developers has the experience of working for Real Estate, Fashion, Hospitality, Education, E-Commerce, 

            Auto Mobile, and Finance industry.We successfully delivered the 1200 +projects weather it is of e-commerce web development or custom 

            website development for any other industry to more than 700 clients globally. Our team efficiently works with all clients from USA, UK, France,

            Germany, Canada, India and many other countries.We also have experience as a <a href="https://www.startdesigns.com/mobile-app-development-agency.php" class="inpage_link">mobile app development agency </a> that builds mobile fully

            responsive and functionality applications. We have skilled mobile app developers for both android app development & iPhone app development.</p>    </div>



          <div class="col-md-6">           

            <div class="img_outer">

                <div class="reactleftimages">

                  <img src="images/webdevlopmentpic.png" class="responsive web-smal floating imgw-90" alt="image">

                </div>

              </div>

          </div>

    </section>

    <!-- About web development ends -->



    <!-- web design  services Offer -->

<section class="webflowfeatures_services web3-page bg-gray-white webdevelop-page">

  <div class="container">

    <div class="title">   

      <h3>We are providing every web development service that your business needs.</h3>   

      <h2>We Offer Website

        <a href="" class="typewrite" data-period="2000" data-type='[  "Development Services" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row weoffer-row1">

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/custom-c-development.png"></div>              

            </div>

            <h4>Custom Website Development</h4>

            <span class="sub-head">We are offering custom website design and development services that give your business a new identity on the web. Our skillful web designer and developers are highly professional to build your business website.

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/module.png"></div>             

            </div>

             <h4>WordPress Development</h4>

            <span class="sub-head">WordPress is the most used open-source CMS that gives you the feature of customizing web development. Wordpress has a wide scope of usability as Blog, Magazine, E-Commerce Website, etc. You can <a href="https://www.startdesigns.com/hire-wordpress-developer.php" class="inpage_link">hire dedicated WordPress developer </a> on a flexible time module.

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/online-shopping21.png "></div>             

            </div>

            <h4>eCommerce Web Development</h4>

            <span class="sub-head">Our eCommerce web developers can create B2B and B2C websites very proficiently. We have the expertise that builds fully responsive eCommerce websites for all platforms like mobile, tablets, desktops, and laptops. You can hire eCommerce developers on an hourly, daily, weekly basis.

            </span>

          </div>

        </div>

      </div>     



    </div>

      <div class="row weoffer-row2">

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/cmss.png"></div>              

            </div>

            <h4>CMS or SaaS Development</h4>

            <span class="sub-head">If you need a customized CMS or SaaS according to your business requirements. Then our web developers can build CMS & SaaS as per your need. Our web programmers use technologies like PHP, JAVA, ASP.NET, and Python. 

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/mobile-app.png"></div>             

            </div>

             <h4>Web App Development</h4>

            <span class="sub-head">Our web application developers are capable of build apps on the web to empower your business. Our team has the experience of creating a web application for eCommerce, travel, social media, and real estate industries. Hire our web application developers on an hourly basis. 

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

           <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/erp.png"></div>              

            </div>

            <h4>ERP Development</h4>

            <span class="sub-head">We develop ERP software for different industries. Our web programmers build Enterprise Resource Planning(ERP) system that helps you to manage business planning, inventory, human resource management, and finance management. We have experienced team of web programmers to hire at an affordable cost. 

            </span>

          </div>

        </div>

      </div>      

    </div>



  </div>

</section>

<!-- web design services Offer--->



<!-- --------Features of web--------- -->

<section class="webflow-platform expertise-section ecome-page webdev-page" >

      <div class="container">

        <div class="row">

          <div class="title">

            <h2>Feature Of Web Development  

              <a href="" class="typewrite" data-period="2000" data-type='[  "We Have " ]'> 

              </a>

            </h2>            

          </div>

          <div class="alignitemcenter">



                      <div class="col-md-6">

                <div class="mainservicetopbanner">                  

                  <!-- <h2>PHP Environments & Libraries</h2> -->                 

                  

                <div class="expertise-list">

                <div>

                   <div class="advantage-icon">

                    <img src="images/contentt.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                     <p class="advantage-text-head">Web Compatibility</p>

                     <p class="advantage-text-data">Web development we do is compatible with any web browser, devices, and platform. We create a responsive web application, websites, and software that are user-friendly. These features improve your rank on search engines.</p>

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <img src="images/delivery-time.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                    <p class="advantage-text-head">Fast Loading Speed</p>

                     <p class="advantage-text-data">We develop websites and application with enabling the feature of fast loading time that engage more users. Our codes are bug-free and light to give a fast loading speed online at any browser.</p>

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <img src="images/easy-to-use.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                    <p class="advantage-text-head">Easy Navigation</p>

                     <p class="advantage-text-data">Almost 94% of users think that good navigation is a key feature of the website. We build a website with easy to use navigation feature that improves user experience and usability of the site.</p>

                  </div>

                </div>              

                

                  </div>

                </div>

          </div>



          <div class="col-md-6">

            <div class="mainservicetopbanner">                  

                  <!-- <h2>PHP Environments & Libraries</h2> -->                 

                  

                <div class="expertise-list">

                <div>

                   <div class="advantage-icon">

                    <img src="images/check-form.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                     <p class="advantage-text-head">Usable Forms</p>

                     <p class="advantage-text-data">Forms are the most appropriate way to interact with the site by users. We add forms that are easy to fill for customers and get useful information to build your client base. Thus you can make further contact with interested users.</p>

                  </div>

                </div>

                  <div>

                   <div class="advantage-icon">

                    <img src="images/web-c-plugin.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                    <p class="advantage-text-head">Blog Integration</p>

                     <p class="advantage-text-data">We integrate a blog that can help your customers to learn about your services and products. It also helps in search engine optimization of websites or apps.</p>

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <img src="images/seocc.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                    <p class="advantage-text-head">Product and Content Visuality</p>

                     <p class="advantage-text-data">Our web developers and programmers build websites that improve the visibility of products and their data that boost the sale of products or services. On the other hand, it helps to generate more revenue. Also improve the conversion rate.</p>

                  </div>

                </div>              

                

                  </div>

                </div>

              </div>

        </div>

        </div>

      </div>

    </section>

<!-- end-->



<!-- Recent work -->

<section class="recentwork-section cmi-recent">

  <div class="container">

    <div class="title">

      <h5>Some of our work that impacts clients' business</h5>

      <h2>Website Development

        <a href="" class="typewrite" data-period="2000" data-type='[  "Recent Works" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row recentworkRow">

      <div class="col-md-3 col-sm-6">

        <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/woollytravellers-wordpress.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Woolly Travellers</h4>

                  <span class="sub-head">New Zealand based wool shearing website design and develop in WordPress.                                    

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

        <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/carresol-parquet-prestashop.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Carresol Parquet</h4>

                  <span class="sub-head">France based residential interior business E-commerce PrestaShop store design and development.

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

       <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/allcampussecurity-wordpress.png" class="responsive">

            <div class="recentworkContent">

                  <h4>All Campus Security</h4>

                  <span class="sub-head">US based security solution business website design and development.                                    

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

        <a href="#" class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/ajhome-prestashop.png" class="responsive">

            <div class="recentworkContent">

                  <h4>AJ Homes</h4>

                  <span class="sub-head">France based brand for lawn accessories store design and development on Prestashop.

                  </span>

            </div>

          </div>

        </a>

      </div>

    </div>

  </div>

</section>

<!-- Recent work end-->



<!-- ----------web development technology------ -->

     <section class="use-technological ">

      <div class="container">

        <div class="title">

          <h2>Web Development Technologies   

            <a href="" class="typewrite" data-period="2000" data-type='[  "We Are Expert In" ]'> 

            </a>

          </h2>          

        </div> 

        <div class="technological-box">

          <a href="#" class="spc-bt-30">

            <div class="technological_img_box">

              <img src="images/magento-icon1.png">

            </div>

          </a>

          <a href="#" class="spc-bt-30">

            <div class="technological_img_box">

              <img src="images/shopify-icon1.png">

            </div>            

          </a>

          <a href="#" class="spc-bt-30">

            <div class="technological_img_box">

              <img src="images/woo-icon1.png">

            </div>            

          </a>

          <a href="#" class="spc-bt-30">

            <div class="technological_img_box">

              <img src="images/open-icon1.png">

            </div>            

          </a>

          <a href="#" class="spc-bt-15-md">

            <div class="technological_img_box">

              <img src="images/wordpress-icon1.png">

            </div>            

          </a>

          <a href="#" class="spc-bt-15-md">

            <div class="technological_img_box">

              <img src="images/node-icon1.png">

            </div>            

          </a>

          <a href="#" class="spc-bt-15-md">

            <div class="technological_img_box">

              <img src="images/php-icon1.png">

            </div>            

          </a>

          <a href="#" class="spc-bt-15-md">

            <div class="technological_img_box">

              <img src="images/drupal-icon1.png">

            </div>            

          </a>

        </div>

      </div>

    </section>

    <!-- -----end------ -->



 <!-- why choose start -->

    <section class="advantages-hiring webdevelop-page bg-gray-white">

      <div class="container">

        <div class="title">

          <h2>Why Choose Our 

            <a href="" class="typewrite" data-period="2000" data-type='[  "Web Development Services?" ]'> 

            </a>

          </h2>

        </div>

        <div class="row">          

          <div class="col-md-6">

            <div class="develop_robust_content"> 

                <p>

                    Our app and web development company offers a fully-comprehensive set of IT services through the well-sophisticated knowledge we’ve gathered in all these years. Start Designs has employed the expert in WordPress, Magento, Joomla, CMS, CodeIgniter, CakePHP, DJANGO, PHP, MongoDB, Laravel, Yii, and Website Designing to provide you with best services in this domain. To enhance your business prospects, you can take the virtual support from Start Designs.

                </p>

                <p>

                  Becoming a part of your team, we contribute our 100% for the successful delivery of your projects. We change our work schedule as per your convenience. Start Designs understand your needs and thus, provides right solution and resources.

                  From product-based start-ups to enterprise-grade organizations and the service providers working in the same domain as ours, hire dedicated developers or development teams for all your needs.

                </p>

          </div>

            <div class="advantages-hiring-list">

                <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check-circle" aria-hidden="true">

                    </i>

                  </div>

                  <div class="advantage-text">

                     Highly experienced professionals.

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check-circle" aria-hidden="true">

                    </i>

                  </div>

                  <div class="advantage-text">

                    Non disclosure agreement.

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check-circle" aria-hidden="true">

                    </i>

                  </div>

                  <div class="advantage-text">

                    Varied industry experience.

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check-circle" aria-hidden="true">

                    </i>

                  </div>

                  <div class="advantage-text">

                    Supreme communication.

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check-circle" aria-hidden="true">

                    </i>

                  </div>

                  <div class="advantage-text">

                    Bug free Coding.

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check-circle" aria-hidden="true">

                    </i>

                  </div>

                  <div class="advantage-text">

                    24*7 technical support.

                  </div>

                </div>

            </div>

          </div>



          <div class="col-md-6">

              <div class="advantages-hiring-img">

                <img src="images/hire_dedicate2.png" class="floating responsive imgw-90">

              </div>

          </div>



        </div>

      </div>

    </section>    

    <!-- why choose ends -->



    <!-- hire start -->

    <section class="about-reactjs web3-benefit ecome-page webdev-page">

      <div class="container">



        <div class="row row-waffer">  

          <div class="col-md-6">

              <div class="img_outer">

                <div class="reactleftimages">

                  <img src="images/webb-developpment.png" class="responsive web-smal floating" alt="image">

                </div>

              </div>                

          </div>        

          <div class="col-md-6 web3-contents">    

          <h2>Hire <span class="web-theme-color">Web Developer</span></h2>           

            <p class="para">Hire experienced web developer on hourly, weekly or full time basis at Start designs. We offer best web development solutions using laravel, ruby on rails, java, etc. To convert your ideas in reality in the digital space, we give you the best services. We offer 24*7 support and cost efficient web solutions.              

            </p>



            <div class="dflex">

                <a href="#" class="btn btn-contactsupport" id="projectmodel" data-toggle="modal" data-target="#startproject">Start Project →</a>

            </div>                                   

          </div>

          

        </div>

      </div>

    </section>

    <!-- hire start -->



 

<!-- Expert review  testimony-serve-->

  <section class="section-testimonials reveiw_slide bg-gray-white">

      <div class="container">

        <div class="row">

          <div class="title">

            <h3>Testimony from our happy clients</h3>

            <h2>What do client say about 

              <a href="" class="typewrite" data-period="2000" data-type='[  "Website Development" ]'> 

              </a>

            </h2>

          </div>

        </div>

       

        <div id="review-slider" class="owl-carousel">

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn21.png" alt="">

                  <div class="user-details-services">

                    <h4>Brain tracy</h4>

                    <p>AJ Homes</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "Start designs produced a great solution to a very complicated development problems in a very cost-effective manner."

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn14.png" alt="">

                  <div class="user-details-services">

                    <h4>Cloris G</h4>

                    <p>All Campus Security</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "I was amazed at the quality of Website Development services. Definitely worth the investment. We were treated like royalty. "

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn11.png" alt="">

                  <div class="user-details-services">

                    <h4>Myranda A</h4>

                    <p>Carresol Parquet</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "StartDesigns is worth much more than I paid. Not able to tell you how happy I am with Website Development services by StartDesigns.  "

                </p>

              </div>

            </div>

          </div>

        </div>        



      </div>

    </section>

<!-- Expert review end -->





<!--#include file="footer.shtml"-->

    <a href="javascript:" id="return-to-top">

      <i class="fa fa-angle-double-up  " aria-hidden="true">

      </i>

    </a>



<?php include('footer.php'); ?>



<script type="text/javascript" src="js/jquery.js">

</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js">

</script>

<script src="js/jquery.countup.js">

</script>

<script>

$('.counter').countUp();

</script>

<!-- <script src="js/bootstrap.min.js">

</script> -->

<script src="js/owl.carousel.min.js" defer>

</script>

<script src="js/script.js">

</script>

<script src="js/jquery-1.11.1.min.js">

</script>

<script src="js/jquery.validate.min.js">

</script>

<script src="js/additional-methods.min.js">

</script>

<script src="js/slick.min.js" defer>

</script>









<!-- ----------testimony slider------- -->

<script>

$(document).ready(function(){

    $('#review-slider').owlCarousel({

  loop: true,

  margin: 10,

  nav: false,  

  autoplay: true,

  autoplayHoverPause: true,

  responsive: {

    0: {

      items: 1

    },

    767: {

      items: 1

    },

    1000: {

      items: 1

    }

  }

})

  })

</script>



<script>

  $(document).ready(function(){

    $('#whychoose-slider').owlCarousel({

  loop: true,

  margin: 10,

  nav: false,  

  autoplay: true,

  autoplayHoverPause: true,

  responsive: {

    0: {

      items: 1

    },

    767: {

      items: 2

    },

    1000: {

      items: 4

    }

  }

})

  })

</script>



</body>

</html>

