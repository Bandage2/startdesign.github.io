<?php
//reCAPTCHA Configuration - go to Google and get the below keys http://www.google.com/recaptcha/admin
define('SITE_KEY',"6LdtlZEeAAAAAMUj8vYn8xC60mu-ftYTgUhcwS38"); 
define('SECRET_KEY',"6LdtlZEeAAAAAM6elf4_DUVNPiO9M9-BbMee2qF0");

?>