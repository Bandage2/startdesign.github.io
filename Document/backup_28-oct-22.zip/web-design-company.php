 <?php include('header.php'); ?>

<!--#include file="header.shtml"-->

          <div class="no-touch m-nav-menusocial">

            <div id="menusocial" class="menu--social1">

              <div class="toggle--social">

                <span class="soundspeaker-icon">

                </span>

              </div>

              <ul class="menu--sub">

                <li class="menu__item--facebook"> 

                  <a target="_blank" itemprop="samAs" class="menu-link sub-menu-link social_event_track_cls" data-title="Facebook" href="#">

                    <i>

                    </i>HB on Facebook

                  </a> 

                </li>

                <li class="menu__item--twitter"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Twitter" href="#">

                    <i>

                    </i> HB on Twitter 

                  </a> 

                </li>

                <li class="menu__item--linkdin"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="LinkedIn" href="#">

                    <i>

                    </i>HB on Linkedin

                  </a> 

                </li>

                <li class="menu__item--google-p"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Google Plus" href="#">

                    <i>

                    </i>HB on Google+

                  </a> 

                </li>

                <li class="menu__item--youtube"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="You Tube" href="#">

                    <i>

                    </i>HB on Youtube

                  </a> 

                </li>

                <li class="menu__item--blog"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Blog" href="#">

                    <i>

                    </i>HB on Blog

                  </a> 

                </li>

              </ul>

            </div>

          </div>

        </div>

        <div id="top-container" style="display:none;">

          <div class="centerdiv">

            <div class="left"> 

              <a href="#" title=""> 

                <img src="images/logo.png" width="261" height="51" alt="" class="logo" /> 

              </a> 

            </div>

            <div class="right" style="width:72%;">

              <div class="r-clear menu-display">

                <div class="search-div">

                  <input type="search" placeholder="Search" name="" />

                </div>

                <span class="link-area">

                  <a target="_blank" title="" href="#">Blog

                  </a>

                  <a title="" href="#" target="_blank">Articles

                  </a>

                  <a title="" href="#">FAQ

                  </a>

                  <a title="" href="#">Careers

                  </a> 

                  <a title="Contact" href="#">Contact

                  </a> 

                  <a title="" href="#">Partnership

                  </a>

                </span> 

              </div>

              <div class="r-clear topmenu">

                <div class="mobile-tablet-menu">

                  <a href="#" class="mobile-menu-home-iclass" id="mobile-menu-home-icon">

                  </a>

                  <div class="mobile-menu-home-contner" id="mobile-menu-home">

                    <ul>

                      <li>

                        <a title="Company" href="#">Company

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Services

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Technology

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Products

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Client

                        </a>

                      </li>

                      <li>

                        <a title="Work" class="work-menu" href="#">Work

                        </a>

                      </li>

                      <li>

                        <a title="Inquiry" href="#" id="inquiry-pop-up" class="active">Get Quote

                        </a>

                      </li>

                    </ul>

                  </div>

                </div>

                <ul class="menu-t-menu-new">

                  <li>

                    <a title="startdesigns InfoTech" href="#">

                      <span class="home">

                      </span>

                    </a> 

                  </li>

                  <li>

                    <a title="Company" href="#">Company

                    </a> 

                  </li>

                  <li>

                    <a title="Services" href="#">Services

                    </a> 

                  </li>

                  <li>

                    <a title="Technology" href="#">Technology

                    </a> 

                  </li>

                  <li>

                    <a href="#">Products

                    </a> 

                  </li>

                  <li>

                    <a title="Work" href="#">Work

                    </a> 

                  </li>

                  <li>

                    <a title="Inquiry" href="#">Get Quote

                    </a> 

                  </li>

                </ul>

              </div>

            </div>

          </div>

        </div>

      </div>

    </header>



    <!-- Banner top- contact end -->



    <section class="service-topbanner webdbannerbg">      

      <div class="container">

          <div class="row service-flex">

              <div class="col-md-6">

                <div class="mainservicetopbanner">

                  <h3>Web Design Company</h3>

                  <h1 class="wordpress_head">Website Design and Development Company</h1>

                  <p>StartDesigns gives inventive web design services that convey your business more effectively online to visitors for the first time. We have an in-house team of web designers with 10+ years of experience with a 95% success rate in all industries. Start Designs giving creative and responsive website design solutions that enhance the user experience from every platform to convert your potential customers in your client.</p>

                  <div class="dflex">

                    <a href="#foooter_form" class="btn btn-contactsupport">Contact Support →</a>

                    <a href="#" class="btn btn-startproject" id="projectmodel" data-toggle="modal" data-target="#startproject">Start Project →</a>

                  </div>                  

                </div>

              </div>

              <div class="col-md-6">

                <div class="rightside-topbanner wpbanner-top">

                  <img src="images/webb-designn-bennr.png" alt="banner-img">

                </div>

              </div>

          </div>

      </div>

      <!-- </div> -->

    </section>





        <!-- About web design  start -->

    <section class="about-reactjs web3-page webd-page">

      <div class="container">

 

        <div class="row row-waffer">          

          <div class="col-md-6 web3-contents">     

          <h2>Awarded <span class="web-theme-color">Website Design Company</span></h2>       

            <p class="para">We craft what you think, one of our USP is designing web pages to present your business in an enchanting way on the web. We are serving for the last 5 years in the USA, UK, and India with our skilled and highly professional web designers. By innovative design solutions, we increase not only our expertise but also become a family of 150+ delighted customers globally.</p> 



            <p class="para">You can hire our web designers on different hiring modules. Our hiring modules are hourly, weakly, monthly, and project basis. It allows you the freedom to choose according to your requirements and project need. So, choose us as your web solution partner today.</p>                                   

          </div>



          <div class="col-md-6">            

          </div>          

        </div>



      </div>

    </section>

    <!-- About web design  ends -->



    <!-- web design  services Offer -->

<section class="webflowfeatures_services web3-page bg-gray-white webd-page">

  <div class="container">

    <div class="title">   

      <h3>We are providing hassle-free web design services that your business needs.</h3>   

      <h2>We Offer Website

        <a href="" class="typewrite" data-period="2000" data-type='[  "Design Services" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row weoffer-row1">

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/module.png"></div>              

            </div>

            <h4>Custom Website Design</h4>

            <span class="sub-head">The website is an online face of your business that brings the customers to you by convincing and telling about your business, products, or services. So we make custom web designs that creatively speak about your profession to improve engagement.

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/online-shopping21.png"></div>             

            </div>

             <h4>eCommerce Website Design</h4>

            <span class="sub-head">We craft an e-commerce website that enhancing features like user-friendly, appealing, easy to use, and significant navigation that comfort your customers at the time of browsing. We are a reputed web design company with eminent eCommerce website development services.

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/mobile-app.png "></div>             

            </div>

            <h4>Responsive Website Design</h4>

            <span class="sub-head">More than 60% of traffic comes from mobile phones and tablets other than desktops. So it’s a major factor for creating a responsive website design that compatible with all devices. Our expert ui/ux designers build fully responsive websites.

            </span>

          </div>

        </div>

      </div>     



    </div>

      <div class="row weoffer-row2">

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/landing-page2.png"></div>              

            </div>

            <h4>Landing Page Design</h4>

            <span class="sub-head">The first web page that your customers see on your site, so it should be appealing enough to retain the user. We design highly approachable and call-to-action pages that hold your customers and restrain them to go to other sites. 

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/logooe.png"></div>             

            </div>

             <h4>Logo Design</h4>

            <span class="sub-head">A logo is a brand identity that separates you from the competition. Therefore, we offer logo designing services that help you in branding of the business and create a unique impression on your customers. Our creative graphic designers make logos that tell about your brand and hit deeper in your user's mind. 

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

           <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/graphic-design.png"></div>              

            </div>

            <h4>Graphic Designs</h4>

            <span class="sub-head">By our out of the box graphic design ideas, you grab the most of the traffic in your specific industry in an engaging way. As the best web design company, we create the most attractive graphics for your web pages. Our expert graphic designers have the potential to make your website visually sound. 

            </span>

          </div>

        </div>

      </div>      

    </div>



  </div>

</section>

<!-- web design services Offer--->



<section class="webflowfeatures_services webdtech-page">

  <div class="container">

    <div class="title">         

      <h2>Web Design Technologies We

        <a href="" class="typewrite" data-period="2000" data-type='[  "Proficient In" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row weoffer-row1">

      <div class="col-md-4">

        <div class="damlBox">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/module.png"></div>              

            </div>

            <h4>HTML Frameworks</h4>

            <span class="sub-head">HTML is a basic and necessary element of web designing. Web pages are designed by using HTML tags. Our dedicated UI/UX designers are experts in using HTML 5 and previous versions.

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/online-shopping21.png"></div>             

            </div>

             <h4>CSS Frameworks</h4>

            <span class="sub-head">Cascading Style Sheets, or CSS used to beautify or giving visual color and effects to web pages. We use Materialize CSS, Bootstrap 4, Pure, Bulma, Milligram, etc to craft beautiful sites.

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/mobile-app.png "></div>             

            </div>

            <h4>JAVA Script/Libraries</h4>

            <span class="sub-head">We have experience of working on different Java Scripts Frameworks and libraries. Our web design expertise uses NodeJS, Angular, React, VueJs, Meteor, BackboneJs, etc.

            </span>

          </div>

        </div>

      </div>     



    </div>

  </div>

</section>





<!-- Recent work -->

<section class="recentwork-section cmi-recent">

  <div class="container">

    <div class="title">

      <h3>Some of our work that impacts clients' business</h3>

      <h2>Website Design

        <a href="" class="typewrite" data-period="2000" data-type='[  "Recent Works" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row recentworkRow">

      <div class="col-md-3 col-sm-6">

        <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/itfc-ui-ux.png" class="responsive">

            <div class="recentworkContent">

                  <h4>ITFC</h4>

                  <span class="sub-head">A Canada based company which provides robust recruitment option for employers all across Canada.                  

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

        <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/carresol-parquet-prestashop.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Carresol Parquet</h4>

                  <span class="sub-head">France based residential interior business E-commerce PrestaShop store design and development.

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

       <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/allcampussecurity-wordpress.png" class="responsive">

            <div class="recentworkContent">

                  <h4>All Campus Security</h4>

                  <span class="sub-head">US based security solution business website design and development.                                    

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

        <a href="#" class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/gl-ui-ux.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Goodman Lantern</h4>

                  <span class="sub-head">A London based company which provides content writing services.                  

                  </span>

            </div>

          </div>

        </a>

      </div>

    </div>

  </div>

</section>

<!-- Recent work end-->



<!-- --------why choose--------- -->

<section class="webflow-platform expertise-section ecome-page" >

      <div class="container">

        <div class="row">

          <div class="title">

            <h2>Why Choose Our Website Design 

              <a href="" class="typewrite" data-period="2000" data-type='[  "Services In USA? " ]'> 

              </a>

            </h2>            

          </div>

          <div class="alignitemcenter">



                      <div class="col-md-6">

                <div class="mainservicetopbanner">                  

                  <!-- <h2>PHP Environments & Libraries</h2> -->                 

                  

                <div class="expertise-list">

                <div>

                   <div class="advantage-icon">

                    <img src="images/exp-teaam.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                     <p class="advantage-text-head">Experience Team</p>

                     <p class="advantage-text-data">Our experienced team is the key to success that handle any project impressively. Our experience helps us to complete our professional goals in time without any hurdles.</p>

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <img src="images/creative-ideas.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                    <p class="advantage-text-head">Creative Ideas</p>

                     <p class="advantage-text-data">Being a leading website design company we have the reputation of designing the most inspiring and creative ideas that help customers to build a unique identity through the online presence in the industry.</p>

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <img src="images/agreement1.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                    <p class="advantage-text-head">Non Disclosure Agreement (NDA) Policy</p>

                     <p class="advantage-text-data">We are strictly concern about our client data, we make it confidential to provide more securities to 

                      our customers. We always follow the NDA policy.</p>

                  </div>

                </div>              

                

                  </div>

                </div>

          </div>



          <div class="col-md-6">

            <div class="mainservicetopbanner">                  

                  <!-- <h2>PHP Environments & Libraries</h2> -->                 

                  

                <div class="expertise-list">

                <div>

                   <div class="advantage-icon">

                    <img src="images/delivery-time.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                     <p class="advantage-text-head">On-time Delivery</p>

                     <p class="advantage-text-data">While we having a team of highly professional developers and experts we able to deliver projects on time. Without any comprise in the quality of products and services. We do bug-free codding.</p>

                  </div>

                </div>

                  <div>

                   <div class="advantage-icon">

                    <img src="images/seocc.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                    <p class="advantage-text-head">Professional Approach</p>

                     <p class="advantage-text-data">Our approach is more professional. We always listen to the requirements and ideas of our customers. Share our experience to improve and provides that our customer thinks.</p>

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <img src="images/customer-service.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                    <p class="advantage-text-head">Customer Support</p>

                     <p class="advantage-text-data">As an emerging eCommerce web designing company, we ensure to provides 24x7 customer support. We help 

                      clients to make familiar about using CMS, which we use to build an eCommerce website.</p>

                  </div>

                </div>              

                

                  </div>

                </div>

              </div>

        </div>

        </div>

      </div>

    </section>

<!-- end-->



    <!-- hire start -->

    <section class="about-reactjs web3-benefit bg-gray-white ecome-page">

      <div class="container">



        <div class="row row-waffer">          

          <div class="col-md-6 web3-contents">    

          <h2>Website <span class="web-theme-color">Design Company</span></h2>           

            <p class="para">Hire StartDesigns on hourly, weekly or full time basis to design your website. A website can be your dream, business or a form of marketing. We at StartDesigns have the best website designers who can help you create a target oriented, adaptive, appealing, user friendly, efficient website. We offer beautiful elegant templates, customizable layouts, web integrations, mobile optimized design and a lot more. Whatever you desire we create using wordpress, magento, ruby on rails, etc.               

            </p>



            <div class="dflex">

                <a href="#" class="btn btn-contactsupport" id="projectmodel" data-toggle="modal" data-target="#startproject">Start Project →</a>

            </div>                                   

          </div>



          <div class="col-md-6">

              <div class="img_outer">

                <div class="reactleftimages">

                  <img src="images/hire-web-designr.png" class="responsive web-smal floating" alt="image">

                </div>

              </div>                

          </div>

        </div>

      </div>

    </section>

    <!-- hire start -->



 

<!-- Expert review  testimony-serve-->

  <section class="section-testimonials reveiw_slide bg-white ">

      <div class="container">

        <div class="row">

          <div class="title">

            <h3>Testimony from our happy clients</h3>

            <h2>What do client say about 

              <a href="" class="typewrite" data-period="2000" data-type='[  "Web Design" ]'> 

              </a>

            </h2>

          </div>

        </div>

       

        <div id="review-slider" class="owl-carousel">

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn18.png" alt="">

                  <div class="user-details-services">

                    <h4>Daniel P.</h4>

                    <p>Goodman Lantern</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "StartDesigns is worth much more than I paid. Not able to tell you how happy I am with Website Design services by StartDesigns. "

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn26.png" alt="">

                  <div class="user-details-services">

                    <h4>Béatrice</h4>

                    <p>All Campus Security</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "I was amazed at the quality of UX/UI Design services. Definitely worth the investment. We were treated like royalty."

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn19.png" alt="">

                  <div class="user-details-services">

                    <h4>Amelia</h4>

                    <p>ITFC</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "Start designs produced a great solution to a very complicated Web designs in a very cost-effective manner."

                </p>

              </div>

            </div>

          </div>

        </div>        



      </div>

    </section>

<!-- Expert review end -->





<!--#include file="footer.shtml"-->

    <a href="javascript:" id="return-to-top">

      <i class="fa fa-angle-double-up  " aria-hidden="true">

      </i>

    </a>



<?php include('footer.php'); ?>



<script type="text/javascript" src="js/jquery.js">

</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js">

</script>

<script src="js/jquery.countup.js">

</script>

<script>

$('.counter').countUp();

</script>

<!-- <script src="js/bootstrap.min.js">

</script> -->

<script src="js/owl.carousel.min.js" defer>

</script>

<script src="js/script.js">

</script>

<script src="js/jquery-1.11.1.min.js">

</script>

<script src="js/jquery.validate.min.js">

</script>

<script src="js/additional-methods.min.js">

</script>

<script src="js/slick.min.js" defer>

</script>









<!-- ----------testimony slider------- -->

<script>

$(document).ready(function(){

    $('#review-slider').owlCarousel({

  loop: true,

  margin: 10,

  nav: false,  

  autoplay: true,

  autoplayHoverPause: true,

  responsive: {

    0: {

      items: 1

    },

    767: {

      items: 1

    },

    1000: {

      items: 1

    }

  }

})

  })

</script>



<script>

  $(document).ready(function(){

    $('#whychoose-slider').owlCarousel({

  loop: true,

  margin: 10,

  nav: false,  

  autoplay: true,

  autoplayHoverPause: true,

  responsive: {

    0: {

      items: 1

    },

    767: {

      items: 2

    },

    1000: {

      items: 4

    }

  }

})

  })

</script>



</body>

</html>

