 <?php include('header.php'); ?>

<!--#include file="header.shtml"-->

          <div class="no-touch m-nav-menusocial">

            <div id="menusocial" class="menu--social1">

              <div class="toggle--social">

                <span class="soundspeaker-icon">

                </span>

              </div>

              <ul class="menu--sub">

                <li class="menu__item--facebook"> 

                  <a target="_blank" itemprop="samAs" class="menu-link sub-menu-link social_event_track_cls" data-title="Facebook" href="#">

                    <i>

                    </i>HB on Facebook

                  </a> 

                </li>

                <li class="menu__item--twitter"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Twitter" href="#">

                    <i>

                    </i> HB on Twitter 

                  </a> 

                </li>

                <li class="menu__item--linkdin"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="LinkedIn" href="#">

                    <i>

                    </i>HB on Linkedin

                  </a> 

                </li>

                <li class="menu__item--google-p"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Google Plus" href="#">

                    <i>

                    </i>HB on Google+

                  </a> 

                </li>

                <li class="menu__item--youtube"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="You Tube" href="#">

                    <i>

                    </i>HB on Youtube

                  </a> 

                </li>

                <li class="menu__item--blog"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Blog" href="#">

                    <i>

                    </i>HB on Blog

                  </a> 

                </li>

              </ul>

            </div>

          </div>

        </div>

        <div id="top-container" style="display:none;">

          <div class="centerdiv">

            <div class="left"> 

              <a href="#" title=""> 

                <img src="images/logo.png" width="261" height="51" alt="" class="logo" /> 

              </a> 

            </div>

            <div class="right" style="width:72%;">

              <div class="r-clear menu-display">

                <div class="search-div">

                  <input type="search" placeholder="Search" name="" />

                </div>

                <span class="link-area">

                  <a target="_blank" title="" href="#">Blog

                  </a>

                  <a title="" href="#" target="_blank">Articles

                  </a>

                  <a title="" href="#">FAQ

                  </a>

                  <a title="" href="#">Careers

                  </a> 

                  <a title="Contact" href="#">Contact

                  </a> 

                  <a title="" href="#">Partnership

                  </a>

                </span> 

              </div>

              <div class="r-clear topmenu">

                <div class="mobile-tablet-menu">

                  <a href="#" class="mobile-menu-home-iclass" id="mobile-menu-home-icon">

                  </a>

                  <div class="mobile-menu-home-contner" id="mobile-menu-home">

                    <ul>

                      <li>

                        <a title="Company" href="#">Company

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Services

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Technology

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Products

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Client

                        </a>

                      </li>

                      <li>

                        <a title="Work" class="work-menu" href="#">Work

                        </a>

                      </li>

                      <li>

                        <a title="Inquiry" href="#" id="inquiry-pop-up" class="active">Get Quote

                        </a>

                      </li>

                    </ul>

                  </div>

                </div>

                <ul class="menu-t-menu-new">

                  <li>

                    <a title="startdesigns InfoTech" href="#">

                      <span class="home">

                      </span>

                    </a> 

                  </li>

                  <li>

                    <a title="Company" href="#">Company

                    </a> 

                  </li>

                  <li>

                    <a title="Services" href="#">Services

                    </a> 

                  </li>

                  <li>

                    <a title="Technology" href="#">Technology

                    </a> 

                  </li>

                  <li>

                    <a href="#">Products

                    </a> 

                  </li>

                  <li>

                    <a title="Work" href="#">Work

                    </a> 

                  </li>

                  <li>

                    <a title="Inquiry" href="#">Get Quote

                    </a> 

                  </li>

                </ul>

              </div>

            </div>

          </div>

        </div>

      </div>

    </header>



    <!-- Banner top- contact end -->



    <section class="service-topbanner reactbannerbg">

      <div class="container">

          <div class="row service-flex">

              <div class="col-md-6">

                <div class="mainservicetopbanner">

                  <h3>ReactJS Development Company</h3>

                  <h1 class="wordpress_head">ReactJS Development Services</h1>

                  <p>Hire the ultimate Reactjs developer for a well-designed and responsive application. Start Designs help you build a scalable and feature Js solution for a great user experience, which will help you achieve great conversions. Our highly experienced developers work extensively to deliver an unparalleled experience to the users.</p>

                  <div class="dflex">

                    <a href="#foooter_form" class="btn btn-contactsupport">Contact Support →</a>

                    <a href="#" class="btn btn-startproject" id="projectmodel" data-toggle="modal" data-target="#startproject">Start Project →</a>

                  </div>                  

                </div>

              </div>

              <div class="col-md-6">

                <div class="rightside-topbanner wpbanner-top">

                  <img src="images/Reactjs-Development-img.svg">

                </div>

              </div>

          </div>

      </div>

    </section>



    <section class="developmnt_services react-page">

  <div class="container">

    <div class="row">

      <div class="developmnt_services_box">

        <div class="service_box_data">

          <div class="dev_service_icon"><img src="images/devops.svg"></div>

          <p>Reusable Components</p>          

        </div>



        <div class="service_box_data">

          <div class="dev_service_icon"><img src="images/server.svg"></div>

          <p>Server Configuration</p>          

        </div>



        <div class="service_box_data">

          <div class="dev_service_icon"><img src="images/ux-ui.svg"></div>

          <p>UI Focused Designs</p>          

        </div>



        <div class="service_box_data">

          <div class="dev_service_icon"><img src="images/quick.svg"></div>

          <p>Prompt Rendering</p>          

        </div>



        <div class="service_box_data">

          <div class="dev_service_icon"><img src="images/comptent.svg"></div>

          <p>Competent Resources</p>

        </div>

        

      </div>

    </div>

  </div>

</section>





        <!-- About Reactjs start -->

    <section class="about-reactjs">

      <div class="container">

        <div class="title">    

          <h3>Creating web And mobile applications with ReactJS</h3>  

          <h2>What is

            <a href="" class="typewrite" data-period="2000" data-type='[  "ReactJS Development? " ]'> 

            </a>

          </h2>

        </div>



        <div class="row row-waffer">

          <div class="col-md-6 react-contents">            

            <p class="para">Build best user interfaces and their components with ReactJs. It is an open-source front-end JavaScript library that helps you achieve a declarative, constructive, and efficient user interface. It is maintained by Facebook and a community of individual developers and companies.                

            </p>



            <div class="advantages-hiring-list">

                <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                     It helps in creating interactive UIs.  

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                    It facilitates remarkable cross-platform support. 

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                    It helps in attaining SEO-friendly user interfaces across browsers and engines. 

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                    It facilitates easy further maintenance and also boosts productivity. 

                  </div>

                </div>              

              </div>                                   

          </div>



          <div class="col-md-6">

              <div class="img_outer">

                <div class="reactleftimages">

                  <img src="images/reactjs11.png" class="responsive floating">

                </div>

              </div>                

          </div>

        </div>

      </div>

    </section>

    <!-- About Reactjs ends -->



<!-- --------Why start designs start--------- -->

    <section class="section-reason-choose wp-devlop-choose react-page">

      <div class="container">

        <div class="row">

          <div class="title">

            <h2>Why You Choose 

              <a href="" class="typewrite" data-period="2000" data-type='[  "Reactjs Development?" ]'> 

              </a>

            </h2>           

          </div>

        </div>

        <div class="row">

          <div class="col-md-12">

            <div id="whychoose-slider" class="owl-carousel">

              <div class="testimonial">

                <div class="advantageBox newDml">        

                  <div class="advantageImg">

                    <div class="pink_bordr_icon"><img src="images/easy-to-use.png"></div>              

                  </div>

                  <div class="advantageContent">

                          <h4>Easy to Learn and Use</h4>

                          <span class="sub-head">Here, we provide easy-to-learn and use websites. Our highly experienced developers make sure the platform is user-friendly and easy to use, and no one faces issues understanding how it works. 

                          </span>

                  </div>

                </div>                

              </div>

              <div class="testimonial">

                <div class="advantageBox newDml">        

                  <div class="advantageImg">

                    <div class="pink_bordr_icon"><img src="images/reuseable.png"></div>              

                  </div>

                  <div class="advantageContent">

                          <h4>Component Reusability</h4>

                          <span class="sub-head">Component Reusability is the quintessential part of development that supports the reusing of components in different environments, which makes us save time and money. Our developers aim to achieve efficiency in optimum resources.

                          </span>

                  </div>

                </div>                

              </div>

              <div class="testimonial">

                <div class="advantageBox newDml">        

                  <div class="advantageImg">

                    <div class="pink_bordr_icon"><img src="images/custom-c-development.png"></div>               

                  </div>

                  <div class="advantageContent">

                          <h4>Virtual DOM for Performance</h4>

                          <span class="sub-head">Our vision is to serve better performance. Virtual DOM is a feature that is known for its efficient algorithm and boosts the performance of web applications is lightweight and easy for transitions. 

                          </span>

                  </div>

                </div>                

              </div>

              <div class="testimonial">

                <div class="advantageBox newDml">        

                  <div class="advantageImg">

                    <div class="pink_bordr_icon"><img src="images/adaptive.png"></div>               

                  </div>

                  <div class="advantageContent">

                          <h4>Easy adaptability</h4>

                          <span class="sub-head">We ensure our website is easily adaptable. Our designers take care of all the users and devices used to access it. It is taken care of depending on the different audience using it and make it user-friendly and accessible. 

                          </span>

                  </div>

                </div>                

              </div>

              <div class="testimonial">

                <div class="advantageBox newDml">        

                  <div class="advantageImg">

                    <div class="pink_bordr_icon"><img src="images/seocc.png"></div>               

                  </div>

                  <div class="advantageContent">

                          <h4>SEO-Friendly</h4>

                          <span class="sub-head">These services make your website presence more approachable with the help of using correct keywords, structuring content, and optimizing images. To make your web presence better and build traffic on your website on all search engines. 

                          </span>

                  </div>

                </div>                

              </div>     

              <div class="testimonial">

                <div class="advantageBox newDml">        

                  <div class="advantageImg">

                    <div class="pink_bordr_icon"><img src="images/custom-cdev.png"></div>               

                  </div>

                  <div class="advantageContent">

                          <h4>Reliable Development Tools</h4>

                          <span class="sub-head">Our developers use reliable development tools that help in creating intuitive ReactJs solutions. These tools help in debugging and maintaining the ReactJs solutions for optimal results. 

                          </span>

                  </div>

                </div>                

              </div>

              <div class="testimonial">

                <div class="advantageBox newDml">        

                  <div class="advantageImg">

                    <div class="pink_bordr_icon"><img src="images/protectioon.png"></div>               

                  </div>

                  <div class="advantageContent">

                          <h4>Code Stability</h4>

                          <span class="sub-head">Our developers are highly experienced and skilled in their jobs. They ensure providing optimal functioning web products with stable platforms which are efficient on multiple devices, user-friendly, and easy to use for different audiences.

                          </span>

                  </div>

                </div>                

              </div> 

              <div class="testimonial">

                <div class="advantageBox newDml">        

                  <div class="advantageImg">

                    <div class="pink_bordr_icon"><img src="images/frameworkhtml.png"></div>               

                  </div>

                  <div class="advantageContent">

                          <h4>Supports Server-side Rendering</h4>

                          <span class="sub-head">ReactJs supports server-side rendering, which is very effective for SEO. Server-side rendering speeds up the load time, which improves user experience and also helps the website to rank better on google.

                          </span>

                  </div>

                </div>                

              </div>       

             

            </div>

          </div>

        </div>

      </div>

    </section>

<!-- --------Why start designs ends--------- -->





<!-- Scope of ReactJS -->

<section class="angularjs_scope react-page">

  <div class="container">

    <div class="title">      

      <h2>ReactJS Development 

        <a href="" class="typewrite" data-period="2000" data-type='[  "Services We Offer " ]'> 

        </a>

      </h2>

    </div>



    <div class="row scope-row1">

      <div class="col-md-6">

        <div class="scopeBox newDml">

          <div class="ScopeContent ">

            <div class= "ScopeContentHead">

              <div class="pink_bordr_icon"><img src="images/drupal2.png"></div>

              <h4>ReactJS UI/UX Development</h4>

            </div>

            <p>Get well-designed UI/UX solutions with Start Designs. Our highly experienced developers help you achieve an interactive user interface and aesthetically pleasing user experience. They understand your requirements and market trends and deliver a solution that will help you get a unique identity business.

            </p>

          </div>

        </div>

      </div>

      <div class="col-md-6">

        <div class="scopeBox newDml">

          <div class="ScopeContent ">

            <div class= "ScopeContentHead">

              <div class="pink_bordr_icon"><img src="images/drupal3.png"></div>

              <h4>ReactJS Web App Development</h4>

            </div>

            <p>At Start Designs, we deliver you a scalable, robust, user-friendly, and professional web application. Our highly skilled developers work relentlessly to meet your requirements, resulting in an application that is an amalgamation of your vision and market trends. 

            </p>

          </div>

        </div>

      </div>

    </div>



    <div class="row scope-row2">

      <div class="col-md-6">

         <div class="scopeBox newDml">

          <div class="ScopeContent ">

            <div class= "ScopeContentHead">

              <div class="pink_bordr_icon"><img src="images/custom-c-development.png"></div>

              <h4>ReactJS Custom Development</h4>

            </div>

            <p>Get custom ReactJs solutions at Start Designs. Our team of professional developers works diligently to provide you with user-friendly, cross-platform, cross-browser custom ReactJs solutions. They help you achieve your vision by understanding your business requirements and implementing them. 

            </p>

          </div>

        </div>

      </div>

      <div class="col-md-6">

         <div class="scopeBox newDml">

          <div class="ScopeContent ">

            <div class= "ScopeContentHead">

              <div class="pink_bordr_icon"><img src="images/drupal1.png"></div>

              <h4>ReactJS Migration</h4>

            </div>

            <p>We help you migrate to ReactJs and get better-performing applications. ReactJs makes your application load faster and gives a seamless navigation experience to the user. No matter on what platform your application is, we will help you migrate to ReactJs with all your data intact. 

            </p>

          </div>

        </div>

      </div>

    </div>



    <div class="row scope-row3">

      <div class="col-md-6">

         <div class="scopeBox newDml">

          <div class="ScopeContent ">

            <div class= "ScopeContentHead">

              <div class="pink_bordr_icon"><img src="images/web-c-plugin.png"></div>

              <h4>ReactJS Plugins</h4>

            </div>

            <p>Get a custom ReactJs plugin or customize an existing plugin with the help of our highly experienced developers. At Start Designs, we comprehend your specification and help you attain feature-rich, compatible, and easy-to-use plugins.

            </p>

          </div>

        </div>

      </div>

      <div class="col-md-6">

         <div class="scopeBox newDml">

          <div class="ScopeContent">

            <div class= "ScopeContentHead">

              <div class="pink_bordr_icon"><img src="images/integration-color.png"></div>

              <h4>ReactJS Integration Services</h4>

            </div>

            <p>At Start Designs, we help you integrate ReactJs into an existing application or a third-party application into ReactJs. Our profoundly skilled developers make the integration smooth and effective. Our experts' realign the application in a way that the application will derive more results and meet all your needs.

            </p>

          </div>

        </div>

      </div>

    </div>



    <div class="row scope-row4">

      <div class="col-md-6">

         <div class="scopeBox newDml">

          <div class="ScopeContent ">

            <div class= "ScopeContentHead">

              <div class="pink_bordr_icon"><img src="images/api-color.png"></div>

              <h4>ReactJS API Integration</h4>

            </div>

            <p>At Start Designs, we help you integrate APIs into ReactJs. Our experts assist you in trustworthy integration so that you can gain the maximum benefit of this innovative framework.

            </p>

          </div>

        </div>

      </div>

      <div class="col-md-6">

         <div class="scopeBox newDml">

          <div class="ScopeContent ">

            <div class= "ScopeContentHead">

              <div class="pink_bordr_icon"><img src="images/drupal4.png"></div>

              <h4>ReactJS Template Creation</h4>

            </div>

            <p>Get innovative ReactJs templates at Start Designs. Our highly experienced team of developers works keenly to deliver a template that's a blend of your vision and market trends. Thus, creating an intuitive template that will give you an edge in the market. 

            </p>

          </div>

        </div>

      </div>

    </div>



  </div>

</section>

<!-- Scope of ReactJS Ends -->





<!-- Why us as reactjs partner  -->

  <section class="stripe_advantge reactjs-page">

    <div class="container">

        <div class="title">

          <!-- <h3>We build beautiful Webflow websites that engage your audience.</h3> -->

          <h2>Why We Are Reliable 

            <a href="" class="typewrite" data-period="2000" data-type='[  "ReactJS Development Partners? " ]'> 

            </a>

          </h2>

        </div>         

              <div class="row service-flex">              

                  <div class="col-md-6">

                    <div class="mainservicetopbanner features-title">

                      <!-- <h3>We used CMI integration </h3>

                      <h2>Know More About <span class="sd-web-pink">CMI Payment Gateway</span></h2> -->

                      <div class="advantages-hiring-list">

                    <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                         We have a team of qualified and highly experienced developers who will work with you diligently to achieve your vision. 

                      </div>

                    </div>

                     <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                        We provide you with tailor-made ReactJs solutions that meet all your requirements and give you an upper hand in the market.

                      </div>

                    </div>

                     <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                        Our developers are well equipped with market trends and new technologies.

                      </div>

                    </div>    

                     <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                        Our project managers are in constant touch with the client and regularly update them on the progress of the project. 

                      </div>

                    </div> 

                     <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                        We deliver the project on the stipulated timeline. 

                      </div>

                    </div> 

                     <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                        We provide you with lifetime support for our services to ensure that they perform seamlessly. 

                      </div>

                    </div>           

                  </div>                      

                      <!-- <div class="dflex">

                        <a href="#" class="btn btn-contactsupport btn-mrgn-top">Start a Project</a>

                      </div> -->

                    </div>

                  </div>   



                  <div class="col-md-6">

                  <div class="img_outer">

                    <div class="cmileftimages">

                      <img src="images/reactjs-1.png" class="responsive floating">

                    </div>

                  </div>                

                  </div>

                            

              </div>             

    </div>

  </section>

    <!-- Why us as reactjs partner ends -->







<!-- Recent work Ui -->

<!-- <section class="recentwork-section angular-recent">

  <div class="container">

    <div class="title">

      <h5>Some of our work that impacts clients' business</h5>

      <h2>ReactJS Development

        <a href="" class="typewrite" data-period="2000" data-type='[  "Recent Works" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row recentworkRow">

      <div class="col-md-3 col-sm-6">

        <a href="#" class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/shopify-project-1.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Bhagyaratnam</h4>

                  <span class="sub-head">Lorem Ipsum has been the industry's standard dummy text.

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

        <a href="#" class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/shopify-project-2.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Pistaa sales</h4>

                  <span class="sub-head">Lorem Ipsum has been the industry's standard dummy text.

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

       <a href="#" class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/topbanner-servicespage.png" class="responsive">

            <div class="recentworkContent">

                  <h4>ReactJS Project</h4>

                  <span class="sub-head">Lorem Ipsum has been the industry's standard dummy text.

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

        <a href="#" class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/topbanner-servicespage.png" class="responsive">

            <div class="recentworkContent">

                  <h4>ReactJS Project</h4>

                  <span class="sub-head">Lorem Ipsum has been the industry's standard dummy text.

                  </span>

            </div>

          </div>

        </a>

      </div>

    </div>

  </div>

</section> -->



<!-- Recent work Ui end-->



 

<!-- Expert review -->

  <section class="section-testimonials reveiw_slide php_page bg-white">

      <div class="container">

        <div class="row">

          <div class="title">

            <h3>Testimony from our happy clients</h3>

            <h2>What do client say about 

              <a href="" class="typewrite" data-period="2000" data-type='[  "ReactJS Expert" ]'> 

              </a>

            </h2>

          </div>

        </div>

       

        <div id="review-slider" class="owl-carousel">

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn21.png" alt="">

                  <div class="user-details-services">

                    <h4>Brayden</h4>

                    <p>ReactJS Expert</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "Start designs produced a great solution to a very complicated ReactJS application in a very cost-effective manner."

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn5.png" alt="">

                  <div class="user-details-services">

                    <h4>Jeff Carlos</h4>

                    <p>ReactJS Expert</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "Start designs is an outstanding organization,they fulfilled my vision & nurtured it to even better. I received a very well finished product in a tight deadline."

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn8.png" alt="">

                  <div class="user-details-services">

                    <h4>John Doe</h4>

                    <p>ReactJS Expert</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "The strong expertise of developers at ReactJS India improved several processes at every level of our business. They were very proactive, efficient, communicative, cooperative, and accepting of feedback."

                </p>

              </div>

            </div>

          </div>

        </div>        



      </div>

    </section>

<!-- Expert review end -->





<!-- ReactJS FAQ Ui -->

<section class="webflowfeatures_services presta_faq">

  <div class="container">

    <div class="title">

      <h3>Got questions? We've got answers!</h3>

      <h2>FAQ's 

        <a href="" class="typewrite" data-period="2000" data-type='[  "Frequently Asked Questions" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row">

      <div class="col-md-8 col-md-offset-2 faq-main-parent">

          <button class="accordion-faq">How does React JS decrease application development costs?</button>

          <div class="panel-faq">

            <p>ReactJS offers reusability, code UI parts, and tests the applications while compiling the code. The isomorphic highlights of the ReactJS library allow programmers to code in both customer and server-side of the application. This lessens the application advancement cost.</p>

          </div>



          <button class="accordion-faq">What are the advantages of outsourcing ReactJS web development?</button>

          <div class="panel-faq">

            <p>Here is a portion of the critical advantages of outsourcing your ReactJS Web development:</p>



            <ul class="faq-navbar">

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> Low development and process expense </li>

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> Adaptable to work as indicated by your time-region </li>

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> Admittance to work with skilled and experienced developers </li>

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> On-time project delivery </li>

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> Guaranteed quality administrations </li>

            </ul>

          </div>



          <button class="accordion-faq">Is React JS good for sophisticated applications?</button>

          <div class="panel-faq">

            <p>You can use React for developing sophisticated apps. However, React Js is predominantly used for the development of small-scale apps such as single-page apps and progressive web applications.</p>

          </div>

      </div>

    </div>

      



  </div>

</section>



<!-- ReactJS FAQ  end-->



<!--#include file="footer.shtml"-->

    <a href="javascript:" id="return-to-top">

      <i class="fa fa-angle-double-up  " aria-hidden="true">

      </i>

    </a>



<?php include('footer.php'); ?>





<script>

  $(document).ready(function(){

    $('#whychoose-slider').owlCarousel({

  loop: true,

  margin: 10,

  nav: false,  

  autoplay: true,

  autoplayHoverPause: true,

  responsive: {

    0: {

      items: 1

    },

    767: {

      items: 2

    },

    1000: {

      items: 3

    }

  }

})

  })

</script>



<!-- ----------testimony slider------- -->

<script>

$(document).ready(function(){

    $('#review-slider').owlCarousel({

  loop: true,

  margin: 10,

  nav: false,  

  autoplay: true,

  autoplayHoverPause: true,

  responsive: {

    0: {

      items: 1

    },

    767: {

      items: 1

    },

    1000: {

      items: 1

    }

  }

})

  })

</script>





</body>

</html>

