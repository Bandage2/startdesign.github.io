 <?php include('header.php'); ?>

<!--#include file="header.shtml"-->

          <div class="no-touch m-nav-menusocial">

            <div id="menusocial" class="menu--social1">

              <div class="toggle--social">

                <span class="soundspeaker-icon">

                </span>

              </div>

              <ul class="menu--sub">

                <li class="menu__item--facebook"> 

                  <a target="_blank" itemprop="samAs" class="menu-link sub-menu-link social_event_track_cls" data-title="Facebook" href="#">

                    <i>

                    </i>HB on Facebook

                  </a> 

                </li>

                <li class="menu__item--twitter"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Twitter" href="#">

                    <i>

                    </i> HB on Twitter 

                  </a> 

                </li>

                <li class="menu__item--linkdin"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="LinkedIn" href="#">

                    <i>

                    </i>HB on Linkedin

                  </a> 

                </li>

                <li class="menu__item--google-p"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Google Plus" href="#">

                    <i>

                    </i>HB on Google+

                  </a> 

                </li>

                <li class="menu__item--youtube"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="You Tube" href="#">

                    <i>

                    </i>HB on Youtube

                  </a> 

                </li>

                <li class="menu__item--blog"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Blog" href="#">

                    <i>

                    </i>HB on Blog

                  </a> 

                </li>

              </ul>

            </div>

          </div>

        </div>

        <div id="top-container" style="display:none;">

          <div class="centerdiv">

            <div class="left"> 

              <a href="#" title=""> 

                <img src="images/logo.png" width="261" height="51" alt="" class="logo" /> 

              </a> 

            </div>

            <div class="right" style="width:72%;">

              <div class="r-clear menu-display">

                <div class="search-div">

                  <input type="search" placeholder="Search" name="" />

                </div>

                <span class="link-area">

                  <a target="_blank" title="" href="#">Blog

                  </a>

                  <a title="" href="#" target="_blank">Articles

                  </a>

                  <a title="" href="#">FAQ

                  </a>

                  <a title="" href="#">Careers

                  </a> 

                  <a title="Contact" href="#">Contact

                  </a> 

                  <a title="" href="#">Partnership

                  </a>

                </span> 

              </div>

              <div class="r-clear topmenu">

                <div class="mobile-tablet-menu">

                  <a href="#" class="mobile-menu-home-iclass" id="mobile-menu-home-icon">

                  </a>

                  <div class="mobile-menu-home-contner" id="mobile-menu-home">

                    <ul>

                      <li>

                        <a title="Company" href="#">Company

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Services

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Technology

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Products

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Client

                        </a>

                      </li>

                      <li>

                        <a title="Work" class="work-menu" href="#">Work

                        </a>

                      </li>

                      <li>

                        <a title="Inquiry" href="#" id="inquiry-pop-up" class="active">Get Quote

                        </a>

                      </li>

                    </ul>

                  </div>

                </div>

                <ul class="menu-t-menu-new">

                  <li>

                    <a title="startdesigns InfoTech" href="#">

                      <span class="home">

                      </span>

                    </a> 

                  </li>

                  <li>

                    <a title="Company" href="#">Company

                    </a> 

                  </li>

                  <li>

                    <a title="Services" href="#">Services

                    </a> 

                  </li>

                  <li>

                    <a title="Technology" href="#">Technology

                    </a> 

                  </li>

                  <li>

                    <a href="#">Products

                    </a> 

                  </li>

                  <li>

                    <a title="Work" href="#">Work

                    </a> 

                  </li>

                  <li>

                    <a title="Inquiry" href="#">Get Quote

                    </a> 

                  </li>

                </ul>

              </div>

            </div>

          </div>

        </div>

      </div>

    </header>



    <!-- Banner top- contact end -->



    <section class="service-topbanner ecombannerbg">      

      <div class="container">

          <div class="row service-flex">

              <div class="col-md-6">

                <div class="mainservicetopbanner">

                  <h3>E-commerce Development Company</h3>

                  <h1 class="wordpress_head">E-commerce Website Design and Development Company</h1>

                  <p>Emerging eCommerce website development company based out in India develops the most reliable customer-centric online store from the front-end and simply manageable from the back-end that generates sales and simultaneously increases your revenue.</p>

                  <div class="dflex">

                    <a href="#foooter_form" class="btn btn-contactsupport">Contact Support →</a>

                    <a href="#" class="btn btn-startproject" id="projectmodel" data-toggle="modal" data-target="#startproject">Start Project →</a>

                  </div>                  

                </div>

              </div>

              <div class="col-md-6">

                <div class="rightside-topbanner wpbanner-top">

                  <img src="images/ecom-banner.png" alt="ecommerce website development company">

                </div>

              </div>

          </div>

      </div>

      <!-- </div> -->

    </section>





        <!-- About E-commerce start -->

    <section class="about-reactjs web3-page ecom-page">

      <div class="container">

        <div class="title">    

              

          <h2>Emerging E-commerce Website Development  

            <a href="" class="typewrite" data-period="2000" data-type='[  "Company" ]'> 

            </a>

          </h2>

        </div> 

 

        <div class="row row-waffer">   



          <div class="col-md-6">

              <div class="img_outer">

                <div class="reactleftimages">

                  <img src="images/ecomshop.png" class="responsive web-smal floating" alt="e-commerce website development">

                </div>

              </div>                

          </div>



          <div class="col-md-6 web3-contents">     

          <h3>Why Does Your Business Need An E-commerce Website?</h3>       

            <p class="para">It is a long established fact that a reader will be distracted by the 

              readable content of a page when looking at its layout. The point of 

              using Lorem Ipsum is that it has a more-or-less normal distribution 

              of letters, as opposed.</p>

            <p class="para">88% i.e. almost 9 out of 10 consumers research online before purchasing online or in-store.

              74% of customers purchasing decision depends on social networks

              Retail e-commerce sales in 2019 calculated 3.535 billion US dollars globally</p>



              <a href="https://www.startdesigns.com/blog/why-your-business-needs-an-e-commerce-website/" class="btn btn-contactsupport">Read More</a>                                   

          </div>

          

        </div>

      </div>

    </section>

    <!-- About E-commerce ends -->



    <!-- E-commerce services Offer -->

<section class="webflowfeatures_services web3-page bg-gray-white ecom-page">

  <div class="container">

    <div class="title">   

      <h3>We are providing every <span class="transcase">E-commerce</span> service that your business needs.</h3>   

      <h2>Our <span class="transcase">E-commerce</span> Web 

        <a href="" class="typewrite" data-period="2000" data-type='[  "Development Services" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row weoffer-row1">

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/mobile-phone.png"></div>              

            </div>

            <h4>E-commerce App Development</h4>

            <span class="sub-head">We make hassle-free B2B, B2C, C2C, and C2B eCommerce mobile apps that build a relationship with customers in a more captivating way. Apps are embedded with features like fast loading speed, feedback system, push notification, advanced search options, user convenience, etc.

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/mobile-app.png"></div>             

            </div>

             <h4>Responsive E-commerce Web Design</h4>

            <span class="sub-head">Build a responsive eCommerce website design that can increase your revenue by giving an easy-to-use experience t o your customers. Use the latest technologies to improve website UI/UX at every platform like mobiles, tablets, desktops, etc. Our approach is always customer-centric.

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/online-shopping21.png"></div>              

            </div>

            <h4>Custom E-commerce Store Development </h4>

            <span class="sub-head">Always ready to build according to customer’s requirements. Thus we offer custom e-commerce store development services for customers that help to build more according to their business needs. We use technologies like PHP, Node.Js, React, RoR, etc to provide a highly secure and user handy.

            </span>

          </div>

        </div>

      </div>     



    </div>

      <div class="row weoffer-row2">

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/module.png"></div>              

            </div>

            <h4>E-commerce Plugin and Module Development</h4>

            <span class="sub-head">We develop custom plugins and modules to empower your business. We make plugins with new features and functionalities for different cms like WordPress, BigCommerce, Magento, OpenCart, etc. 

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/integration-color.png"></div>             

            </div>

             <h4>CMS Integration</h4>

            <span class="sub-head">We integrate various open source content management systems(CMSs) like Magento, Woo-Commerce, Drupal, Shopify, PrestaShop, SquareSpace, Jumla, OpenCart, and more to build complete eCommerce websites at the best costs. 

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

           <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/maintenance22.png"></div>              

            </div>

            <h4>Maintenance and Support</h4>

            <span class="sub-head">We provide support to customers whenever they facing any problem to use and handle the eCommerce site. Help to maintain, migrate website to another platform, upgrading, and integration of third-party APIs. 

            </span>

          </div>

        </div>

      </div>      

    </div>



  </div>

</section>

<!-- E-commerce services Offer--->



<!-- --------technology use start--------- -->

    <section class="section-reason-choose wp-devlop-choose ecom-page">

      <div class="container">

        <div class="row">

          <div class="title">

            <h2>Technologies We Use In E-commerce

              <a href="" class="typewrite" data-period="2000" data-type='[  "Website Development" ]'> 

              </a>

            </h2>           

          </div>

        </div>

        <div class="row">

          <div class="col-md-12">

            <div id="whychoose-slider" class="owl-carousel">

              <div class="testimonial">

                <div class="advantageBox newDml">        

                  <div class="technoImg">

                    <img src="images/shopify-econ.png">              

                  </div>

                  <div class="advantageContent">                          

                          <span class="sub-head">Set up your online shop with Shopify. It gives features like mobile responsive, free SSL, 100 payment gateways, multiple languages to spread business worldwide, 70+ professional themes.                    

                          </span>

                  </div>

                </div>                

              </div>

              <div class="testimonial">

                <div class="advantageBox newDml">        

                  <div class="technoImg">

                    <img src="images/drupal-econ.png">              

                  </div>

                  <div class="advantageContent">

                          <span class="sub-head">Legitimize your e-commerce store online with a modular design allowing features by open source CMS like Drupal. With features like mobile responsive, quickly editable, power of HTML5, easy authoring, etc.

                          </span>

                  </div>

                </div>                

              </div>

              <div class="testimonial">

                <div class="advantageBox newDml">        

                  <div class="technoImg">

                    <img src="images/node-econ.png">              

                  </div>

                  <div class="advantageContent">

                          <span class="sub-head">Create and Manage your eCommerce business online with powered by PrestaShop. It integrated with features like eCommerce SEO, mobile-friendly, intuitive interface, and powerful store builder.                    

                          </span>

                  </div>

                </div>                

              </div>

              <div class="testimonial">

                <div class="advantageBox newDml">        

                  <div class="technoImg">

                    <img src="images/magento-econ.png">              

                  </div>

                  <div class="advantageContent">

                          <span class="sub-head">Shatter Limits to online store development and gives a unique experience to your customers by using Magento. Magento has features that improve your website performance.

                          </span>

                  </div>

                </div>                

              </div>

              <div class="testimonial">

                <div class="advantageBox newDml">        

                  <div class="technoImg">

                    <img src="images/php-econ.png">              

                  </div>

                  <div class="advantageContent">

                          <span class="sub-head">Generate more revenue from online e-commerce store with integration of BigCommerce open source CMS. It comes with built-in SEO features for more organic exposure and external application integration options.

                          </span>

                  </div>

                </div>                

              </div>     

              <div class="testimonial">

                <div class="advantageBox newDml">        

                  <div class="technoImg">

                    <img src="images/wordpress-icon.png">              

                  </div>

                  <div class="advantageContent">

                          <span class="sub-head">Open new opportunities for business by using WordPress CMS. It improves functionalities and user experience with thousands of plugins available.

                          </span>

                  </div>

                </div>                

              </div>

              <div class="testimonial">

                <div class="advantageBox newDml">        

                  <div class="technoImg">

                    <img src="images/open-icon.png">              

                  </div>

                  <div class="advantageContent">

                          <span class="sub-head">Enhance your web store with the power of OpenCart. It is highly customizable, social media integrated, and with an electronic payment gateway.

                          </span>

                  </div>

                </div>                

              </div>  

              <div class="testimonial">

                <div class="advantageBox newDml">        

                  <div class="technoImg">

                    <img src="images/woo-icon.png">              

                  </div>

                  <div class="advantageContent">

                          <span class="sub-head"><p>Customize your business online by using WooCommerce. It explores your experience by enhancing the website with the power of modular functionality, adds unlimited products, sells anything, and powered by trust.</p>

                          </span>

                  </div>

                </div>                

              </div> 

              <div class="testimonial">

                <div class="advantageBox newDml">        

                  <div class="technoImg">

                    <img src="images/joomla.png">              

                  </div>

                  <div class="advantageContent">

                          <span class="sub-head">Engage more customers to your web business with Joomla. It powers with media manager, banner management, and weblink management to attract more customers online.

                          </span>

                  </div>

                </div>                

              </div>      

             

            </div>

          </div>

        </div>

      </div>

    </section>

<!-- --------technology use ends--------- -->



<!-- Recent work -->

<section class="recentwork-section cmi-recent">

  <div class="container">

    <div class="title">

      <h5>Some of our work that impacts clients' business</h5>

      <h2>E-commerce Development

        <a href="" class="typewrite" data-period="2000" data-type='[  "Recent Works" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row recentworkRow">

      <div class="col-md-3 col-sm-6">

        <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/vkng-shopify.png" class="responsive">

            <div class="recentworkContent">

                  <h4>VKNG Jewelry</h4>

                  <span class="sub-head">France based jewellery E-commerce store Shopify website design and development.

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

        <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/carresol-parquet-prestashop.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Carresol Parquet</h4>

                  <span class="sub-head">France based residential interior business E-commerce PrestaShop store design and development.

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

       <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/braneloshop-shopify.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Branelo Shop</h4>

                  <span class="sub-head">France based multi-product e-commerce Shopify store design and development.                  

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

        <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/ajhome-prestashop.png" class="responsive">

            <div class="recentworkContent">

                  <h4>AJ Homes</h4>

                  <span class="sub-head">France based brand for lawn accessories store design and development on Prestashop.

                  </span>

            </div>

          </div>

        </a>

      </div>

    </div>

  </div>

</section>

<!-- Recent work end-->



<!-- --------why choose--------- -->

<section class="webflow-platform expertise-section ecome-page" >

      <div class="container">

        <div class="row">

          <div class="title">

            <h2>Why To Choose Start Designs for 

              <a href="" class="typewrite" data-period="2000" data-type='[  "Ecommerce Development " ]'> 

              </a>

            </h2>            

          </div>

          <div class="alignitemcenter">



                      <div class="col-md-6">

                <div class="mainservicetopbanner">                  

                  <!-- <h2>PHP Environments & Libraries</h2> -->                 

                  

                <div class="expertise-list">

                <div>

                   <div class="advantage-icon">

                    <img src="images/experience-pro.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                     <p class="advantage-text-head">500+ Project Experience</p>

                     <p class="advantage-text-data">Our team of dedicated eCommerce developers completed over 500 projects using almost every 

                      technology successfully in past years. We have experience of working with international customers from USA, UK, France, and more.</p>

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <img src="images/communicton.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                    <p class="advantage-text-head">Supreme Communication</p>

                     <p class="advantage-text-data">As we have clients all over the globe, Our experience improves with the time and now we are highly 

                      professional in communicate with our clients. That opens more opportunities for us.</p>

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <img src="images/agreement1.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                    <p class="advantage-text-head">Non Disclosure Agreement (NDA) Policy</p>

                     <p class="advantage-text-data">We are strictly concern about our client data, we make it confidential to provide more securities to 

                      our customers. We always follow the NDA policy.</p>

                  </div>

                </div>              

                

                  </div>

                </div>

          </div>



          <div class="col-md-6">

            <div class="mainservicetopbanner">                  

                  <!-- <h2>PHP Environments & Libraries</h2> -->                 

                  

                <div class="expertise-list">

                <div>

                   <div class="advantage-icon">

                    <img src="images/delivery-time.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                     <p class="advantage-text-head">On-time Delivery</p>

                     <p class="advantage-text-data">While we having a team of highly professional developers and experts we able to deliver projects on time. Without any comprise in the quality of products and services. We do bug-free codding.</p>

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <img src="images/customer-service.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                    <p class="advantage-text-head">Customer Support</p>

                     <p class="advantage-text-data">As an emerging eCommerce web designing company, we ensure to provides 24x7 customer support. We help 

                      clients to make familiar about using CMS, which we use to build an eCommerce website.</p>

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <img src="images/seocc.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                    <p class="advantage-text-head">Transparency</p>

                     <p class="advantage-text-data">We are transparent while dealing and working with customers. We listen to our customers. We are truthful 

                      and accurate about work and suggest the best to clients.</p>

                  </div>

                </div>              

                

                  </div>

                </div>

              </div>

        </div>

        </div>

      </div>

    </section>

<!-- end-->



<!-- --------Technological Aids--------- -->

    <section class="use-technological bg-gray-white tech-use-dev dev-tech-2">

      <div class="container">

        <div class="title">

          <h2>Our  Developers Use Best 

            <a href="" class="typewrite" data-period="2000" data-type='[  " Technological Aids" ]'> 

            </a>

          </h2>

        </div>

        <div class="technological-box">

          <a href="#" class="spc-bt-30">

            <img src="images/drop-box.png">

          </a>

          <a href="#" class="spc-bt-30">

            <img src="images/github.png">

          </a>

          <a href="#" class="spc-bt-30">

            <img src="images/trello.png">

          </a>

          <a href="#" class="spc-bt-30">

            <img src="images/slack.png">

          </a>

          <a href="#" class="spc-bt-15-md">

            <img src="images/xjira.png">

          </a>

          <a href="#" class="spc-bt-15-md">

            <img src="images/bugzila.png">

          </a>

          <a href="#" class="spc-bt-15-md">

            <img src="images/Evernote.png">

          </a>

          <a href="#" class="spc-bt-15-md">

            <img src="images/gitlab.png">

          </a>

        </div>

      </div>

    </section>

  <!-- --------Technological Aids ends--------- -->



    <!-- hire start -->

    <section class="about-reactjs web3-benefit ecome-page">

      <div class="container">



        <div class="row row-waffer">          

          <div class="col-md-6 web3-contents">    

          <h2>Hire <span class="web-theme-color">E-commerce Developer</span></h2>           

            <p class="para">Hire Start Designs for developing the best E-commerce platform which will yield maximum sales. We have made several 

              e-commerce websites over the year which are performing well inthe market, we used open source CMS like Drupal, Magento and 

              WordPress. You can <a href="https://www.startdesigns.com/hire-magento-developer.php" class="web-theme-color">Hire Magento Developer</a>, WordPress Expert, Drupal Developer on an hourly, weekly and monthly basis. We also provide advisory services for marketing, increasing sales, and managing online presence. Hiring start designs will give you the best e-commerce website and support in a cost-effective manner.                

            </p>



            <div class="dflex">

                <a href="#" class="btn btn-contactsupport" id="projectmodel" data-toggle="modal" data-target="#startproject">Start Project →</a>

            </div>                                   

          </div>



          <div class="col-md-6">

              <div class="img_outer">

                <div class="reactleftimages">

                  <img src="images/ecoomerceimg.png" class="responsive web-smal floating" alt="image">

                </div>

              </div>                

          </div>

        </div>

      </div>

    </section>

    <!-- hire start -->



 

<!-- Expert review -->

  <section class="section-testimonials reveiw_slide">

      <div class="container">

        <div class="row">

          <div class="title">

            <h3>Testimony from our happy clients</h3>

            <h2>What do client say about 

              <a href="" class="typewrite" data-period="2000" data-type='[  "E-commerce Expert" ]'> 

              </a>

            </h2>

          </div>

        </div>

       

        <div id="review-slider" class="owl-carousel">

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn16.png" alt="">

                  <div class="user-details-services">

                    <h4>K. Anderson</h4>

                    <p>AJ Homes</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "I was amazed at the quality of E-commerce development services. Definitely worth the investment. We were treated like royalty. "

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn26.png" alt="">

                  <div class="user-details-services">

                    <h4>Béatrice</h4>

                    <p>Carresol Parquet</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "StartDesigns is worth much more than I paid. Not able to tell you how happy I am with E-commerce development services by StartDesigns.  "

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn9.png" alt="">

                  <div class="user-details-services">

                    <h4>Travis P.</h4>

                    <p>VKNG Jewelry</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "Start designs produced a great solution to a very complicated E-commerce website development in a very cost-effective manner."

                </p>

              </div>

            </div>

          </div>

        </div>        



      </div>

    </section>

<!-- Expert review end -->





<!--#include file="footer.shtml"-->

    <a href="javascript:" id="return-to-top">

      <i class="fa fa-angle-double-up  " aria-hidden="true">

      </i>

    </a>



<?php include('footer.php'); ?>



<script type="text/javascript" src="js/jquery.js">

</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js">

</script>

<script src="js/jquery.countup.js">

</script>

<script>

$('.counter').countUp();

</script>

<!-- <script src="js/bootstrap.min.js">

</script> -->

<script src="js/owl.carousel.min.js" defer>

</script>

<script src="js/script.js">

</script>

<script src="js/jquery-1.11.1.min.js">

</script>

<script src="js/jquery.validate.min.js">

</script>

<script src="js/additional-methods.min.js">

</script>

<script src="js/slick.min.js" defer>

</script>









<!-- ----------testimony slider------- -->

<script>

$(document).ready(function(){

    $('#review-slider').owlCarousel({

  loop: true,

  margin: 10,

  nav: false,  

  autoplay: true,

  autoplayHoverPause: true,

  responsive: {

    0: {

      items: 1

    },

    767: {

      items: 1

    },

    1000: {

      items: 1

    }

  }

})

  })

</script>



<script>

  $(document).ready(function(){

    $('#whychoose-slider').owlCarousel({

  loop: true,

  margin: 10,

  nav: false,  

  autoplay: true,

  autoplayHoverPause: true,

  responsive: {

    0: {

      items: 1

    },

    767: {

      items: 2

    },

    1000: {

      items: 4

    }

  }

})

  })

</script>



</body>

</html>

