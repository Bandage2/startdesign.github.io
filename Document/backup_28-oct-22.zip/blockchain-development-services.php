 <?php include('header.php'); ?>

<!--#include file="header.shtml"-->

          <div class="no-touch m-nav-menusocial">

            <div id="menusocial" class="menu--social1">

              <div class="toggle--social">

                <span class="soundspeaker-icon">

                </span>

              </div>

              <ul class="menu--sub">

                <li class="menu__item--facebook"> 

                  <a target="_blank" itemprop="samAs" class="menu-link sub-menu-link social_event_track_cls" data-title="Facebook" href="#">

                    <i>

                    </i>HB on Facebook

                  </a> 

                </li>

                <li class="menu__item--twitter"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Twitter" href="#">

                    <i>

                    </i> HB on Twitter 

                  </a> 

                </li>

                <li class="menu__item--linkdin"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="LinkedIn" href="#">

                    <i>

                    </i>HB on Linkedin

                  </a> 

                </li>

                <li class="menu__item--google-p"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Google Plus" href="#">

                    <i>

                    </i>HB on Google+

                  </a> 

                </li>

                <li class="menu__item--youtube"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="You Tube" href="#">

                    <i>

                    </i>HB on Youtube

                  </a> 

                </li>

                <li class="menu__item--blog"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Blog" href="#">

                    <i>

                    </i>HB on Blog

                  </a> 

                </li>

              </ul>

            </div>

          </div>

        </div>

        <div id="top-container" style="display:none;">

          <div class="centerdiv">

            <div class="left"> 

              <a href="#" title=""> 

                <img src="images/logo.png" width="261" height="51" alt="" class="logo" /> 

              </a> 

            </div>

            <div class="right" style="width:72%;">

              <div class="r-clear menu-display">

                <div class="search-div">

                  <input type="search" placeholder="Search" name="" />

                </div>

                <span class="link-area">

                  <a target="_blank" title="" href="#">Blog

                  </a>

                  <a title="" href="#" target="_blank">Articles

                  </a>

                  <a title="" href="#">FAQ

                  </a>

                  <a title="" href="#">Careers

                  </a> 

                  <a title="Contact" href="#">Contact

                  </a> 

                  <a title="" href="#">Partnership

                  </a>

                </span> 

              </div>

              <div class="r-clear topmenu">

                <div class="mobile-tablet-menu">

                  <a href="#" class="mobile-menu-home-iclass" id="mobile-menu-home-icon">

                  </a>

                  <div class="mobile-menu-home-contner" id="mobile-menu-home">

                    <ul>

                      <li>

                        <a title="Company" href="#">Company

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Services

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Technology

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Products

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Client

                        </a>

                      </li>

                      <li>

                        <a title="Work" class="work-menu" href="#">Work

                        </a>

                      </li>

                      <li>

                        <a title="Inquiry" href="#" id="inquiry-pop-up" class="active">Get Quote

                        </a>

                      </li>

                    </ul>

                  </div>

                </div>

                <ul class="menu-t-menu-new">

                  <li>

                    <a title="startdesigns InfoTech" href="#">

                      <span class="home">

                      </span>

                    </a> 

                  </li>

                  <li>

                    <a title="Company" href="#">Company

                    </a> 

                  </li>

                  <li>

                    <a title="Services" href="#">Services

                    </a> 

                  </li>

                  <li>

                    <a title="Technology" href="#">Technology

                    </a> 

                  </li>

                  <li>

                    <a href="#">Products

                    </a> 

                  </li>

                  <li>

                    <a title="Work" href="#">Work

                    </a> 

                  </li>

                  <li>

                    <a title="Inquiry" href="#">Get Quote

                    </a> 

                  </li>

                </ul>

              </div>

            </div>

          </div>

        </div>

      </div>

    </header>





    <section class="service-topbanner phpbannerbg">

      <div class="container">

          <div class="row service-flex">

              <div class="col-md-6">

                <div class="mainservicetopbanner">

                  <h3>DAML Development Services</h3>

                  <h1 class="wordpress_head">Professional DAML Development Services </h1>                 

                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.  </p>

                  <div class="dflex">

                    <a href="#foooter_form" class="btn btn-contactsupport">Contact Support →</a>

                    <a href="#" class="btn btn-startproject" id="projectmodel" data-toggle="modal" data-target="#startproject">Start Project →</a>                    

                  </div>                  

                </div>

              </div>

              <div class="col-md-6">

                <div class="rightside-topbanner wpbanner-top">

                  <img src="images/php_web_development.svg">

                </div>

              </div>

          </div>

      </div>

    </section>



<section class="developmnt_services php_page">

  <div class="container">

    <div class="row">

      <div class="developmnt_services_box">

        <div class="service_box_data">

          <div class="dev_service_icon"><img src="images/devops.svg"></div>

          <p>DAML Service</p>

        </div>



        <div class="service_box_data">

          <div class="dev_service_icon"><img src="images/server.svg"></div>

          <p>DAML Service</p>

        </div>



        <div class="service_box_data">

          <div class="dev_service_icon"><img src="images/ux-ui.svg"></div>

          <p>DAML Service</p>

        </div>



        <div class="service_box_data">

          <div class="dev_service_icon"><img src="images/quick.svg"></div>

          <p>DAML Service</p>

        </div>



        <div class="service_box_data">

          <div class="dev_service_icon"><img src="images/comptent.svg"></div>

          <p>DAML Service</p>

        </div>

        

      </div>

    </div>

  </div>

</section>



    <!-- Php Features -->

<section class="webflowfeatures_services php_solutions">

  <div class="container">

    <div class="title">

      <h3>We have a team of skilled and experienced DAML developers to provide </h3>

      <h2>A Wide Range of Our Cutting-edge

        <a href="" class="typewrite" data-period="2000" data-type='[  "DAML Development Solutions" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row weoffer-row1">

      <div class="col-md-4">
        <div class="damlBox newDml">
          <div class="DamlContent">
            <div class="service_icon"><img src="images/app-ui.png"></div>
            <h4>Daml Smart Contract Development</h4>
            <span class="sub-head">
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
            </span>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="damlBox newDml">
          <div class="DamlContent">
            <div class="service_icon"><img src="images/app-ui.png"></div>
            <h4>Daml Smart Contract Development</h4>
            <span class="sub-head">
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
            </span>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="damlBox newDml">
          <div class="DamlContent">
            <div class="service_icon"><img src="images/app-ui.png"></div>
            <h4>Daml Smart Contract Development</h4>
            <span class="sub-head">
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
            </span>
          </div>
        </div>
      </div>    



    </div>

      <div class="row weoffer-row2">

      <div class="col-md-4">
        <div class="damlBox newDml">
          <div class="DamlContent">
            <div class="service_icon"><img src="images/app-ui.png"></div>
            <h4>Daml Smart Contract Development</h4>
            <span class="sub-head">
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
            </span>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="damlBox newDml">
          <div class="DamlContent">
            <div class="service_icon"><img src="images/app-ui.png"></div>
            <h4>Daml Smart Contract Development</h4>
            <span class="sub-head">
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
            </span>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="damlBox newDml">
          <div class="DamlContent">
            <div class="service_icon"><img src="images/app-ui.png"></div>
            <h4>Daml Smart Contract Development</h4>
            <span class="sub-head">
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
            </span>
          </div>
        </div>
      </div>    

    </div>



  </div>

</section>



<!-- Php features end-->



<!-- --------Advantage of php--------- -->

<section class="section-testimonials testimonials advantage_section php_page">

      <div class="container">

        <div class="row">

          <div class="title">

            <h3>Rendering result-oriented web solutions across the globe</h3>

            <h2>Advantages Of Our 

              <a href="" class="typewrite" data-period="2000" data-type='[  "DAML Development Services" ]'> 

              </a>

            </h2>            

          </div>

        </div>

        <div class="row advantageRow">

          <div class="col-md-3 advantageBox newDml">
              <div class="advantageImg">
                <img src="images/responsivedesign.jpg" alt="img">       
              </div>
              <div class="advantageContent">
                  <h4>Title</h4>
                  <span class="sub-head">
                  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                  </span>
              </div>
          </div>

          <div class="col-md-3 advantageBox newDml">
              <div class="advantageImg">
                <img src="images/responsivedesign.jpg" alt="img">       
              </div>
              <div class="advantageContent">
                  <h4>Title</h4>
                  <span class="sub-head">
                  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                  </span>
              </div>
          </div>

          <div class="col-md-3 advantageBox newDml">
              <div class="advantageImg">
                <img src="images/responsivedesign.jpg" alt="img">       
              </div>
              <div class="advantageContent">
                  <h4>Title</h4>
                  <span class="sub-head">
                  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                  </span>
              </div>
          </div>

          <div class="col-md-3 advantageBox newDml">
              <div class="advantageImg">
                <img src="images/responsivedesign.jpg" alt="img">       
              </div>
              <div class="advantageContent">
                  <h4>Title</h4>
                  <span class="sub-head">
                  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                  </span>
              </div>
          </div>

      </div>
      </div>
    </section>

<!-- --------End advantage of php--------- -->




<!-- Recent work -->

<section class="recentwork-section cmi-recent php_page">

  <div class="container">

    <div class="title">

      <h3>Pour a brew and peruse our goods</h3>

      <h2>DAML Development

        <a href="" class="typewrite" data-period="2000" data-type='[  "Recent Works" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row recentworkRow">

      <div class="col-md-3 col-sm-6">
        <a class="recentworkBox">
          <div class="recentworkImg">
            <img src="images/vacationsbyrail.png" class="responsive">
            <div class="recentworkContent">
                  <h4>What is Lorem Ipsum?</h4>
                  <span class="sub-head">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                  </span>
            </div>
          </div>
        </a>
      </div>

      <div class="col-md-3 col-sm-6">

        <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/networkadvertising.png" class="responsive">

            <div class="recentworkContent">
                  <h4>What is Lorem Ipsum?</h4>
                  <span class="sub-head">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                  </span>
            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

       <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/nomorobo.png" class="responsive">

            <div class="recentworkContent">
                  <h4>What is Lorem Ipsum?</h4>
                  <span class="sub-head">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                  </span>
            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

        <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/technicpack.png" class="responsive">

            <div class="recentworkContent">
                  <h4>What is Lorem Ipsum?</h4>
                  <span class="sub-head">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                  </span>
            </div>

          </div>

        </a>

      </div>

    </div>

  </div>

</section>



<!-- Recent work end-->



 

<!-- Expert review -->

  <section class="section-testimonials reveiw_slide php_page">

      <div class="container">

        <div class="row">

          <div class="title">

            <h3>Testimony From Our Happy Clients</h3>

            <h2>What do client say about 

              <a href="" class="typewrite" data-period="2000" data-type='[  "DAML Expert" ]'> 

              </a>

            </h2>

          </div>

        </div>

       

        <div id="review-slider" class="owl-carousel">

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn2.png" alt="">

                  <div class="user-details-services">

                    <h4>James Smith</h4>

                    <p>Nomorobo</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "Start designs produced a great solution to a very complicated PHP problems in a very cost-effective manner."

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn7.png" alt="">

                  <div class="user-details-services">

                    <h4>Maria Garcia</h4>

                    <p>Technic pack</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "Wow what great service, I love it! Needless to say, we are extremely satisfied with the results. PHP website is both attractive and highly adaptable."

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn14.png" alt="">

                  <div class="user-details-services">

                    <h4>Samuel</h4>

                    <p>Network Advertising</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "StartDesigns did exactly what you said it does. I have gotten at least 50 times the value from your PHP website development service."

                </p>

              </div>

            </div>

          </div>

        </div>        



      </div>

    </section>

<!-- Expert review end -->



<!-- FAQ Ui -->

<section class="webflowfeatures_services php_page">

  <div class="container">

    <div class="title">

      <h3>Got questions? We've got answers!</h3>

      <h2>FAQ's 

        <a href="" class="typewrite" data-period="2000" data-type='[  "Frequently Asked Questions" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row">

      <div class="col-md-8 col-md-offset-2 faq-main-parent">

          <button class="accordion-faq">What are the technologies or PHP frameworks in which your developers have expertise?</button>

          <div class="panel-faq">

            <p>At StartDesigns, we have a team of developers with 50+ collective experience and expertise to use Laravel, Symfony, CakePHP, Zend Framework, Docker, PHP Unit, Phalcon, Codeigniter, Yii, and Fule PHP.</p>

          </div>



          <button class="accordion-faq">What are different PHP development solutions do you offer?</button>

          <div class="panel-faq">

            <p>We have been providing a wide range of PHP development solutions since 2015. We provide custom PHP development, CMS development, E-commerce development, API development, SaaS development, and maintenance support solutions.</p>

          </div>



          <button class="accordion-faq">Can you help to redesign or redevelop the existing website with the latest PHP version?</button>

          <div class="panel-faq">

            <p>Yes, we offer redesign and development services for existing PHP-based websites. Redevelopment of existing websites boosts performance, functionality, credibility, and security level.</p>

          </div>



          <button class="accordion-faq">Will you provide support after the completion of the project?</button>

          <div class="panel-faq">

            <p>Yes, we provide support after the completion of the project. Our PHP developers make the required changes related to site appearance, content, and layout. We advise you to discuss all project requirements, scope, and other elements.</p>

          </div>

      </div>

    </div>

      



  </div>

</section>



<!-- FAQ Ui end-->



<!--#include file="footer.shtml"-->

    <a href="javascript:" id="return-to-top">

      <i class="fa fa-angle-double-up  " aria-hidden="true">

      </i>

    </a>



<?php include('footer.php'); ?>



<script type="text/javascript" src="js/jquery.js">

</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js">

</script>

<script src="js/jquery.countup.js">

</script>

<script>

$('.counter').countUp();

</script>

<!-- <script src="js/bootstrap.min.js">

</script> -->

<script src="js/owl.carousel.min.js" defer>

</script>

<script src="js/script.js">

</script>

<script src="js/jquery-1.11.1.min.js">

</script>

<script src="js/jquery.validate.min.js">

</script>

<script src="js/additional-methods.min.js">

</script>

<script src="js/slick.min.js" defer>

</script>



<script>

  $(document).ready(function(){

    $('#whychoose-slider').owlCarousel({

  loop: true,

  margin: 10,

  nav: false,  

  autoplay: true,

  autoplayHoverPause: true,

  responsive: {

    0: {

      items: 1

    },

    767: {

      items: 2

    },

    1000: {

      items: 3

    }

  }

})

  })



$(document).ready(function(){

    $('#review-slider').owlCarousel({

  loop: true,

  margin: 10,

  nav: false,  

  autoplay: true,

  autoplayHoverPause: true,

  responsive: {

    0: {

      items: 1

    },

    767: {

      items: 1

    },

    1000: {

      items: 1

    }

  }

})

  })

</script>





</body>

</html>

