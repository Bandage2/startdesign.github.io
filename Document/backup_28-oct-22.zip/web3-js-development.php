 <?php include('header.php'); ?>

<!--#include file="header.shtml"-->

          <div class="no-touch m-nav-menusocial">

            <div id="menusocial" class="menu--social1">

              <div class="toggle--social">

                <span class="soundspeaker-icon">

                </span>

              </div>

              <ul class="menu--sub">

                <li class="menu__item--facebook"> 

                  <a target="_blank" itemprop="samAs" class="menu-link sub-menu-link social_event_track_cls" data-title="Facebook" href="#">

                    <i>

                    </i>HB on Facebook

                  </a> 

                </li>

                <li class="menu__item--twitter"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Twitter" href="#">

                    <i>

                    </i> HB on Twitter 

                  </a> 

                </li>

                <li class="menu__item--linkdin"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="LinkedIn" href="#">

                    <i>

                    </i>HB on Linkedin

                  </a> 

                </li>

                <li class="menu__item--google-p"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Google Plus" href="#">

                    <i>

                    </i>HB on Google+

                  </a> 

                </li>

                <li class="menu__item--youtube"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="You Tube" href="#">

                    <i>

                    </i>HB on Youtube

                  </a> 

                </li>

                <li class="menu__item--blog"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Blog" href="#">

                    <i>

                    </i>HB on Blog

                  </a> 

                </li>

              </ul>

            </div>

          </div>

        </div>

        <div id="top-container" style="display:none;">

          <div class="centerdiv">

            <div class="left"> 

              <a href="#" title=""> 

                <img src="images/logo.png" width="261" height="51" alt="" class="logo" /> 

              </a> 

            </div>

            <div class="right" style="width:72%;">

              <div class="r-clear menu-display">

                <div class="search-div">

                  <input type="search" placeholder="Search" name="" />

                </div>

                <span class="link-area">

                  <a target="_blank" title="" href="#">Blog

                  </a>

                  <a title="" href="#" target="_blank">Articles

                  </a>

                  <a title="" href="#">FAQ

                  </a>

                  <a title="" href="#">Careers

                  </a> 

                  <a title="Contact" href="#">Contact

                  </a> 

                  <a title="" href="#">Partnership

                  </a>

                </span> 

              </div>

              <div class="r-clear topmenu">

                <div class="mobile-tablet-menu">

                  <a href="#" class="mobile-menu-home-iclass" id="mobile-menu-home-icon">

                  </a>

                  <div class="mobile-menu-home-contner" id="mobile-menu-home">

                    <ul>

                      <li>

                        <a title="Company" href="#">Company

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Services

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Technology

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Products

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Client

                        </a>

                      </li>

                      <li>

                        <a title="Work" class="work-menu" href="#">Work

                        </a>

                      </li>

                      <li>

                        <a title="Inquiry" href="#" id="inquiry-pop-up" class="active">Get Quote

                        </a>

                      </li>

                    </ul>

                  </div>

                </div>

                <ul class="menu-t-menu-new">

                  <li>

                    <a title="startdesigns InfoTech" href="#">

                      <span class="home">

                      </span>

                    </a> 

                  </li>

                  <li>

                    <a title="Company" href="#">Company

                    </a> 

                  </li>

                  <li>

                    <a title="Services" href="#">Services

                    </a> 

                  </li>

                  <li>

                    <a title="Technology" href="#">Technology

                    </a> 

                  </li>

                  <li>

                    <a href="#">Products

                    </a> 

                  </li>

                  <li>

                    <a title="Work" href="#">Work

                    </a> 

                  </li>

                  <li>

                    <a title="Inquiry" href="#">Get Quote

                    </a> 

                  </li>

                </ul>

              </div>

            </div>

          </div>

        </div>

      </div>

    </header>



    <!-- Banner top- contact end -->



    <section class="service-topbanner webbannerbg">

      <!-- <div style="background-image: url(images/webbackgroundimg.png);"> -->

      <div class="container">

          <div class="row service-flex">

              <div class="col-md-6">

                <div class="mainservicetopbanner">

                  <h3>Hire Web3.JS Developer</h3>

                  <h1 class="wordpress_head">Web3.JS Development Services</h1>

                  <p>Hire a web3.js developer from the best blockchain development services in USA. We have a team of skilled web3.js developers that are able to design and develop Dapps, Smart contracts, Blockchain apps, and much more.</p>

                  <div class="dflex">

                    <a href="#foooter_form" class="btn btn-contactsupport">Contact Support →</a>

                    <a href="#" class="btn btn-startproject" id="projectmodel" data-toggle="modal" data-target="#startproject">Start Project →</a>

                  </div>                  

                </div>

              </div>

              <div class="col-md-6">

                <div class="rightside-topbanner wpbanner-top">

                  <img src="images/web3banner.png" alt="banner-img">

                </div>

              </div>

          </div>

      </div>

      <!-- </div> -->

    </section>





        <!-- About Web3JS start -->

    <section class="about-reactjs web3-page">

      <div class="container">

        <!-- <div class="title">    

          <h3>Creating Dapps applications with Web3.JS</h3>  

          <h2>What is

            <a href="" class="typewrite" data-period="2000" data-type='[  "Web3.JS Development? " ]'> 

            </a>

          </h2>

        </div> -->



        <div class="row row-waffer">            



          <div class="col-md-6 web3-contents">     

          <h2>What is <span class="web-theme-color">Web3.JS?</span></h2>       

            <p class="para">Web3.js is a collection of libraries that allow users to interact with Ethereum nodes and blockchain through HTTP, Interprocess Communication (IPC), and Web Socket. Web3.js uses JavaScript Object Notation — Remote Procedure Call (JSON-RPC) protocol to communicate with the Ethereum blockchain.  

            A Web3.js Ethereum blockchain developer builds websites that interact with the blockchain and code to read and write data from the Ethereum blockchain with smart contracts. It helps to perform actions:                

            </p>



            <div class="advantages-hiring-list">

                <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                     Ether transaction peer-to-peer

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                    Interact via a web browser 

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                    Check balance 

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                    Create smart contracts 

                  </div>

                </div>              

              </div>                                   

          </div>



          <div class="col-md-6">

              <div class="img_outer">

                <div class="reactleftimages">

                  <img src="images/web3imgr.png" class="responsive web-smal floating" alt="image">

                </div>

              </div>                

          </div>

        </div>

      </div>

    </section>

    <!-- About Web3js ends -->



<!-- How Web3JS work start -->

<section class="web3work-section">

  <div class="container">

    <div class="title">      

      <h2>How Web3.JS

        <a href="" class="typewrite" data-period="2000" data-type='[  "Works?" ]'> 

        </a>

      </h2>

    </div>



    <div class="webwork-para">When clients want to interact with the Ethereum network through a browser, they need decentralized apps(Dapp ) that send commands to the Ethereum nodes to read and write data from Ethereum blockchain servers. Display back perform actions on the clients' screen. These web apps run on the clients' browsers so that users can perform specific tasks such as transfer data, check balance, value through intuitive UI and UX.

	Our web3.js developers redesign and develop the Dapps, Smart contracts, enhance UX/UI, blockchain applications, and more.

	</div>

    <div class="webwork-images"><img src="images/web3-process.png" alt="image"></div>

    <div class="webwork-para1">The process starts when the user tries to interact with the blockchain network through web apps. Users send the command through the frontend apps using HTTP, Interprocess Communication (IPC), and Web Socket. Web3.js developers make web apps based on JavaScript. These client-side apps can't directly interact with the Ethereum nodes. To interact with the Ethereum node these Javascript codes are converted to JSON-RPC requests by the Web3.js provider. After performing the changes that the user wants, it processes back to display successful completion of tasks. Our web3.js developers create highly intuitive and user-friendly front-end designs using web3.js technology.</div>

  </div>

</section>

<!-- How Web3JS work ends -->



    <!-- Web3js services partner -->

<section class="webflowfeatures_services web3-page">

  <div class="container">

    <div class="title">      

      <h2>The Expertise of our 

        <a href="" class="typewrite" data-period="2000" data-type='[  "Web3.JS Developer" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row weoffer-row1">

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/integration-color.png"></div>              

            </div>

            <h4>Build Ethereum DApps</h4>

            <span class="sub-head">We are emerging blockchain development services to power your business with the latest blockchain development technology. Our web3.js developers build robust Dapps for users to interact with the Ethereum blockchain.

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/currency-exchange.png"></div>             

            </div>

             <h4>Crypto Exchange/Swapping</h4>

            <span class="sub-head">Our blockchain developers build applications that allow users to exchange cryptocurrency flawlessly. Users can swap Bitcoin, Cardano (ADA), Binance coin (BNB), Solana, and more other cryptocurrencies to Ethereum using web apps developed by us.

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/app-color.png"></div>              

            </div>

            <h4>Create NFT </h4>

            <span class="sub-head">We have a team of developers that write and deploy the Ethereum NFTs. NFT stands for a non-fungible token that Ethereum allows you to create for example NFT furniture, song files, or your computers. Our developers are skilled enough to create NFTs for any business. 

            </span>

          </div>

        </div>

      </div>     



    </div>

      <div class="row weoffer-row2">

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/ethereum.png"></div>              

            </div>

            <h4>Create Ethereum Wallet</h4>

            <span class="sub-head">We have blockchain developers that build Ethereum wallet applications with advanced UX/UI. Through the Ethereum wallet, users can read balances, send transactions and connect to applications. Hire a web3.js developer today for a complete solution. 

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/coin.png"></div>             

            </div>

             <h4>UX Solution for Blockchain</h4>

            <span class="sub-head">We offer complete UX solutions for blockchain platforms. We have the expertise to design and develop highly intuitive front-end for blockchain applications so users can interact flawlessly. You can hire blockchain developers for the cutting-edge solution. 

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

           <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/drupal4.png"></div>              

            </div>

            <h4>Blockchain Technology Consultation</h4>

            <span class="sub-head">Blockchain technology, almost every business adopting it because of its data security, globalization, faster transactions, transparency, and other unique features. We are helping businesses to keep ahead of competitors using blockchain technology. 

            </span>

          </div>

        </div>

      </div>      

    </div>



  </div>

</section>

<!-- Web3js services Ends--->



<!-- ---------Case studies start---------- -->

<!-- <section class="drupal_expertise web3_casestudy">

  <div class="container">

    <div class="title">          

        <h2>Case 

          <a href="" class="typewrite" data-period="2000" data-type='[  "Studies" ]'> 

          </a> 

        </h2>

    </div>

    <div class="row">

      <div class="col-md-12">

        <div class="owl-slider">

          <div id="expertisecarousel" class="owl-carousel">



            <div class="item row slide-one">

              <div class="col-md-5 drupal-left-expertise ">

                <div>

                  <h3>Case Study 1</h3>

                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.

                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.

                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.

                  </p>

                </div>

              </div>



              <div class="col-md-7 drupal-right-expertise expertise1">

                <img src="images/image 5.svg">

              </div>              

            </div>



            <div class="item row slide-two">

              <div class="col-md-5 drupal-left-expertise ">

                <h3>Case Study 2</h3>

                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.

                  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.

                  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.

                </p>

              </div>



              <div class="col-md-7 drupal-right-expertise expertise2">

                <img src="images/image 5.svg">

              </div>              

            </div>



            <div class="item row slide-three">

              <div class="col-md-5 drupal-left-expertise">

                <h3>Case Study 3</h3>

                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.

                  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.

                  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.

                </p>

              </div>



              <div class="col-md-7 drupal-right-expertise expertise3">

                <img src="images/image 5.svg">

              </div>              

            </div>



          </div>

        </div>

      </div>

  </div>

</section> -->

<!-- ---------Case studies ends---------- -->



  <!-- Benefit Web3JS start -->

    <section class="about-reactjs web3-benefit bg-gray-white">

      <div class="container">

        <!-- <div class="title">   

          <h2>Benefits Of

            <a href="" class="typewrite" data-period="2000" data-type='[  "Web3.JS" ]'> 

            </a>

          </h2>

        </div> -->



        <div class="row row-waffer">           



          <div class="col-md-6 web3-contents">    

          <h2>Benefits Of <span class="web-theme-color">Web3.JS?</span></h2>           

            <p class="para">Web3.js has several advantages while developing the front-end of the decentralized application that allows users to interact through the web browser and web socket. Dapps made with web3.js are fully functional, intuitive UI/UX, convenient, easy to use, interactive, and dynamic. Web3.js allows programmers to interact with these on-chain components efficiently. Help a connection to Ethereum nodes, using HTTP or IPC connections. Numerous Web3 developers have elected to create DApps because of Ethereum's inherent decentralization:                

            </p>



            <div class="advantages-hiring-list">

                <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                     For anyone who uses the service within the network, permission isn't required. 

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                    No one can stop you or refuse you access to the service. 

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                    Payments are built-in through the native token.

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                    Ethereum is Turing-complete, meaning you can program anything. 

                  </div>

                </div>              

              </div>                                   

          </div>



          <div class="col-md-6">

              <div class="img_outer">

                <div class="reactleftimages">

                  <img src="images/web3imgsB.png" class="responsive web-smal floating" alt="image">

                </div>

              </div>                

          </div>

        </div>

      </div>

    </section>

  <!-- Benefit Web3js ends -->



<!-- Why us Web3js Development partner  -->

  <section class="stripe_advantge web3-page bg-white">

    <div class="container">

        <div class="title">

          <!-- <h3>We build beautiful Webflow websites that engage your audience.</h3> -->

          <h2>Why We Are Reliable 

            <a href="" class="typewrite" data-period="2000" data-type='[  "Web3.JS Development Partners? " ]'> 

            </a>

          </h2>

        </div>         

              <div class="row service-flex"> 



                  <div class="col-md-6">

                  <div class="img_outer">

                    <div class="cmileftimages">

                      <img src="images/web3imgl.png" class="responsive web-smal floating" alt="image">

                    </div>

                  </div>                

                  </div>



                  <div class="col-md-6">

                    <div class="mainservicetopbanner features-title">

                      <!-- <h3>We used best strategy</h3> -->

                      <h2>We are reliable web3.js development services</h2>

                      <div class="advantages-hiring-list">

                    <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                         We have experienced in-house blockchain development experts for complete blockchain development.

                      </div>

                    </div>

                     <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                        Our blockchain developers have experience of 5+ web development in more than 10 industries.

                      </div>

                    </div>

                     <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                        We have expertise in UI and UX design. We create user-friendly blockchain products.

                      </div>

                    </div>    

                     <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                        We have delivered over 20+ web3.js development projects for our worldwide clients.

                      </div>

                    </div> 

                     <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                        We are specialists in the latest blockchain technology like Ethereum, Solana, BitGo, and Hyperledger.

                      </div>

                    </div> 

                     <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                        Our web3.js developers are skilled, professional, experienced, and problem-solving proficient.

                      </div>

                    </div>           

                  </div>                      

                      <!-- <div class="dflex">

                        <a href="#" class="btn btn-contactsupport btn-mrgn-top">Start a Project</a>

                      </div> -->

                    </div>

                  </div>  

                                              

              </div>             

    </div>

  </section>

    <!-- Why us Vuejs Developmentr ends -->





<!-- Expert review -->

  <section class="section-testimonials reveiw_slide web3-page bg-gray-white">

      <div class="container">

        <div class="row">

          <div class="title">

            <h3>Testimony from our happy clients</h3>

            <h2>What do client say about 

              <a href="" class="typewrite" data-period="2000" data-type='[  "Web3.JS Expert" ]'> 

              </a>

            </h2>

          </div>

        </div>

       

        <div id="review-slider" class="owl-carousel">

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn16.png" alt="">

                  <div class="user-details-services">

                    <h4>John Doe</h4>

                    <p>Dream Cash</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "Start designs produced a great solution to a very complicated mobile app in a very cost-effective manner."

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn26.png" alt="">

                  <div class="user-details-services">

                    <h4>Selina W.</h4>

                    <p>Dray</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "Start designs produced a great solution to a very complicated mobile app in a very cost-effective manner."

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn9.png" alt="">

                  <div class="user-details-services">

                    <h4>Jhon Thomas</h4>

                    <p>Carresol</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "Start designs produced a great solution to a very complicated mobile app in a very cost-effective manner."

                </p>

              </div>

            </div>

          </div>

        </div>        



      </div>

    </section>

<!-- Expert review end -->





<!-- FAQ Ui -->

<section class="webflowfeatures_services">

  <div class="container">

    <div class="title">

      <h3>Got questions? We've got answers!</h3>

      <h2>FAQ's 

        <a href="" class="typewrite" data-period="2000" data-type='[  "Frequently Asked Questions" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row">

      <div class="col-md-8 col-md-offset-2 faq-main-parent">

          <button class="accordion-faq">How do I hire a Web3.js Developer?</button>

          <div class="panel-faq">

            <p>At StartDesigns, it's very simple to hire web3.js developers. You can contact us through the simple contact form or you can contact us through the mobile number on the website or even through live chat.</p>

          </div>



          <button class="accordion-faq">What is the standard cost to hire a Web3.js programmer?</button>

          <div class="panel-faq">

            <p>We have flexible pricing modules to choose from. You can hire a dedicated web3.js programmer for hours, days, and projects basis. We offer blockchain development services at a very competitive price.</p>

          </div>



          <button class="accordion-faq">How do we know if your Web3.js programmer is experienced enough?</button>

          <div class="panel-faq">

            <p>Before you choose our web3.js programmer you can see our previous work mentioned on the website. You can directly connect to developers to ask questions in your mind.</p>

          </div>

      </div>

    </div>

      



  </div>

</section>



<!-- FAQ Ui end-->



<!--#include file="footer.shtml"-->

    <a href="javascript:" id="return-to-top">

      <i class="fa fa-angle-double-up  " aria-hidden="true">

      </i>

    </a>



<?php include('footer.php'); ?>



<script type="text/javascript" src="js/jquery.js">

</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js">

</script>

<script src="js/jquery.countup.js">

</script>

<script>

$('.counter').countUp();

</script>

<!-- <script src="js/bootstrap.min.js">

</script> -->

<script src="js/owl.carousel.min.js" defer>

</script>

<script src="js/script.js">

</script>

<script src="js/jquery-1.11.1.min.js">

</script>

<script src="js/jquery.validate.min.js">

</script>

<script src="js/additional-methods.min.js">

</script>

<script src="js/slick.min.js" defer>

</script>









<!-- ----------testimony slider------- -->

<script>

$(document).ready(function(){

    $('#review-slider').owlCarousel({

  loop: true,

  margin: 10,

  nav: false,  

  autoplay: true,

  autoplayHoverPause: true,

  responsive: {

    0: {

      items: 1

    },

    767: {

      items: 1

    },

    1000: {

      items: 1

    }

  }

})

  })

</script>



<!-- --------case study slider---- -->

<script >

    $(document).ready(function(){

      $("#expertisecarousel").owlCarousel({

      autoplay: true,

      rewind: true, 

      margin: 20,  

      responsiveClass: true,

      autoHeight: true,

      autoplayTimeout: 7000,

      smartSpeed: 800,

      nav: false,

      responsive: {

        0: {

          items: 1

        },



        600: {

          items: 1

        },



        1024: {

          items: 1

        },



        1366: {

          items: 1

        }

      }

      });

    })

</script>





</body>

</html>

