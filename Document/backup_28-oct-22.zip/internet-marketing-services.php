 <?php include('header.php'); ?>

<!--#include file="header.shtml"-->

          <div class="no-touch m-nav-menusocial">

            <div id="menusocial" class="menu--social1">

              <div class="toggle--social">

                <span class="soundspeaker-icon">

                </span>

              </div>

              <ul class="menu--sub">

                <li class="menu__item--facebook"> 

                  <a target="_blank" itemprop="samAs" class="menu-link sub-menu-link social_event_track_cls" data-title="Facebook" href="#">

                    <i>

                    </i>HB on Facebook

                  </a> 

                </li>

                <li class="menu__item--twitter"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Twitter" href="#">

                    <i>

                    </i> HB on Twitter 

                  </a> 

                </li>

                <li class="menu__item--linkdin"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="LinkedIn" href="#">

                    <i>

                    </i>HB on Linkedin

                  </a> 

                </li>

                <li class="menu__item--google-p"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Google Plus" href="#">

                    <i>

                    </i>HB on Google+

                  </a> 

                </li>

                <li class="menu__item--youtube"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="You Tube" href="#">

                    <i>

                    </i>HB on Youtube

                  </a> 

                </li>

                <li class="menu__item--blog"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Blog" href="#">

                    <i>

                    </i>HB on Blog

                  </a> 

                </li>

              </ul>

            </div>

          </div>

        </div>

        <div id="top-container" style="display:none;">

          <div class="centerdiv">

            <div class="left"> 

              <a href="#" title=""> 

                <img src="images/logo.png" width="261" height="51" alt="" class="logo" /> 

              </a> 

            </div>

            <div class="right" style="width:72%;">

              <div class="r-clear menu-display">

                <div class="search-div">

                  <input type="search" placeholder="Search" name="" />

                </div>

                <span class="link-area">

                  <a target="_blank" title="" href="#">Blog

                  </a>

                  <a title="" href="#" target="_blank">Articles

                  </a>

                  <a title="" href="#">FAQ

                  </a>

                  <a title="" href="#">Careers

                  </a> 

                  <a title="Contact" href="#">Contact

                  </a> 

                  <a title="" href="#">Partnership

                  </a>

                </span> 

              </div>

              <div class="r-clear topmenu">

                <div class="mobile-tablet-menu">

                  <a href="#" class="mobile-menu-home-iclass" id="mobile-menu-home-icon">

                  </a>

                  <div class="mobile-menu-home-contner" id="mobile-menu-home">

                    <ul>

                      <li>

                        <a title="Company" href="#">Company

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Services

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Technology

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Products

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Client

                        </a>

                      </li>

                      <li>

                        <a title="Work" class="work-menu" href="#">Work

                        </a>

                      </li>

                      <li>

                        <a title="Inquiry" href="#" id="inquiry-pop-up" class="active">Get Quote

                        </a>

                      </li>

                    </ul>

                  </div>

                </div>

                <ul class="menu-t-menu-new">

                  <li>

                    <a title="startdesigns InfoTech" href="#">

                      <span class="home">

                      </span>

                    </a> 

                  </li>

                  <li>

                    <a title="Company" href="#">Company

                    </a> 

                  </li>

                  <li>

                    <a title="Services" href="#">Services

                    </a> 

                  </li>

                  <li>

                    <a title="Technology" href="#">Technology

                    </a> 

                  </li>

                  <li>

                    <a href="#">Products

                    </a> 

                  </li>

                  <li>

                    <a title="Work" href="#">Work

                    </a> 

                  </li>

                  <li>

                    <a title="Inquiry" href="#">Get Quote

                    </a> 

                  </li>

                </ul>

              </div>

            </div>

          </div>

        </div>

      </div>

    </header>



    <!-- Banner top- contact end -->



    <section class="service-topbanner imarketbannerbg">      

      <div class="container">

          <div class="row service-flex">

              <div class="col-md-6">

                <div class="mainservicetopbanner">

                  <h3>Internet Marketing Service</h3>

                  <h1 class="wordpress_head">A Result Driven Digital Marketing Services</h1>

                    <p>Start Designs is an emerging web development company. We providing services for web design and development at an 

                    affordable cost. We have an in-house team of experienced and 

                    professional web developers that build your business online using 

                    newly coming technologies.</p>

                  <div class="dflex">

                    <a href="#foooter_form" class="btn btn-contactsupport">Contact Support →</a>

                    <a href="#" class="btn btn-startproject" id="projectmodel" data-toggle="modal" data-target="#startproject">Start Project →</a>

                  </div>                  

                </div>

              </div>

              <div class="col-md-6">

                <div class="rightside-topbanner wpbanner-top">

                  <img src="images/Digital-marketing.png" alt="banner-img">

                </div>

              </div>

          </div>

      </div>     

    </section>





        <!-- About web development  start -->

    <section class="about-reactjs web3-page webdevelop-page bg-gray-white imarket-page">

      <div class="container">

        

        <div class="row row-waffer">           

          <div class="col-md-6">           

            <div class="img_outer">

                <div class="reactleftimages">

                  <img src="images/Social-Medi-Marketing.png" class="responsive web-smal floating imgw-90" alt="image">

                </div>

              </div>

          </div>

          <div class="col-md-6 web3-contents">     

          <h2>Online Marketing Services to Increase Revenue and  

           <span class="web-theme-color">Brand Identity</span></h2>       

            <p class="para">Start Designs, a place for complete digital marketing solutions with expertise. We provide services for Local & International Search Engine Optimization(SEO), Pay-Per-Click(PPC), B2B & B2C Digital Marketing, Branding, Lead Generation, Social Media Optimization(SMO), Social Media Marketing(SMM) and Email Marketing.

            We have a team of Digital Marketing Experts that make an infallible SEO strategy according to your business to reach the business goals. Our digital marketing consultants have experience of more than 5 years and working on the latest technologies and work according to the latest search engine guideline or algorithm.</p>    

          </div>



    </section>

    <!-- About web development ends -->



<!-- --------Features of web--------- -->

<section class="webflow-platform expertise-section ecome-page imarket" >

      <div class="container">

        <div class="row">

          <div class="title">

            <h2>Why Choose Our Internet Marketing  

              <a href="" class="typewrite" data-period="2000" data-type='[  "Services?" ]'> 

              </a>

            </h2>            

          </div>

          <div class="alignitemcenter">



                      <div class="col-md-6">

                <div class="mainservicetopbanner">                  

                  <!-- <h2>PHP Environments & Libraries</h2> -->                 

                  

                <div class="expertise-list">

                <div>

                   <div class="advantage-icon">

                    <img src="images/experience-pro.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                     <p class="advantage-text-head">Experienced Digital Marketers</p>

                     <p class="advantage-text-data">Our team of skillful marketers provides result-oriented digital marketing services. They do market research before performing any action and strategy. This gives you genuine results faster at the best cost.</p>

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <img src="images/filter-1.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                    <p class="advantage-text-head">Lead Generation</p>

                     <p class="advantage-text-data">Our paid search engine and social media marketing champagne generate genuine leads to your services and business in less time. Effectively this improves more revenue and ROI.</p>

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <img src="images/seocc.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                    <p class="advantage-text-head">Improve Visibility</p>

                     <p class="advantage-text-data">We have a remote team supports system to communicate with you 24x7 globally. We listen and answer every query of customers to make more understandable relation and to maintain high-value CRM.</p>

                  </div>

                </div>              

                

                  </div>

                </div>

          </div>



          <div class="col-md-6">

            <div class="mainservicetopbanner">                  

                  <!-- <h2>PHP Environments & Libraries</h2> -->                 

                  

                <div class="expertise-list">

                <div>

                   <div class="advantage-icon">

                    <img src="images/payment-proces.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                     <p class="advantage-text-head">Generate More Revenue</p>

                     <p class="advantage-text-data">By applying different tactics and methods we try to get more revenue for your business in all possible ways. The ultimate purpose of all planning and working is to generate more revenue and profit from the business. We have a team working in this particular field.</p>

                  </div>

                </div>

                  <div>

                   <div class="advantage-icon">

                    <img src="images/branding.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                    <p class="advantage-text-head">Branding Management</p>

                     <p class="advantage-text-data">Branding creates a psychological impact on the visitor’s minds that can convert your potential customers into the client. Reputation is a factor that can interrupt your success, so we manage reviews and reputation online.</p>

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <img src="images/maintenance22.png" alt="icon">

                  </div>

                  <div class="advantage-text">

                    <p class="advantage-text-head">Maintenance and Support</p>

                     <p class="advantage-text-data">We offer the website SEO maintenance and support services for clients. We optimize your website speed, content, broken links, site auditing, and on-site SEO.</p>

                  </div>

                </div>              

                

                  </div>

                </div>

              </div>

        </div>

        </div>

      </div>

    </section>

<!-- end-->



    <!-- web design  services Offer -->

<section class="webflowfeatures_services web3-page bg-gray-white imarket-page">

  <div class="container">

    <div class="title">            

      <h2>Our Result Oriented Online Marketing 

        <a href="" class="typewrite" data-period="2000" data-type='[  "Services" ]'> 

        </a>

      </h2>

      <h3>We are offering different types of digital marketing services to boost your business revenue through all possible marketing channels that include Search Engine Optimization(SEO), Pay Per Click(PPC), Local SEO, International SEO, Content Marketing, Social Media Marketing, Email Marketing.</h3>

    </div>

    

    <div class="row weoffer-row1">

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/seo-new.png"></div>              

            </div>

            <h4>Search Engine Optimization</h4>

            <span class="sub-head">We offer affordable SEO services for every niche or industry. We research, think, make strategy, and apply in action to give the best results to your business. Our complete Search Engine Optimization Packages includes On-page SEO, Technical SEO, Site Audit, Off-page SEO or Link Building, and Blog Submission.

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/easy-to-use.png"></div>             

            </div>

             <h4>Pay-Per Click Services</h4>

            <span class="sub-head">We offer pay-per-click or Google AdWords services to get instant sales and traffic to your website. This service is faster compare to the SEO approach, it increases ROI and generates revenue to your businesses. PPC is the best approach for eCommerce and lead generation.

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/integration-color.png "></div>             

            </div>

            <h4>Local SEO Services</h4>

            <span class="sub-head">We provide local SEO services to improve your business visibility locally or specific location. We register your business on local business sites like Google My Business(GMB), Bing Business, and other local directories. This the best way if you serving locally.

            </span>

          </div>

        </div>

      </div>     



    </div>

      <div class="row weoffer-row2">

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/contentt.png"></div>              

            </div>

            <h4>Content Marketing</h4>

            <span class="sub-head">Content Marketing is used for branding and to improve the visibility of your business. We offer content marketing services to improve traffic, visibility, and educate your customers. We publish blogs, infographics, banners, videos, and documents that help to reach goals.

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/sociall.png"></div>             

            </div>

             <h4>Social Media Marketing</h4>

            <span class="sub-head">We have a team of social media marketers that are skillful to create highly optimized paid ads champagne on social media platforms like Facebook, LinkedIn, Pinterest, Quora, Instagram, and some other social media platforms. SMO is the most visual and appealing way to reach potential customers and audience. 

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

           <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/newsletter.png"></div>              

            </div>

            <h4>Email Marketing</h4>

            <span class="sub-head">Email Marketing Champagne still has the potential to bring back customers to your business, if it handles and create by the experts. We have email marketing experts that create more attractive and optimize champagne to give you the best results. Our email marketing services help you to reach to valuable customers. 

            </span>

          </div>

        </div>

      </div>      

    </div>



  </div>

</section>

<!-- web design services Offer--->



    <!-- hire start -->

    <section class="about-reactjs web3-benefit ecome-page">

      <div class="container">



        <div class="row row-waffer">          

          <div class="col-md-6 web3-contents">

          <h2>Hire <span class="web-theme-color">Digital Marketing Expert</span></h2>           

            <p class="para">A beautifully designed website is worthless if there is no traffic on it. This is where Digital marketing experts are required. A digital marketer can just not only increase traffic on your website but also help you in revenue generation. We at Start Designs have DM experts who can help you reach your business goals through effective marketing of your website. We work on multiple digital marketing channels such as Search Engine Optimization (SEO), Social Media Optimization (SMO), Pay Per Click (PPC), Email marketing, etc. Hire Digital marketing experts from Start Designs and we will make sure you get the results.              

            </p>



            <div class="dflex">

                <a href="#" class="btn btn-contactsupport" id="projectmodel" data-toggle="modal" data-target="#startproject">Start Project →</a>

            </div>                                   

          </div>



          <div class="col-md-6">

              <div class="img_outer">

                <div class="reactleftimages">

                  <img src="images/digital-marketing-hire.jpg" class="responsive web-smal floating" alt="image">

                </div>

              </div>                

          </div>

        </div>

      </div>

    </section> 

    <!-- hire start -->



<!-- Recent work -->

<section class="recentwork-section cmi-recent">

  <div class="container">

    <div class="title">

      <h5>Some of our work that impacts clients' business</h5>

      <h2>Internet Marketing

        <a href="" class="typewrite" data-period="2000" data-type='[  "Recent Works" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row recentworkRow">      

      <div class="col-md-3 col-sm-6">

        <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/ecom-heros.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Ecom Heros</h4>

                  <span class="sub-head">India based Shopify task experts company complete onsite and technical SEO.

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

       <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/addory-website.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Addory</h4>

                  <span class="sub-head">Provide marketing services to boost the sales of India-based women's clothing E-commerce brand.                      

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

        <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/itfc-ui-ux.png" class="responsive">

            <div class="recentworkContent">

                  <h4>ITFC</h4>

                  <span class="sub-head">A Canada based company which provides robust recruitment option for employers all across Canada.                  

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

        <a href="#" class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/sistersrepublic-shopify.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Sisters Republic</h4>

                  <span class="sub-head">France based women's lingerie brand fully functional Shopify store setup.

                  </span>

            </div>

          </div>

        </a>

      </div>

    </div>

  </div>

</section>

<!-- Recent work end-->



 

<!-- Expert review testimony-serve-->

  <section class="section-testimonials reveiw_slide bg-white ">

      <div class="container">

        <div class="row">

          <div class="title">

            <h3>Testimony from our happy clients</h3>

            <h2>What do client say about 

              <a href="" class="typewrite" data-period="2000" data-type='[  "Internet Marketing" ]'> 

              </a>

            </h2>

          </div>

        </div>

       

        <div id="review-slider" class="owl-carousel">

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn23.png" alt="">

                  <div class="user-details-services">

                    <h4>Akshar Patel</h4>

                    <p>Addory</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "Start designs produced a great solution to a very complicated Internet Marketing in a very cost-effective manner."

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn4.png" alt="">

                  <div class="user-details-services">

                    <h4>Daryl N.</h4>

                    <p>Sisters Republic</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">                  

                  "StartDesigns is worth much more than I paid. Not able to tell you how happy I am with Internet Marketing services by StartDesigns."                

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn9.png" alt="">

                  <div class="user-details-services">

                    <h4>Travis P.</h4>

                    <p>ITFC</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">                  

                  "I was amazed at the quality of SEO and Marketing Serives. Definitely worth the investment. We were treated like royalty."                

                </p>

              </div>

            </div>

          </div>

        </div>        



      </div>

    </section>

<!-- Expert review end -->





<!--#include file="footer.shtml"-->

    <a href="javascript:" id="return-to-top">

      <i class="fa fa-angle-double-up  " aria-hidden="true">

      </i>

    </a>



<?php include('footer.php'); ?>



<script type="text/javascript" src="js/jquery.js">

</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js">

</script>

<script src="js/jquery.countup.js">

</script>

<script>

$('.counter').countUp();

</script>

<!-- <script src="js/bootstrap.min.js">

</script> -->

<script src="js/owl.carousel.min.js" defer>

</script>

<script src="js/script.js">

</script>

<script src="js/jquery-1.11.1.min.js">

</script>

<script src="js/jquery.validate.min.js">

</script>

<script src="js/additional-methods.min.js">

</script>

<script src="js/slick.min.js" defer>

</script>









<!-- ----------testimony slider------- -->

<script>

$(document).ready(function(){

    $('#review-slider').owlCarousel({

  loop: true,

  margin: 10,

  nav: false,  

  autoplay: true,

  autoplayHoverPause: true,

  responsive: {

    0: {

      items: 1

    },

    767: {

      items: 1

    },

    1000: {

      items: 1

    }

  }

})

  })

</script>



<script>

  $(document).ready(function(){

    $('#whychoose-slider').owlCarousel({

  loop: true,

  margin: 10,

  nav: false,  

  autoplay: true,

  autoplayHoverPause: true,

  responsive: {

    0: {

      items: 1

    },

    767: {

      items: 2

    },

    1000: {

      items: 4

    }

  }

})

  })

</script>



</body>

</html>

