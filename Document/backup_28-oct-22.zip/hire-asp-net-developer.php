<?php include('header.php'); ?>
<!--#include file="header.shtml"-->
          <div class="no-touch m-nav-menusocial">
            <div id="menusocial" class="menu--social1">
              <div class="toggle--social">
                <span class="soundspeaker-icon">
                </span>
              </div>
              <ul class="menu--sub">
                <li class="menu__item--facebook"> 
                  <a target="_blank" itemprop="samAs" class="menu-link sub-menu-link social_event_track_cls" data-title="Facebook" href="#">
                    <i>
                    </i>HB on Facebook
                  </a> 
                </li>
                <li class="menu__item--twitter"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Twitter" href="#">
                    <i>
                    </i> HB on Twitter 
                  </a> 
                </li>
                <li class="menu__item--linkdin"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="LinkedIn" href="#">
                    <i>
                    </i>HB on Linkedin
                  </a> 
                </li>
                <li class="menu__item--google-p"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Google Plus" href="#">
                    <i>
                    </i>HB on Google+
                  </a> 
                </li>
                <li class="menu__item--youtube"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="You Tube" href="#">
                    <i>
                    </i>HB on Youtube
                  </a> 
                </li>
                <li class="menu__item--blog"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Blog" href="#">
                    <i>
                    </i>HB on Blog
                  </a> 
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div id="top-container" style="display:none;">
          <div class="centerdiv">
            <div class="left"> 
              <a href="#" title=""> 
                <img src="images/logo.png" width="261" height="51" alt="" class="logo" /> 
              </a> 
            </div>
            <div class="right" style="width:72%;">
              <div class="r-clear menu-display">
                <div class="search-div">
                  <input type="search" placeholder="Search" name="" />
                </div>
                <span class="link-area">
                  <a target="_blank" title="" href="#">Blog
                  </a>
                  <a title="" href="#" target="_blank">Articles
                  </a>
                  <a title="" href="#">FAQ
                  </a>
                  <a title="" href="#">Careers
                  </a> 
                  <a title="Contact" href="#">Contact
                  </a> 
                  <a title="" href="#">Partnership
                  </a>
                </span> 
              </div>
              <div class="r-clear topmenu">
                <div class="mobile-tablet-menu">
                  <a href="#" class="mobile-menu-home-iclass" id="mobile-menu-home-icon">
                  </a>
                  <div class="mobile-menu-home-contner" id="mobile-menu-home">
                    <ul>
                      <li>
                        <a title="Company" href="#">Company
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Services
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Technology
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Products
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Client
                        </a>
                      </li>
                      <li>
                        <a title="Work" class="work-menu" href="#">Work
                        </a>
                      </li>
                      <li>
                        <a title="Inquiry" href="#" id="inquiry-pop-up" class="active">Get Quote
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
                <ul class="menu-t-menu-new">
                  <li>
                    <a title="startdesigns InfoTech" href="#">
                      <span class="home">
                      </span>
                    </a> 
                  </li>
                  <li>
                    <a title="Company" href="#">Company
                    </a> 
                  </li>
                  <li>
                    <a title="Services" href="#">Services
                    </a> 
                  </li>
                  <li>
                    <a title="Technology" href="#">Technology
                    </a> 
                  </li>
                  <li>
                    <a href="#">Products
                    </a> 
                  </li>
                  <li>
                    <a title="Work" href="#">Work
                    </a> 
                  </li>
                  <li>
                    <a title="Inquiry" href="#">Get Quote
                    </a> 
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
    <div class="" id="particles-js">
      <div class=" heading-particjs" >
        <div class="title">
          <h1 class="text-center">Hire ASP.NET 
            <a href="" class="typewrite" data-period="2000" data-type='[  "Developer" ]'>
            </a>
          </h1>
        </div>
      </div>
    </div>
    <!-- Banner top- contact end -->
    <section class="service-detils hire_resources">
      <div class="container">
        <div class="row">
          <div class="col-md-10">
            <div class="details-content">
              <div class="title">
                <h2>Hire ASP.NET 
                  <a href="" class="typewrite" data-period="2000" data-type='[  "Developer" ]'> 
                  </a>
                </h2>  
              </div> 
              <span class="details-strip">
                Hire Start Designs on hourly, monthly or project basis to create adaptable, scalable and feature rich web applications. Our ASP.net developers are Microsoft certified and are well versed in  working with Microsoft stack. ASP.net enables to create web applications hassle free, speedy coding and delivers best solutions which will add to your business growth. 
              </span> 
            </div>
            <div class="service-detils-img-box">
              <div class="service-detils-img">
                <a href="#">
                  <img src="images/lnding-prot.jpg">
                  <span>
                    <i>+
                    </i> 
                  </span>
                </a>
              </div>
              <div class="service-detils-img">
                <a href="#">
                  <img src="images/lnding-prot.jpg">
                  <span>
                    <i>+
                    </i>  
                  </span>
                </a>
              </div>
              <div class="service-detils-img">
                <a href="#">
                  <img src="images/lnding-prot.jpg">
                  <span>
                    <i>+
                    </i> 
                  </span>
                </a>
              </div>
            </div>
          </div>
          <div class="col-md-2">
            <div class="services-from">
            <form method="post" autocomplete="off" id="service" action="service_ajax.php" name="service">
                <div id="service_response">
                </div>
                <div class="form-group" >
                  <label>name<span class="require_fi">*</span>
                  </label>
                  <input type="text" name="sname" id="sname" class="form-control" placeholder="Enter Your Name">
                </div>
                <div class="form-group">
                  <label>Email<span class="require_fi">*</span>
                  </label>
                  <input type="email" name="semail" id="semail" class="form-control" placeholder="Enter Email Address" required pattern="[^@]+@[^@]+\.[a-zA-Z]{2,6}">
                </div>
                <div class="form-group">
                  <label> Phone Number<span class="require_fi">*</span>
                  </label>
                 <input id="phone" maxlength="14" name="phone" type="text" class="required comm_phone_number form-control" placeholder="Enter Your Number" title="Please enter exactly 10 digits" pattern="[1-9]{1}[0-9]{9}">
                </div>
                <div class="form-group">
                  <label>Message
                  </label>
                  <textarea class="form-control" placeholder="Enter Message" name="smessage" id="smessage"></textarea>
                  <span class="from-terms">
                    For any questions and query please contact us on 
                    <br>
                    <strong>+91 0141-4044287
                    </strong>
                  </span>
                </div>
                <div class="btn-from">
                  <button type="submit"  name="service_submit"  class="btn">submit
                  </button>
                </div>
                <span class="terms-from-dec">
                  Various versions have evolved over the years 
                  <a href="#">  sometimes by accident,
                  </a> on purpose 
                  <a href="#">sometimes
                  </a>  (injected humour and the like).
                </span>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="advantages-hiring bg-gray-white" id="to-be-fixed">
      <div class="container">
        <div class="title">
          <h2>Why
            <a href="" class="typewrite" data-period="2000" data-type='[  "Choose Start Designs ?" ]'> 
            </a>
          </h2>
        </div>
        <div class="row">
        
          <div class="col-md-7">
            <div class="develop_robust_content"> 
                <p>
                    Our app and web development company offers a fully-comprehensive set of IT services through the well-sophisticated knowledge we’ve gathered in all these years. Start Designs has employed the expert in WordPress, Magento, Joomla, CMS, CodeIgniter, CakePHP, DJANGO, PHP, MongoDB, Laravel, Yii, and Website Designing to provide you with best services in this domain. To enhance your business prospects, you can take the virtual support from Start Designs.
                </p>
                <p>
                  Becoming a part of your team, we contribute our 100% for the successful delivery of your projects. We change our work schedule as per your convenience. Start Designs understand your needs and thus, provides right solution and resources.
                  From product-based start-ups to enterprise-grade organizations and the service providers working in the same domain as ours, hire dedicated developers or development teams for all your needs.
                </p>
          </div>
            <div class="advantages-hiring-list">
                <div>
                   <div class="advantage-icon">
                    <i class="fa fa-check-circle" aria-hidden="true">
                    </i>
                  </div>
                  <div class="advantage-text">
                     Highly experienced professionals.
                  </div>
                </div>
                 <div>
                   <div class="advantage-icon">
                    <i class="fa fa-check-circle" aria-hidden="true">
                    </i>
                  </div>
                  <div class="advantage-text">
                    Non disclosure agreement.
                  </div>
                </div>
                 <div>
                   <div class="advantage-icon">
                    <i class="fa fa-check-circle" aria-hidden="true">
                    </i>
                  </div>
                  <div class="advantage-text">
                    Varied industry experience.
                  </div>
                </div>
                 <div>
                   <div class="advantage-icon">
                    <i class="fa fa-check-circle" aria-hidden="true">
                    </i>
                  </div>
                  <div class="advantage-text">
                    Supreme communication.
                  </div>
                </div>
                 <div>
                   <div class="advantage-icon">
                    <i class="fa fa-check-circle" aria-hidden="true">
                    </i>
                  </div>
                  <div class="advantage-text">
                    Bug free Coding.
                  </div>
                </div>
                 <div>
                   <div class="advantage-icon">
                    <i class="fa fa-check-circle" aria-hidden="true">
                    </i>
                  </div>
                  <div class="advantage-text">
                    24*7 technical support.
                  </div>
                </div>
            </div>
          </div>
            <div class="col-md-5">
            <div class="advantages-hiring-img">
              <img src="images/hire_dedicate2.png" class="floating">
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="use-technological technological_developer">
      <div class="container">
        <div class="title">
          <h2>Our  Developers Use Best 
            <a href="" class="typewrite" data-period="2000" data-type='[  " Technological Aids" ]'> 
            </a>
          </h2>
        </div>
        <div class="technological-box">
          <a href="#" class="spc-bt-30">
            <img src="images/drop-box.png">
          </a>
          <a href="#" class="spc-bt-30">
            <img src="images/github.png">
          </a>
          <a href="#" class="spc-bt-30">
            <img src="images/trello.png">
          </a>
          <a href="#" class="spc-bt-30">
            <img src="images/slack.png">
          </a>
          <a href="#" class="spc-bt-15-md">
            <img src="images/xjira.png">
          </a>
          <a href="#" class="spc-bt-15-md">
            <img src="images/bugzila.png">
          </a>
          <a href="#">
            <img src="images/Evernote.png">
          </a>
          <a href="#">
            <img src="images/gitlab.png">
          </a>
        </div>
      </div>
    </section>
    <!--#include file="footer.shtml"-->   
    <a href="javascript:" id="return-to-top">
      <i class="fa fa-angle-double-up  " aria-hidden="true">
      </i>
    </a>
    <!-- get jQuery from the google apis -->
<script type="text/javascript" src="js/jquery.js">
</script>
<script src="js/bootstrap.min.js">
</script>
<script src="js/script.js">
</script>
<script src="js/jquery-1.11.1.min.js">
</script>
<script src="js/jquery.validate.min.js">
</script>
<script src="js/additional-methods.min.js">
</script>
<!-- ================== -->
<script>

(function($) {
$.fn.inputFilter = function(inputFilter) {
  return this.on("input keydown keyup mousedown mouseup select contextmenu drop", function() {
  //console.log(this.value);
  if (inputFilter(this.value)) {
    this.oldValue = this.value;
    this.oldSelectionStart = this.selectionStart;
    this.oldSelectionEnd = this.selectionEnd;
  } else if (this.hasOwnProperty("oldValue")) {
    this.value = this.oldValue;
    this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
  }
  });
};
}(jQuery));
$(".comm_phone_number").inputFilter(function(value) {
  return /^\d*$/.test(value) && (value === "" || parseInt(value) <= 9999999999); 
});

(function(i,s,o,g,r,a,m){
  i['GoogleAnalyticsObject']=r;
  i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)}
    ,i[r].l=1*new Date();
  a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];
  a.async=1;
  a.src=g;
  m.parentNode.insertBefore(a,m)
}
)(window,document,'script','//www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-67094806-1', 'auto');
ga('send', 'pageview');
</script>

<script type="text/javascript">
$(document).ready(function(){
    jQuery.validator.setDefaults({
      debug: true,
      success: "valid"
    });
    $( "#service" ).validate({
      rules: {
        // simple rule, converted to {required:true}
        sname: "required",
        // compound rule
        semail: {
          required: true,
          email: true
        }
        ,
        phone: {
          required: true,
          number: true,
        },
      },
        messages: {
          sname: "Please enter your name",
          semail: {
            required: "Please enter a valid email address",
            email: "Please enter a valid email address",
           // remote: jQuery.validator.format("{0} is already in use")

          },
          phone:"Please enter a number",
        }
      ,submitHandler: function(form) {
        // do other things for a valid form
        //form.submit();
        submit_by_service();
      }
    });
    function submit_by_service(){
      $.ajax({
        type: "POST",
        url: "service_ajax.php",
        dataType: "json",
        data: $("#service").serialize(),
        success: function(response) {
          if(response.status)
          {
            $("#service_response").empty().html('<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+response.message+'</div>');
            document.getElementById("service").reset();
             setTimeout(function(){  $('#service_response').empty();}, 3000);
          }
          else {
            $("#service_response").empty().html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+response.message+'</div>');
          }
        }
        ,
        error: function(data) {
          console.log("error in ajax request");
        }
      }
            ).done(function() {
        console.log("ajax request complete");
      } );
    }
});
</script>

<script type="text/javascript">
 /* $(document).ready(function(){
      $('#skype_id').keypress(function (e) {
      var regex = new RegExp("^[a-zA-Z0-9]+$");
      var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
      if (regex.test(str)) {
          return true;
      }
      e.preventDefault();
      return false;
      });
  });*/
  $(window).on('scroll', function(){
      var elementPosition = $('#to-be-fixed').offset();
      var headerHeight = $('#top-container-def').height();
      var elemHeight = $('#to-be-fixed').height() / 8;
        var elementTopPositon = elementPosition.top - headerHeight;
        var elementTopPositonDiv = elementPosition.top + elemHeight;
        if($(this).width() >= 992){
        if($(this).scrollTop() >= elementTopPositon){
           $('#to-be-fixed').addClass('to-be-fixed');
           if($(this).scrollTop() >= elementTopPositonDiv){
              $('#to-be-fixed').removeClass('to-be-fixed');
           }
        }
        else{
             $('#to-be-fixed').removeClass('to-be-fixed');
           }

        }
   });
</script>
</body>
</html>
<?php include('footer.php'); ?>