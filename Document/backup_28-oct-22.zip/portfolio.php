 <?php include('header.php'); ?>
<!--#include file="header.shtml"-->
          <div class="no-touch m-nav-menusocial">
            <div id="menusocial" class="menu--social1">
              <div class="toggle--social">
                <span class="soundspeaker-icon">
                </span>
              </div>
              <ul class="menu--sub">
                <li class="menu__item--facebook"> 
                  <a target="_blank" itemprop="samAs" class="menu-link sub-menu-link social_event_track_cls" data-title="Facebook" href="#">
                    <i>
                    </i>HB on Facebook
                  </a> 
                </li>
                <li class="menu__item--twitter"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Twitter" href="#">
                    <i>
                    </i> HB on Twitter 
                  </a> 
                </li>
                <li class="menu__item--linkdin"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="LinkedIn" href="#">
                    <i>
                    </i>HB on Linkedin
                  </a> 
                </li>
                <li class="menu__item--google-p"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Google Plus" href="#">
                    <i>
                    </i>HB on Google+
                  </a> 
                </li>
                <li class="menu__item--youtube"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="You Tube" href="#">
                    <i>
                    </i>HB on Youtube
                  </a> 
                </li>
                <li class="menu__item--blog"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Blog" href="#">
                    <i>
                    </i>HB on Blog
                  </a> 
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div id="top-container" style="display:none;">
          <div class="centerdiv">
            <div class="left"> 
              <a href="#" title=""> 
                <img src="images/logo.png" width="261" height="51" alt="" class="logo" /> 
              </a> 
            </div>
            <div class="right" style="width:72%;">
              <div class="r-clear menu-display">
                <div class="search-div">
                  <input type="search" placeholder="Search" name="" />
                </div>
                <span class="link-area">
                  <a target="_blank" title="" href="#">Blog
                  </a>
                  <a title="" href="#" target="_blank">Articles
                  </a>
                  <a title="" href="#">FAQ
                  </a>
                  <a title="" href="#">Careers
                  </a> 
                  <a title="Contact" href="#">Contact
                  </a> 
                  <a title="" href="#">Partnership
                  </a>
                </span> 
              </div>
              <div class="r-clear topmenu">
                <div class="mobile-tablet-menu">
                  <a href="#" class="mobile-menu-home-iclass" id="mobile-menu-home-icon">
                  </a>
                  <div class="mobile-menu-home-contner" id="mobile-menu-home">
                    <ul>
                      <li>
                        <a title="Company" href="#">Company
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Services
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Technology
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Products
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Client
                        </a>
                      </li>
                      <li>
                        <a title="Work" class="work-menu" href="#">Work
                        </a>
                      </li>
                      <li>
                        <a title="Inquiry" href="#" id="inquiry-pop-up" class="active">Get Quote
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
                <ul class="menu-t-menu-new">
                  <li>
                    <a title="startdesigns InfoTech" href="#">
                      <span class="home">
                      </span>
                    </a> 
                  </li>
                  <li>
                    <a title="Company" href="#">Company
                    </a> 
                  </li>
                  <li>
                    <a title="Services" href="#">Services
                    </a> 
                  </li>
                  <li>
                    <a title="Technology" href="#">Technology
                    </a> 
                  </li>
                  <li>
                    <a href="#">Products
                    </a> 
                  </li>
                  <li>
                    <a title="Work" href="#">Work
                    </a> 
                  </li>
                  <li>
                    <a title="Inquiry" href="#">Get Quote
                    </a> 
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
    <!-- <div class="" id="particles-js">
      <div class=" heading-particjs" >
        <div class="title">
          <h1 class="text-center">Webflow 
            <a href="" class="typewrite" data-period="2000" data-type='[  "Expert" ]'>
            </a>
          </h1>
        </div>
      </div>
    </div> -->
    <!-- Banner top- contact end -->

    <section class="service-topbanner portfoliya-newpage">
      <div class="container">
          <div class="row service-flex">
              <div class="col-md-6">
                <div class="mainservicetopbanner">
                  <h3>See what we have done... </h3>
                  <!-- <span><img src="images/white_prestashop.png"></span> -->
                  <h1>Hello We're Start Designs  </h1>
                  <p>
                  Just look at our portfolios and works before hiring us. We know this is the way to make you believe in us and our capabilities. But we want to ensure you that with our experience of more than 12 years in this industry. We are capable achieve any goal and transforming your ideas digitally.
                 </p>
                  <div class="dflex">
                    <a href="#foooter_form" class="btn btn-contactsupport">Contact Support →</a>
                    <a href="#" class="btn btn-startproject" id="projectmodel" data-toggle="modal" data-target="#startproject">Start Project →</a>
                  </div>
                 
                </div>
              </div>
              <div class="col-md-6">
                <div class="rightside-topbanner wpbanner-top">
                </div>
              </div>
          </div>
      </div>
    </section>


       <!-- what is drupal start -->

       <section class="service-awardwinning drupal_award spacemanaging_portfolio synchrony_mainsection">
          <div class="container">
              <div class="row service-flex">

                <div class="col-md-6">
                  <div class="mainservicetopbanner">
                    <div class="logo-portfolioimage">
                      <img src="images/synchrony-logo.svg" alt="logo" />
                    </div>
                    <h2>Synchrony </h2>
                    <h3>Providing website design and web app development solution </h3>
                    <p class="para">
                      We are associated with Synchrony for more than 2 years, creating and managing the complete website. We also build and manage their web app. We have used Web3 technology to build this website.
                    </p>
                    <p class="para">
                      We used <strong>ReactJs</strong>, an open-source JavaScript framework, and library developed by Facebook used for building interactive user interfaces and web applications fast.
                    </p>
                      
                      <p class="para">
                        We used <strong>Redux</strong>, another JavaScript library to manage and centralize application states. Used with any JS library or framework like React, Angular, or Vue.
                      </p>
                        
                        <p class="para">
                        <strong>Web3</strong>, we used Web3.js, a collection of libraries that allow users to interact with Ethereum nodes and blockchain through HTTP, Interprocess Communication (IPC), and Web Socket.
                        </p>
                          
                        <p class="para">
                          <strong>RPC API</strong>, we used Remote Procedure Call (RPC) API to construct this distributed, client-server-based application. This RPC API provides the use of op applications in both local & distributed environments.
                        </p>
                        <p class="para">
                        We used <strong>Solana</strong>, a public blockchain platform to host this decentralized application.
                        </p>
                    

                    <div class="technology_details_poprtfolio">
                      
                      <div class="TECHNOLOGY_details">
                        <h4>TECHNOLOGY USED</h4>
                        <h5>Backend Frontend Technologies:</h5>
                        <p><span>ReactJS, Redux, UI/UX, Ajax, Solana</span> </p>
                        <h5>Database:</h5>
                        <p><span>PostgreSQL</span> </p>
                        <h5>Prototype Design:</h5>
                        <p><span>Figma</span> </p>
                        <h5>Server:</h5>
                        <p><span>Google Cloud</span> </p>
                      </div>
                        <div class="available_on">
                          <h4>AVAILABLE ON</h4>
                          <div><a href="https://synchrony.fi/"><img src="images/web-btn.svg" alt=""></a></div>
                        </div>
                    </div>

                  </div>
                </div>

                <div class="col-md-6">
                  <div class="leftside-img advantages-hiring-img">
                    <img src="images/synchrony-banner.png" class="responsive">
                  </div>
                </div>

              </div>
          </div>
       </section>


        <section class="service-awardwinning drupal_award spacemanaging_portfolio wednesdayNFT_mainsection">
          <div class="container">
              <div class="row service-flex">

              

                <div class="col-md-6">
                  <div class="mainservicetopbanner">
                    <div class="logo-portfolioimage">
                      <img src="images/WednesdaysNFT.svg" alt="logo" />
                    </div>
                    <h2>Wednesdays NFT </h2>
                    <h3>Custom Webflow website design and development</h3>
                    <p class="para">
                      We build a website for WednesDayNFT using Webflow CMS. We have provided complete custom website design and development from scratch. We write all the custom code to transform the client's idea into reality. 
                    </p>
                    
                    <p class="para">
                      We used the <strong>Webflow</strong> content management system to build this website with advanced and dynamic animation. Webflow is the best CMS to build a dynamic website that closes the gap between a visual design mockup and a live website.
                    </p>
                    
                    <p class="para">
                      We used custom <strong>jQuery</strong> to add the custom animation to the website. jQuery is the best to create SEO-friendly and fast animation of the website.
                    </p>

                    <div class="technology_details_poprtfolio">
                      
                      <div class="TECHNOLOGY_details">
                        <h4>TECHNOLOGY USED</h4>
                        <h5>Frontend Technologies:</h5>
                        <p> <span>Webflow, jQuery, Particles.js, UI/UX, CSS</span> </p>
                        <h5>Prototype Design:</h5>
                        <p><span>Figma, Photoshop</span> </p>
                      </div>
                        <div class="available_on">
                          <h4>AVAILABLE ON</h4>
                          <div><a href="https://www.wednesdaysnft.com/"><img src="images/web-btn.svg" alt=""></a></div>
                        </div>
                    </div>

                  </div>
                </div>

                <div class="col-md-6">
                  <div class="leftside-img advantages-hiring-img">
                    <img src="images/wednesday-banner.png" class="responsive">
                  </div>
                </div>

                

              </div>
          </div>
        </section>

        <section class="service-awardwinning drupal_award spacemanaging_portfolio itfc_mainsection">
          <div class="container">
              <div class="row service-flex">

                <div class="col-md-6">
                  <div class="mainservicetopbanner">
                    <div class="logo-portfolioimage">
                      <img src="images/itfc-logo.svg" alt="logo" />
                    </div>
                    <h2>ItsTimeForChange</h2>
                    <h3>Custom website design and development</h3>
                    <p class="para">
                      We created this complete website from front-end, back-end, UI, UX, logo, and graphic design. Now we are providing maintenance and support services to ItsTimeForChange.
                    </p>
                    <p class="para">We build ITFC from scratch using <strong>custom HTML, CSS, Bootstrap, JavaScript, Ajax, and custom functionality using PHP.</strong> Create custom icons and graphics that enhance the overall website user interface to understand ITFC easily.


                      </p>
                      <p class="para">
                      <strong>Yii</strong> is an open-source, object-oriented component-based MVC PHP web application framework. We used Yii to create a web application for ItsTimeForChange.
                      </p>
                    
                    <div class="technology_details_poprtfolio">
                      
                      <div class="TECHNOLOGY_details">
                        <h4>TECHNOLOGY USED</h4>
                        <h5>Frontend Technologies:</h5>
                        <p> <span>HTML, CSS, Bootstrap</span> </p>
                        <h5>CMS:</h5>
                        <p>WordPress</p>
                        <h5>Prototype and Graphics Design:</h5>
                        <p><span>Figma, Photoshop</span> </p>
                        <h5>Backend:</h5>
                        <p><span>Yii, Ajax, Node.js</span> </p>
                        <h5>Server:</h5>
                        <p><span>AWS</span> </p>
                      </div>
                        <div class="available_on">
                          <h4>AVAILABLE ON</h4>
                          <div><a href="https://itstimeforchange.ca/"><img src="images/web-btn.svg" alt=""></a></div>
                        </div>
                    </div>

                  </div>
                </div>

                <div class="col-md-6">
                  <div class="leftside-img advantages-hiring-img">
                    <img src="images/itfc-banner.png" class="responsive">
                  </div>
                </div>

                
              </div>
          </div>
        </section>

    <!-- what is drupal end -->




<!-- Recent work Ui -->

<!-- Recent work Ui end-->



<?php include('footer.php'); ?>
<script>
  $(document).ready(function(){
    $('#review-slider').owlCarousel({
  loop: true,
  margin: 10,
  nav: false,  
  autoplay: true,
  autoplayHoverPause: true,
  responsive: {
    0: {
      items: 1
    },
    767: {
      items: 1
    },
    1000: {
      items: 1
    }
  }
})
  })
</script>

<script>
  $(document).ready(function(){
    $('#prestachoose-slider').owlCarousel({
  loop: true,
  margin: 10,
  nav: false,  
  autoplay: true,
  autoplayHoverPause: true,
  responsive: {
    0: {
      items: 1
    },
    767: {
      items: 2
    },
    1000: {
      items: 4
    }
  }
})
  })
</script>


</body>
</html>
