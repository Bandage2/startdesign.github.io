 <?php include('header.php'); ?>

<!--#include file="header.shtml"-->

          <div class="no-touch m-nav-menusocial">

            <div id="menusocial" class="menu--social1">

              <div class="toggle--social">

                <span class="soundspeaker-icon">

                </span>

              </div>

              <ul class="menu--sub">

                <li class="menu__item--facebook"> 

                  <a target="_blank" itemprop="samAs" class="menu-link sub-menu-link social_event_track_cls" data-title="Facebook" href="#">

                    <i>

                    </i>HB on Facebook

                  </a> 

                </li>

                <li class="menu__item--twitter"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Twitter" href="#">

                    <i>

                    </i> HB on Twitter 

                  </a> 

                </li>

                <li class="menu__item--linkdin"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="LinkedIn" href="#">

                    <i>

                    </i>HB on Linkedin

                  </a> 

                </li>

                <li class="menu__item--google-p"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Google Plus" href="#">

                    <i>

                    </i>HB on Google+

                  </a> 

                </li>

                <li class="menu__item--youtube"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="You Tube" href="#">

                    <i>

                    </i>HB on Youtube

                  </a> 

                </li>

                <li class="menu__item--blog"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Blog" href="#">

                    <i>

                    </i>HB on Blog

                  </a> 

                </li>

              </ul>

            </div>

          </div>

        </div>

        <div id="top-container" style="display:none;">

          <div class="centerdiv">

            <div class="left"> 

              <a href="#" title=""> 

                <img src="images/logo.png" width="261" height="51" alt="" class="logo" /> 

              </a> 

            </div>

            <div class="right" style="width:72%;">

              <div class="r-clear menu-display">

                <div class="search-div">

                  <input type="search" placeholder="Search" name="" />

                </div>

                <span class="link-area">

                  <a target="_blank" title="" href="#">Blog

                  </a>

                  <a title="" href="#" target="_blank">Articles

                  </a>

                  <a title="" href="#">FAQ

                  </a>

                  <a title="" href="#">Careers

                  </a> 

                  <a title="Contact" href="#">Contact

                  </a> 

                  <a title="" href="#">Partnership

                  </a>

                </span> 

              </div>

              <div class="r-clear topmenu">

                <div class="mobile-tablet-menu">

                  <a href="#" class="mobile-menu-home-iclass" id="mobile-menu-home-icon">

                  </a>

                  <div class="mobile-menu-home-contner" id="mobile-menu-home">

                    <ul>

                      <li>

                        <a title="Company" href="#">Company

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Services

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Technology

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Products

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Client

                        </a>

                      </li>

                      <li>

                        <a title="Work" class="work-menu" href="#">Work

                        </a>

                      </li>

                      <li>

                        <a title="Inquiry" href="#" id="inquiry-pop-up" class="active">Get Quote

                        </a>

                      </li>

                    </ul>

                  </div>

                </div>

                <ul class="menu-t-menu-new">

                  <li>

                    <a title="startdesigns InfoTech" href="#">

                      <span class="home">

                      </span>

                    </a> 

                  </li>

                  <li>

                    <a title="Company" href="#">Company

                    </a> 

                  </li>

                  <li>

                    <a title="Services" href="#">Services

                    </a> 

                  </li>

                  <li>

                    <a title="Technology" href="#">Technology

                    </a> 

                  </li>

                  <li>

                    <a href="#">Products

                    </a> 

                  </li>

                  <li>

                    <a title="Work" href="#">Work

                    </a> 

                  </li>

                  <li>

                    <a title="Inquiry" href="#">Get Quote

                    </a> 

                  </li>

                </ul>

              </div>

            </div>

          </div>

        </div>

      </div>

    </header>





    <section class="service-topbanner damlbannerbg">

      <div class="container">

          <div class="row service-flex">

              <div class="col-md-6">

                <div class="mainservicetopbanner">

                  <h3>DAML Development Services</h3>

                  <h1 class="wordpress_head">Accelerate your Daml Projects </h1>                 

                  <p>Multiply Daml 10x productivity by another 10x. Take your Daml application to market with Start Design’s ready-made scaffolding </p>

                  <div class="dflex">

                    <a href="#foooter_form" class="btn btn-contactsupport">Contact Support →</a>

                    <a href="#" class="btn btn-startproject" id="projectmodel" data-toggle="modal" data-target="#startproject">Start Project →</a>                    

                  </div>                  

                </div>

              </div>

              <div class="col-md-6">

                <div class="rightside-topbanner wpbanner-top">

                  <img src="images/DAMLimage2.png">

                </div>

              </div>

          </div>

      </div>

    </section>



<!-- <section class="developmnt_services php_page">

  <div class="container">

    <div class="row">

      <div class="developmnt_services_box">

        <div class="service_box_data">

          <div class="dev_service_icon"><img src="images/devops.svg"></div>

          <p>DAML Service</p>

        </div>



        <div class="service_box_data">

          <div class="dev_service_icon"><img src="images/server.svg"></div>

          <p>DAML Service</p>

        </div>



        <div class="service_box_data">

          <div class="dev_service_icon"><img src="images/ux-ui.svg"></div>

          <p>DAML Service</p>

        </div>



        <div class="service_box_data">

          <div class="dev_service_icon"><img src="images/quick.svg"></div>

          <p>DAML Service</p>

        </div>



        <div class="service_box_data">

          <div class="dev_service_icon"><img src="images/comptent.svg"></div>

          <p>DAML Service</p>

        </div>

        

      </div>

    </div>

  </div>

</section> -->

       <!-- what is daml start -->

       <section class="service-awardwinning drupal_award">
      <div class="container">
          <div class="row service-flex">
            <div class="col-md-6">
                <div class="leftside-img advantages-hiring-img">
                  <img src="images/what-drupal.svg" class="responsive floating">
                </div>
              </div>
              <div class="col-md-6">
                <div class="mainservicetopbanner">
                  <!-- <h3>Grow Your eCommerce Business with PrestaShop </h3> -->
                  <h2>How we help you get to market faster</h2>
                  <p class="para">
                    If you are building in Daml, you know that the application architecture and external integrations are very important to get right. The starter Daml templates are great for a quick developer demo, but you need a more robust 3-tier architecture to demonstrate that your app can be production ready. 
                  </p>
                  <p class="para1">
                    That’s where we come in. While you work on the core business logic in Daml, we make everything else easy and seamless for you.
                  </p>
                   </div>
              </div>
          </div>
      </div>
    </section>

    <!-- what is daml end -->

    <!-- Php Features -->

<section class="webflowfeatures_services php_solutions bg-gray-white">

  <div class="container">

    <div class="title">

      <h3>We have a team of skilled and experienced DAML developers to provide </h3>

      <h2>A Wide Range of Our Cutting-edge

        <a href="" class="typewrite" data-period="2000" data-type='[  "DAML Development Solutions" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row weoffer-row1">

      <div class="col-md-4">
        <div class="damlBox newDml">
          <div class="DamlContent">
            <div class="service_icon"><img src="images/dashboard-ui.png"></div>
            <h4>Ready React Templates</h4>
            <span class="sub-head">
            Beautifully designed React templates so you can just customize and adapt. We have templates available for banking, commerce, marketplaces among others
            </span>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="damlBox newDml">
          <div class="DamlContent">
            <div class="service_icon"><img src="images/mudeel.png"></div>
            <h4>Integrated Authentication</h4>
            <span class="sub-head">
            Building in external authentication into your Daml projects can be time consuming and confusing. We have a predefined front end scaffolding along with a set of back end Daml templates that can be customized and mapped to the right party types in your Daml application.
           </span>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="damlBox newDml">
          <div class="DamlContent">
            <div class="service_icon"><img src="images/theme2.png"></div>
            <h4>Pre-defined Cloud Deployment Templates</h4>
            <span class="sub-head">
            Whether you want to deploy on Daml Hub, or want to use a more generic service like AWS, Azure or GCP, we have the deployment blueprint ready out-of-the-box.
           </span>
          </div>
        </div>
      </div>    



    </div>

    

    <div class="row weoffer-row1">

      <div class="col-md-4">
        <div class="damlBox newDml">
          <div class="DamlContent">
            <div class="service_icon"><img src="images/websitee.png"></div>
            <h4>UX Design	</h4>
            <span class="sub-head">
            We are team of Adobe certified designers. Whether you want to design your functional app or want to build a marketing website around it, we are one of the best.
           </span>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="damlBox newDml">
          <div class="DamlContent">
            <div class="service_icon"><img src="images/export.png"></div>
            <h4>Shopify Integration</h4>
            <span class="sub-head">
            Building a commerce related site? We can take your site to the next level with shopify integrations that can dramatically improve customer experience.
          </span>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="damlBox newDml">
          <div class="DamlContent">
            <div class="service_icon"><img src="images/app-ui.png"></div>
            <h4>Email Integration</h4>
            <span class="sub-head">
            Every applications needs to send email. But doing that from your Daml app is not feasible. We have special provisions in our 3-tier Daml architecture to enable this for your with the flick of a switch. Use any provider you want.
            </span>
          </div>
        </div>
      </div>   

    </div>

    <div class="row weoffer-row2">

      <div class="col-md-6">
        <div class="damlBox newDml">
          <div class="DamlContent">
            <div class="service_icon"><img src="images/migration.png"></div>
            <h4>Integrated Document Storage</h4>
            <span class="sub-head">
            Any application today needs document storage…whethers is user profile images, image galleries, or PDF reports we have the integrations ready. We can deploy the storage on AWS S3, Azure or anywhere your project needs. 
            </span>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="damlBox newDml">
          <div class="DamlContent">
            <div class="service_icon"><img src="images/web-plugin.png"></div>
            <h4>3-Tier Architecture</h4>
            <span class="sub-head">
            One of the reasons why Daml is so fast and effective is that it is the golden source of your business logic and does not require a database. 
            However external integrations also need a separate application layer to be deployed. These could be your python, Java, Node.js, or C# modules that need to know when a Daml contract has been created and what to do with the outside world. For example, it could be as simple as getting the signed and secure URL of an image from AWS S3.
            Use our optimal architecture templates to seamless do that for your Daml app.
          </span>
          </div>
        </div>
      </div>

         

    </div>



  </div>

</section>



<!-- Php features end-->







<!-- Recent work -->

<section class="recentwork-section cmi-recent php_page">

  <div class="container">

    <div class="title">

      <h3>Pour a brew and peruse our goods</h3>

      <h2>DAML Development

        <a href="" class="typewrite" data-period="2000" data-type='[  "Recent Works" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row recentworkRow">

      <div class="col-md-3 col-sm-6">
        <a class="recentworkBox">
          <div class="recentworkImg">
            <img src="images/45lo.jpg" class="responsive">
            <div class="recentworkContent">
                  <h4>DAML UI Template</h4>
                  <span class="sub-head">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                  </span>
            </div>
          </div>
        </a>
      </div>

      <div class="col-md-3 col-sm-6">

        <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/smTemp.jpg" class="responsive">

            <div class="recentworkContent">
                  <h4>Primagaz UI Template</h4>
                  <span class="sub-head">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                  </span>
            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

       <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/nomorobo.png" class="responsive">

            <div class="recentworkContent">
                  <h4>What is Lorem Ipsum?</h4>
                  <span class="sub-head">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                  </span>
            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

        <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/technicpack.png" class="responsive">

            <div class="recentworkContent">
                  <h4>What is Lorem Ipsum?</h4>
                  <span class="sub-head">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                  </span>
            </div>

          </div>

        </a>

      </div>

    </div>

  </div>

</section>



<!-- Recent work end-->



 

<!-- Expert review -->

  <section class="section-testimonials reveiw_slide php_page">

      <div class="container">

        <div class="row">

          <div class="title">

            <h3>Testimony From Our Happy Clients</h3>

            <h2>What do client say about 

              <a href="" class="typewrite" data-period="2000" data-type='[  "DAML Expert" ]'> 

              </a>

            </h2>

          </div>

        </div>

       

        <div id="review-slider" class="owl-carousel">

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn2.png" alt="">

                  <div class="user-details-services">

                    <h4>James Smith</h4>

                    <p>Nomorobo</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "Start designs produced a great solution to a very complicated PHP problems in a very cost-effective manner."

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn7.png" alt="">

                  <div class="user-details-services">

                    <h4>Maria Garcia</h4>

                    <p>Technic pack</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "Wow what great service, I love it! Needless to say, we are extremely satisfied with the results. PHP website is both attractive and highly adaptable."

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn14.png" alt="">

                  <div class="user-details-services">

                    <h4>Samuel</h4>

                    <p>Network Advertising</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "StartDesigns did exactly what you said it does. I have gotten at least 50 times the value from your PHP website development service."

                </p>

              </div>

            </div>

          </div>

        </div>        



      </div>

    </section>

<!-- Expert review end -->



<!-- FAQ Ui -->

<section class="webflowfeatures_services php_page">

  <div class="container">

    <div class="title">

      <h3>Got questions? We've got answers!</h3>

      <h2>FAQ's 

        <a href="" class="typewrite" data-period="2000" data-type='[  "Frequently Asked Questions" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row">

      <div class="col-md-8 col-md-offset-2 faq-main-parent">

          <button class="accordion-faq">What are the technologies or PHP frameworks in which your developers have expertise?</button>

          <div class="panel-faq">

            <p>At StartDesigns, we have a team of developers with 50+ collective experience and expertise to use Laravel, Symfony, CakePHP, Zend Framework, Docker, PHP Unit, Phalcon, Codeigniter, Yii, and Fule PHP.</p>

          </div>



          <button class="accordion-faq">What are different PHP development solutions do you offer?</button>

          <div class="panel-faq">

            <p>We have been providing a wide range of PHP development solutions since 2015. We provide custom PHP development, CMS development, E-commerce development, API development, SaaS development, and maintenance support solutions.</p>

          </div>



          <button class="accordion-faq">Can you help to redesign or redevelop the existing website with the latest PHP version?</button>

          <div class="panel-faq">

            <p>Yes, we offer redesign and development services for existing PHP-based websites. Redevelopment of existing websites boosts performance, functionality, credibility, and security level.</p>

          </div>



          <button class="accordion-faq">Will you provide support after the completion of the project?</button>

          <div class="panel-faq">

            <p>Yes, we provide support after the completion of the project. Our PHP developers make the required changes related to site appearance, content, and layout. We advise you to discuss all project requirements, scope, and other elements.</p>

          </div>

      </div>

    </div>

      



  </div>

</section>



<!-- FAQ Ui end-->



<!--#include file="footer.shtml"-->

    <a href="javascript:" id="return-to-top">

      <i class="fa fa-angle-double-up  " aria-hidden="true">

      </i>

    </a>



<?php include('footer.php'); ?>



<script type="text/javascript" src="js/jquery.js">

</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js">

</script>

<script src="js/jquery.countup.js">

</script>

<script>

$('.counter').countUp();

</script>

<!-- <script src="js/bootstrap.min.js">

</script> -->

<script src="js/owl.carousel.min.js" defer>

</script>

<script src="js/script.js">

</script>

<script src="js/jquery-1.11.1.min.js">

</script>

<script src="js/jquery.validate.min.js">

</script>

<script src="js/additional-methods.min.js">

</script>

<script src="js/slick.min.js" defer>

</script>



<script>

  $(document).ready(function(){

    $('#whychoose-slider').owlCarousel({

  loop: true,

  margin: 10,

  nav: false,  

  autoplay: true,

  autoplayHoverPause: true,

  responsive: {

    0: {

      items: 1

    },

    767: {

      items: 2

    },

    1000: {

      items: 3

    }

  }

})

  })



$(document).ready(function(){

    $('#review-slider').owlCarousel({

  loop: true,

  margin: 10,

  nav: false,  

  autoplay: true,

  autoplayHoverPause: true,

  responsive: {

    0: {

      items: 1

    },

    767: {

      items: 1

    },

    1000: {

      items: 1

    }

  }

})

  })

</script>





</body>

</html>

