<?php include('header.php'); ?>
<!--#include file="header.shtml"-->
          <div class="no-touch m-nav-menusocial">
            <div id="menusocial" class="menu--social1">
              <div class="toggle--social">
                <span class="soundspeaker-icon">
                </span>
              </div>
              <ul class="menu--sub">
                <li class="menu__item--facebook"> 
                  <a target="_blank" itemprop="samAs" class="menu-link sub-menu-link social_event_track_cls" data-title="Facebook" href="#">
                    <i>
                    </i>HB on Facebook
                  </a> 
                </li>
                <li class="menu__item--twitter"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Twitter" href="#">
                    <i>
                    </i> HB on Twitter 
                  </a> 
                </li>
                <li class="menu__item--linkdin"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="LinkedIn" href="#">
                    <i>
                    </i>HB on Linkedin
                  </a> 
                </li>
                <li class="menu__item--google-p"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Google Plus" href="#">
                    <i>
                    </i>HB on Google+
                  </a> 
                </li>
                <li class="menu__item--youtube"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="You Tube" href="#">
                    <i>
                    </i>HB on Youtube
                  </a> 
                </li>
                <li class="menu__item--blog"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Blog" href="#">
                    <i>
                    </i>HB on Blog
                  </a> 
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div id="top-container" style="display:none;">
          <div class="centerdiv">
            <div class="left"> 
              <a href="#" title=""> 
                <img src="images/logo.png" width="261" height="51" alt="" class="logo" /> 
              </a> 
            </div>
            <div class="right" style="width:72%;">
              <div class="r-clear menu-display">
                <div class="search-div">
                  <input type="search" placeholder="Search" name="" />
                </div>
                <span class="link-area">
                  <a target="_blank" title="" href="#">Blog
                  </a>
                  <a title="" href="#" target="_blank">Articles
                  </a>
                  <a title="" href="#">FAQ
                  </a>
                  <a title="" href="#">Careers
                  </a> 
                  <a title="Contact" href="#">Contact
                  </a> 
                  <a title="" href="#">Partnership
                  </a>
                </span> 
              </div>
              <div class="r-clear topmenu">
                <div class="mobile-tablet-menu">
                  <a href="#" class="mobile-menu-home-iclass" id="mobile-menu-home-icon">
                  </a>
                  <div class="mobile-menu-home-contner" id="mobile-menu-home">
                    <ul>
                      <li>
                        <a title="Company" href="#">Company
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Services
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Technology
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Products
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Client
                        </a>
                      </li>
                      <li>
                        <a title="Work" class="work-menu" href="#">Work
                        </a>
                      </li>
                      <li>
                        <a title="Inquiry" href="#" id="inquiry-pop-up" class="active">Get Quote
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
                <ul class="menu-t-menu-new">
                  <li>
                    <a title="startdesigns InfoTech" href="#">
                      <span class="home">
                      </span>
                    </a> 
                  </li>
                  <li>
                    <a title="Company" href="#">Company
                    </a> 
                  </li>
                  <li>
                    <a title="Services" href="#">Services
                    </a> 
                  </li>
                  <li>
                    <a title="Technology" href="#">Technology
                    </a> 
                  </li>
                  <li>
                    <a href="#">Products
                    </a> 
                  </li>
                  <li>
                    <a title="Work" href="#">Work
                    </a> 
                  </li>
                  <li>
                    <a title="Inquiry" href="#" >Get Quote
                    </a> 
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
    <!-- 
<div class="" id="particles-js">
<div class=" heading-particjs" >
<div class="title">
<h1 class="text-center">Contact   <a href="" class="typewrite" data-period="2000" data-type='[  "Us!" ]'></a></h1>
</div>
</div> -->
    </div>
  <section class="add-map-sd">
    <div class="">
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3557.40945609492!2d75.81639521436605!3d26.9222309661629!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db152a95cdb31%3A0x2391eb7b4a6968ad!2sStart+Designs!5e0!3m2!1sen!2sin!4v1565612324156!5m2!1sen!2sin" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen>
      </iframe>
    </div> 
  </section>
  <section  class="sd-contact bg-gray-white">
    <div class="container">
      <div class="row">
        <div class="title">
          <h2>Connect with   
            <a href="" class="typewrite" data-period="2000" data-type='[  "us" ]'> 
            </a>
          </h2>
          <span class="sub-head spc-bt-sub-head">connect with us using any of the following channels
          </span>
        </div>
 
      </div>
      <!-- <div class="row ">     
        <div class="col-md-3 col-sm-6" >
          <div class="conpage-head">              
            <div class="copag-midle">
              <center>
                <div class="con-page-footer">
                  <div class="image">
                    <img src="images/icon-contact-1.png" class="img-responsive">
                  </div>
                  <h5>Our Location
                  </h5>
                  <p>Start Designs, 3rd floor Office No. 308 to 311
                    chandalal kalyanmal complex 
                    kishanpol bazar, Jaipur -302002 
                  </p>
                 
                </div>
              </center>
            </div>
            <div class="space">
            </div>
          </div> 
        </div>  
        <div class="col-md-3 col-sm-6" >
          <div class="conpage-head">              
            <div class="copag-midle">
              <center>
                <div class="con-page-footer">
                  <div class="image">
                    <img src="images/icon-contact-2.png" class="img-responsive">
                  </div>
                  <h5>Phone Number
                  </h5>
                  <p>
                    <img src="images/india.png" width="20"> &nbsp;+91 141 404 4287
                  </p>
                  <p>
                    <img src="images/france.png" width="20"> &nbsp; +33 615101055
                  </p>
                </div>
              </center>
            </div>
            <div class="space">
            </div>
          </div>  
        </div>
        <div class="col-md-3 col-sm-6" >
          <div class="conpage-head">              
            <div class="copag-midle">
              <center>
                <div class="con-page-footer">
                  <div class="image">
                    <img src="images/icon-contact-3.png" class="img-responsive">
                  </div>
                  <h5>Email Id 
                  </h5>
                  <p>info@startdesigns.com 
                    <br> startdeesigns@gmail.com  
                  </p>
                </div>
              </center>
            </div>
            <div class="space">
            </div>
          </div>  
        </div>
        <div class="col-md-3 col-sm-6" >
          <div class="conpage-head">              
            <div class="copag-midle">
              <center>
                <div class="con-page-footer">
                  <div class="image">
                    <img src="images/icon-contact-4.png" class="img-responsive">
                  </div>
                  <h5>Work Hours 
                  </h5>
                  <p>Monday to Saturday  
                    <br> 10.00AM to 7.00PM(IST) 
                  </p>
                </div>
              </center>
            </div>
            <div class="space">
            </div>
          </div> 
        </div>
      </div> -->
      <div class="row contact_us_page">
        <div class="col-md-4">
            <div class="conpage-head">              
            <div class="copag-midle">
              <center>
                <div class="con-page-footer">
                  
                  <h5>Corporate Office</h5>
                  <p><span><img src="img/map.png"></span>Start Designs, 3rd floor Office No. 308 to 311 chandalal kalyanmal complex 
                    kishanpol bazar, Jaipur -302002 
                  </p>
                 
                </div>
                 <div class="con-page-footer">
                  
                  <h5>Development Center</h5>
                  <p><span><img src="img/map.png"></span>A-41, Gopalpura Bypass Rd, 
                    Triveni Nagar, Arjun Nagar, 
                    Jaipur, Rajasthan 302018
                  </p>
                 
                </div>

              </center>
            </div>
            
          </div> 
        </div>
         <div class="col-md-8">
          <div class="conpage-head">              
            <div class="copag-midle">
              <center>
                <div class="con-page-footer">
                  <div class="image">
                    <img src="images/icon-contact-2.png" class="img-responsive">
                  </div>
                  <h5>Phone Number
                  </h5>
                  <p>
                    <img src="images/india.png" width="20"> &nbsp;+91 141 404 4287
                  </p>
                  <!-- <p>
                    <img src="images/france.png" width="20"> &nbsp; +33 615101055
                  </p> -->
                </div>
                <b class="border_css"><hr></b>
                <div class="con-page-footer">
                  <div class="image">
                    <img src="images/icon-contact-3.png" class="img-responsive">
                  </div>
                  <h5>Email Id 
                  </h5>
                  <p>info@startdesigns.com 
                    <br> startdeesigns@gmail.com  
                  </p>
                </div>
                 <b class="border_css"><hr></b>
                 <div class="con-page-footer">
                  <div class="image">
                    <img src="images/icon-contact-4.png" class="img-responsive">
                  </div>
                  <h5>Work Hours 
                  </h5>
                  <p>Monday to Saturday  
                    <br> 10.00AM to 7.00PM(IST) 
                  </p>
                </div>
              </center>
            </div>
          
          </div>  
        </div>
      </div>
    </div>
  </section>
 <!--#include file="footer.shtml"--> 
  <a href="javascript:" id="return-to-top">
    <i class="fa fa-angle-double-up" aria-hidden="true">
    </i>
  </a>
  <!-- get jQuery from the google apis -->
<script type="text/javascript" src="js/jquery.js">
</script>

<script src="js/bootstrap.min.js">
</script>

<script src="js/jquery.validate.min.js">
</script>
<script src="js/additional-methods.min.js">
</script>
<script src="js/jquery.mockjax.js"></script>
<script src="js/jquery.maskedinput.js"></script>
<script src="js/mktSignup.js"></script>
<script src="js/script.js">
</script>
<!-- ================== -->
<script>
// Restricts input for each element in the set of matched elements to the given inputFilter.
(function($) {
  $.fn.inputFilter = function(inputFilter) {
    return this.on("input keydown keyup mousedown mouseup select contextmenu drop", function() {
      //console.log(this.value);
      if (inputFilter(this.value)) {
        this.oldValue = this.value;
        this.oldSelectionStart = this.selectionStart;
        this.oldSelectionEnd = this.selectionEnd;
      } else if (this.hasOwnProperty("oldValue")) {
        this.value = this.oldValue;
        this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
      }
    });
  };
}(jQuery));
$(".comm_phone_number").inputFilter(function(value) {
  return /^\d*$/.test(value) && (value === "" || parseInt(value) <= 9999999999); 
});

(function(i,s,o,g,r,a,m){
  i['GoogleAnalyticsObject']=r;
  i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)}
    ,i[r].l=1*new Date();
  a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];
  a.async=1;
  a.src=g;
  m.parentNode.insertBefore(a,m)
}
)(window,document,'script','//www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-67094806-1', 'auto');
ga('send', 'pageview');





$( "#inquiryForm" ).validate({
  rules: {
    // simple rule, converted to {required:true}
    name: "required",
    // compound rule
    email: {
      required: true,
      email: true
    }
    ,
    phone: {
      number: true,
      required: true,
    },
   
    user_budget: "required",
    'inq_service[]': {
      required: true,
      minlength: 1  }
    ,
    information:"required",
    inquiry_file: {
      //required: true,
      accept: "image/png, pdf, docx, jpeg, jpg, excel",
      
    }
  },
  messages: {
    name: "Please enter your name",
    email: {
      required: "Please enter a  email address",
      email: "Please enter a valid email address",
     // remote: jQuery.validator.format("{0} is already in use")

    },
    phone:{
        required:"Please enter a number",
        number: "Please enter 10 digit",
      },
    'inq_service[]': "please select any requirment",
    information: "Please enter your describe",
    inquiry_file: "Please upload a valid file",
    user_budget: "Please select any one",
  },errorPlacement: function(error, element) {
        if (element.attr("name") == "inq_service[]") {
            error.appendTo("#error-inquiry");
        } else {
            error.insertAfter(element);
        }
    }
  ,submitHandler: function(form) {
    // do other things for a valid form
    //form.submit();
    submit_by_quote();
  }
});
function submit_by_quote(){
  $.ajax({
    type: "POST",
    url: "quote_ajax.php",
    dataType: "json",
    data: $("#inquiryForm").serialize(),
    success: function(response) {
       if(response.status)
        {
          $("#quote_response").empty().html('<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+response.message+'</div>');
          document.getElementById("inquiryForm").reset();
           setTimeout(function(){  $('#quote_response').empty();}, 3000);
        }
        else {
          $("#quote_response").empty().html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+response.message+'</div>');
        }
      }
    ,
    error: function(data) {
      console.log("error in ajax request");
    }
  }
        ).done(function() {
    console.log("ajax request complete");
  });
}
</script>

<script type="text/javascript">
  $(document).ready(function(){
  $(".add-get-bodyclass").click(function(){
    $(".homebody").addClass("getqueto-scrool");
  });

  $(".close-popupbtns").click(function(){
    $(".homebody").removeClass("getqueto-scrool");
  });
});
</script>


</body>
</html>

<?php include('footer.php'); ?>