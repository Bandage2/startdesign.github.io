<?php header("Access-Control-Allow-Origin: *"); ?>
<h2>Hello World</h2>
<p>It is use to bid the dlkfjlfjdlkllskfjsfjls</p>
<span>sjfhsakjdfhdsakhdsakjfhdsajfhkdsajhfsda</span>