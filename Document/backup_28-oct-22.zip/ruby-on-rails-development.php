 <?php include('header.php'); ?>

<!--#include file="header.shtml"-->

          <div class="no-touch m-nav-menusocial">

            <div id="menusocial" class="menu--social1">

              <div class="toggle--social">

                <span class="soundspeaker-icon">

                </span>

              </div>

              <ul class="menu--sub">

                <li class="menu__item--facebook"> 

                  <a target="_blank" itemprop="samAs" class="menu-link sub-menu-link social_event_track_cls" data-title="Facebook" href="#">

                    <i>

                    </i>HB on Facebook

                  </a> 

                </li>

                <li class="menu__item--twitter"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Twitter" href="#">

                    <i>

                    </i> HB on Twitter 

                  </a> 

                </li>

                <li class="menu__item--linkdin"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="LinkedIn" href="#">

                    <i>

                    </i>HB on Linkedin

                  </a> 

                </li>

                <li class="menu__item--google-p"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Google Plus" href="#">

                    <i>

                    </i>HB on Google+

                  </a> 

                </li>

                <li class="menu__item--youtube"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="You Tube" href="#">

                    <i>

                    </i>HB on Youtube

                  </a> 

                </li>

                <li class="menu__item--blog"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Blog" href="#">

                    <i>

                    </i>HB on Blog

                  </a> 

                </li>

              </ul>

            </div>

          </div>

        </div>

        <div id="top-container" style="display:none;">

          <div class="centerdiv">

            <div class="left"> 

              <a href="#" title=""> 

                <img src="images/logo.png" width="261" height="51" alt="" class="logo" /> 

              </a> 

            </div>

            <div class="right" style="width:72%;">

              <div class="r-clear menu-display">

                <div class="search-div">

                  <input type="search" placeholder="Search" name="" />

                </div>

                <span class="link-area">

                  <a target="_blank" title="" href="#">Blog

                  </a>

                  <a title="" href="#" target="_blank">Articles

                  </a>

                  <a title="" href="#">FAQ

                  </a>

                  <a title="" href="#">Careers

                  </a> 

                  <a title="Contact" href="#">Contact

                  </a> 

                  <a title="" href="#">Partnership

                  </a>

                </span> 

              </div>

              <div class="r-clear topmenu">

                <div class="mobile-tablet-menu">

                  <a href="#" class="mobile-menu-home-iclass" id="mobile-menu-home-icon">

                  </a>

                  <div class="mobile-menu-home-contner" id="mobile-menu-home">

                    <ul>

                      <li>

                        <a title="Company" href="#">Company

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Services

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Technology

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Products

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Client

                        </a>

                      </li>

                      <li>

                        <a title="Work" class="work-menu" href="#">Work

                        </a>

                      </li>

                      <li>

                        <a title="Inquiry" href="#" id="inquiry-pop-up" class="active">Get Quote

                        </a>

                      </li>

                    </ul>

                  </div>

                </div>

                <ul class="menu-t-menu-new">

                  <li>

                    <a title="startdesigns InfoTech" href="#">

                      <span class="home">

                      </span>

                    </a> 

                  </li>

                  <li>

                    <a title="Company" href="#">Company

                    </a> 

                  </li>

                  <li>

                    <a title="Services" href="#">Services

                    </a> 

                  </li>

                  <li>

                    <a title="Technology" href="#">Technology

                    </a> 

                  </li>

                  <li>

                    <a href="#">Products

                    </a> 

                  </li>

                  <li>

                    <a title="Work" href="#">Work

                    </a> 

                  </li>

                  <li>

                    <a title="Inquiry" href="#">Get Quote

                    </a> 

                  </li>

                </ul>

              </div>

            </div>

          </div>

        </div>

      </div>

    </header>



    <!-- Banner top- contact end -->



    <section class="service-topbanner rorbannerbg">

      <!-- <div style="background-image: url(images/webbackgroundimg.png);"> -->

      <div class="container">

          <div class="row service-flex">

              <div class="col-md-6">

                <div class="mainservicetopbanner">

                  <h3>Ruby on Rails Development Company</h3>

                  <h1 class="wordpress_head">Ruby on Rails Development Services</h1>

                  <p>Are you looking for a Ruby on Rails developer? Your hunt ends here. Hire Start Designs for a more efficient, robust, and scalable application. Our highly experienced developers work substantially to deliver you the application you desire to help you achieve your targeted goals.</p>

                  <div class="dflex">

                    <a href="#foooter_form" class="btn btn-contactsupport-blk">Contact Support →</a>

                    <a href="#" class="btn btn-startproject">Start Project →</a>

                  </div>                  

                </div>

              </div>

              <div class="col-md-6">

                <div class="rightside-topbanner rorbanner-top">

                  <img src="images/rorbanner1.png" alt="banner-img">

                </div>

              </div>

          </div>

      </div>

      <!-- </div> -->

    </section>





        <!-- About ROR start -->

    <section class="about-reactjs web3-page">

      <div class="container">

        <!-- <div class="title">    

          <h3>Creating Dapps applications with Web3.JS</h3>  

          <h2>What is

            <a href="" class="typewrite" data-period="2000" data-type='[  "Web3.JS Development? " ]'> 

            </a>

          </h2>

        </div> -->



        <div class="row row-waffer">            



          <div class="col-md-6 web3-contents">     

          <h2>What is <span class="web-theme-color">Ruby On Rails?</span></h2>       

            <p class="para">Ruby On Rails is a full-stack framework written in Ruby under the MIT License. It goes well with all the tools one needs to create impressive web apps on both the front and back ends. Rails is a model-view-controller (MVC) framework that provides default structures for a database, a web service, and web pages. Rails render HTML templates, update databases, send and receive emails, maintain live pages via WebSockets, queue jobs for asynchronous work, store uploads in the cloud, and provide solid security protections for common attacks.                

            </p>



            <div class="advantages-hiring-list">

                <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                     It is best for creating interactive and robust online stores. 

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                    It is also an excellent option for creating efficient stock marketing platforms. 

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                    It is also beneficial for creating Social Networking sites.

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                    Due to its accessible building features, using it to create Saas solutions is the optimum choice.

                  </div>

                </div>              

              </div>                                   

          </div>



          <div class="col-md-6">

              <div class="img_outer">

                <div class="reactleftimages">

                  <img src="images/banner-img.png" class="responsive web-smal floating" alt="image">

                </div>

              </div>                

          </div>

        </div>

      </div>

    </section>

    <!-- About ROR ends -->



    <!-- ROR services partner -->

<section class="webflowfeatures_services ror-page">

  <div class="container">

    <div class="title">      

      <h2>Our Ruby On Rails 

        <a href="#" class="typewrite" data-period="2000" data-type='[  "Development Services " ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row weoffer-row1">

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/integration-color.png"></div>              

            </div>

            <h4>Ruby on Rails Migrations Services</h4>

            <span class="sub-head">Our highly skilled professionals are here to help you migrate to the latest version of Ruby on Rails for a better and secure platform. We will make the migration process seamless and safe for you with our expertise and constant communication.

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/currency-exchange.png"></div>             

            </div>

             <h4>Advanced Ruby on Rails Programming</h4>

            <span class="sub-head">At Start Designs, we will help you achieve your targeted goals with advanced RoR programming. Our highly experienced professionals are acquainted with monolithic systems, containers, serverless solutions, AWS and can proficiently apply this knowledge to build adaptable and robust applications for you.

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/app-color.png"></div>              

            </div>

            <h4>Ruby on Rails CMS Development</h4>

            <span class="sub-head">At Start Designs, we provide you with smooth and hassle-free CMS installation and development. Our Ruby on Rails professionals are very well acquainted with all the CMS platforms: Refinery, MIT, Alchemy, Comfortable Mexican Sofa, Camaleon, Spina, Locomotive, Fae, Radiant, and others. 

            </span>

          </div>

        </div>

      </div>     



    </div>

      <div class="row weoffer-row2">

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent ">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/ethereum.png"></div>              

            </div>

            <h4>Ruby on Rails Services For Startups /Enterprises</h4>

            <span class="sub-head">At Start Designs, we provide the best deals to startups and enterprises on Ruby on Rails development. We understand your needs and work consistently and transparently in order to deliver the assignments on time.

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

            <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/coin.png"></div>             

            </div>

             <h4>Ruby on Rails Optimization and Integration</h4>

            <span class="sub-head">Our highly knowledgeable developers make the optimization and integration process seamless and swift. We can help you optimize your existing Ruby on Rails platform with updates and integrate with the latest version of RoR. 

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

           <div class= "DamlContentHead">

              <div class="pink_bordr_icon"><img src="images/drupal4.png"></div>              

            </div>

            <h4>Ruby on Rails e-Commerce Applications</h4>

            <span class="sub-head">Our highly skilled developers with over a decade of experience in Ruby on Rails will deliver you flexible, efficient, and robust e-commerce platforms. We understand your business needs and market trends, leading to an e-commerce platform that fulfills all the consumers' needs and your vision. 

            </span>

          </div>

        </div>

      </div>      

    </div>



  </div>

</section>

<!-- ROR services Ends--->



<!-- Why usRuby On Rails Development partner  -->

  <section class="stripe_advantge ror-page">

    <div class="container">

        <div class="title">

          <!-- <h3>We build beautiful Webflow websites that engage your audience.</h3> -->

          <h2>Why We Are Reliable 

            <a href="#" class="typewrite" data-period="2000" data-type='[  "Ruby On Rails Development Partners? " ]'> 

            </a>

          </h2>

        </div>         

              <div class="row service-flex"> 



                  <div class="col-md-6">

                  <div class="img_outer">

                    <div class="cmileftimages">

                      <img src="images/development-procss.jpg" class="responsive web-smal floating" alt="image">

                    </div>

                  </div>                

                  </div>



                  <div class="col-md-6">

                    <div class="mainservicetopbanner features-title">

                      <!-- <h3>We used best strategy</h3> -->

                      <h2>We used best <span class="sd-web-pink">tools</span></h2>

                      <div class="advantages-hiring-list">

                    <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                         We believe in giving a realistic timeline and completing the project within that timeline.

                      </div>

                    </div>

                     <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                        We have extensive experience in Ruby on Rails development. We have successfully dealt with all the aspects of RoR.

                      </div>

                    </div>

                     <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                        We deliver the projects with high-quality code. All our developers work vigilantly to maintain the codes' quality throughout the project.

                      </div>

                    </div>    

                     <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                        We develop highly scalable and secure systems with our unique architecture implementation.

                      </div>

                    </div> 

                     <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                        We give you the best deals on any service you avail, no matter how big or small the task is. We have different payment arrangements available, you can choose accordingly.

                      </div>

                    </div> 

                     <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                        We deploy agile methodology for cost-effective and fast delivery.

                      </div>

                    </div>           

                  </div>                      

                      <!-- <div class="dflex">

                        <a href="#" class="btn btn-contactsupport btn-mrgn-top">Start a Project</a>

                      </div> -->

                    </div>

                  </div>  

                                              

              </div>             

    </div>

  </section>

    <!-- Why us ROR Developmentr ends -->





        <!-- Benefit ROR start -->

    <section class="about-reactjs ror-benefit">

      <div class="container">

        <!-- <div class="title">   

          <h2>Benefits Of

            <a href="" class="typewrite" data-period="2000" data-type='[  "Web3.JS" ]'> 

            </a>

          </h2>

        </div> -->



        <div class="row row-waffer">           



          <div class="col-md-6 ror-contents">    

            <h2>Benefits Of <span class="web-theme-color">Ruby On Rails</span></h2>           

            <!-- <p class="para">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.                      

            </p> -->



            <div class="mian_box">

              <div class="ui_icon"><img src="images/lightning.png" alt=""></div>

                <div class="ui_datas">

                  <p class="ui_datashead">Fast and Productive</p>

                  <p class="ui_datasval">Ruby on Rails is a fast and productive programming language. Many third-party libraries are available for developers to use, increasing their productivity and saving time.</p>

                </div>

              </div>                                      



            <div class="mian_box">

              <div class="ui_icon"><img src="images/drupal5.png" alt=""></div>

                <div class="ui_datas">

                  <p class="ui_datashead">Extensive libraries</p>

                  <p class="ui_datasval">Ruby on Rails has many libraries available, which exposes developers to functionalities they would not have been able to achieve with other programming languages.</p>

                </div>

              </div>                            

            

            <div class="mian_box">

              <div class="ui_icon"><img src="images/contentt.png" alt=""></div>

                <div class="ui_datas">

                  <p class="ui_datashead">Dedicated Community</p>

                  <p class="ui_datasval">Ruby on Rails has a community of dedicated developers who are always ready to help their fellow developers and contribute rich code libraries that other developers could use.</p>

                </div>

              </div>  



              <div class="mian_box">

              <div class="ui_icon"><img src="images/reuseable.png" alt=""></div>

                <div class="ui_datas">

                  <p class="ui_datashead">Flexibility</p>

                  <p class="ui_datasval">Ruby on Rails is a very flexible language permitting web applications to use the frontend and backend capabilities of Rails.</p>

                </div>

              </div>



              <div class="mian_box">

              <div class="ui_icon"><img src="images/protectioon.png" alt=""></div>

                <div class="ui_datas">

                  <p class="ui_datashead">Secure</p>

                  <p class="ui_datasval">The topmost benefit of Ruby on Rails is its security. It pays particular attention to the Secured development process, which owns robust security features which are built-in and enabled by default.</p>

                </div>

              </div>                           

          </div>



          <div class="col-md-6">

              <div class="img_outer">

                <div class="reactleftimages">

                  <img src="images/ror-benefit.png" class="responsive web-smal floating" alt="image">

                </div>

              </div>                

          </div>

        </div>

      </div>

    </section>

    <!-- Benefit ROR ends -->



<!-- Recent work -->

<!-- <section class="recentwork-section cmi-recent php_page">

  <div class="container">

    <div class="title">

      <h5>Pour a brew and peruse our goods</h5>

      <h2>Ruby On Rails Development

        <a href="" class="typewrite" data-period="2000" data-type='[  "Recent Works" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row recentworkRow">

      <div class="col-md-3 col-sm-6">

        <a href="#" class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/vacationsbyrail.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Vacations By Rail</h4>

                  <span class="sub-head">USA based Travel company website development

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

        <a href="#" class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/networkadvertising.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Network Advertising</h4>

                  <span class="sub-head"> USA based networking company website development and design

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

       <a href="#" class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/nomorobo.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Nomorobo</h4>

                  <span class="sub-head">USA based Technology And Computing company website development

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

        <a href="#" class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/technicpack.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Technic pack</h4>

                  <span class="sub-head">USA based Technology And Computing company website development

                  </span>

            </div>

          </div>

        </a>

      </div>

    </div>

  </div>

</section> -->



<!-- Recent work end-->

 

<!-- Expert review -->

  <section class="section-testimonials reveiw_slide ror-page bg-white">

      <div class="container">

        <div class="row">

          <div class="title">

            <h3>Testimony from our happy clients</h3>

            <h2>What do client say about 

              <a href="#" class="typewrite" data-period="2000" data-type='[  "Ruby On Rails Expert" ]'> 

              </a>

            </h2>

          </div>

        </div>

       

        <div id="review-slider" class="owl-carousel">

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn16.png" alt="">

                  <div class="user-details-services">

                    <h4>John Doe</h4>

                    <p>Ruby On Rails Expert</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                "Nice work on your StartDesigns ROR services. It's the perfect solution for our business."
                

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn26.png" alt="">

                  <div class="user-details-services">

                    <h4>Selina W.</h4>

                    <p>Ruby On Rails Expert</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  
                  "I would gladly pay for StartDesigns ROR website design and development service. The very best. It's incredible."
                

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn9.png" alt="">

                  <div class="user-details-services">

                    <h4>Jhon Thomas</h4>

                    <p>Ruby On Rails Expert</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">
                  
                  "I have used StartDesigns ROR design and development service a couple of times and I am very happy with the results each time."
                
                </p>

              </div>

            </div>

          </div>

        </div>        



      </div>

    </section>

<!-- Expert review end -->





<!-- FAQ Ui -->

<section class="webflowfeatures_services presta_faq">

  <div class="container">

    <div class="title">

      <h3>Got questions? We've got answers!</h3>

      <h2>FAQ's 

        <a href="#" class="typewrite" data-period="2000" data-type='[  "Frequently Asked Questions" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row">

      <div class="col-md-8 col-md-offset-2 faq-main-parent">

          <button class="accordion-faq">What is Ruby on Rails?</button>

          <div class="panel-faq">

            <p>Ruby on Rails(RoR) is a server-side web development framework based on Ruby as the programming language. We have a team of RoR developers who build interactive, robust, and feature-rich websites and web applications.</p>

          </div>



          <button class="accordion-faq">What is Ruby on Rails used for?</button>

          <div class="panel-faq rubys_faqs">

            <p>RoR is best for the types of projects like:</p>

            <ul class="faq-navbar">

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> E-commerce </li>

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> Informational portals </li>

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> Stock exchange platforms </li>

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> Dating websites and ad platforms </li>

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> Social networks </li>

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> Non-standard complex projects </li>

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> SaaS-solutions </li>

            </ul>

            <p>Basecamp, Airbnb, Shopify, Goodreads, Kickstarter, and Hulu are some of the companies using RoR.</p>

          </div>



          <button class="accordion-faq">Is choosing RoR cost-effective and speeds up the development process?</button>

          <div class="panel-faq">
            <p>RoR provides cost effective solutions:</p>

            <ul class="faq-navbar">

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> It's open-source, so there is no cost of using a framework. </li>

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> RoR is clearer, simpler, and has code libraries(gems) that allow developers to write less code simultaneously, boosting the speed of programming. So, projects are done faster, and client time is money.

			 </li>

            </ul>

          </div>

      </div>

    </div>

      



  </div>

</section>



<!-- FAQ Ui end-->



<!--#include file="footer.shtml"-->

    <a href="javascript:" id="return-to-top">

      <i class="fa fa-angle-double-up  " aria-hidden="true">

      </i>

    </a>



<?php include('footer.php'); ?>



<script type="text/javascript" src="js/jquery.js">

</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js">

</script>

<script src="js/jquery.countup.js">

</script>

<script>

$('.counter').countUp();

</script>

<script src="js/bootstrap.min.js">

</script>

<script src="js/owl.carousel.min.js" defer>

</script>

<script src="js/script.js">

</script>

<script src="js/jquery-1.11.1.min.js">

</script>

<script src="js/jquery.validate.min.js">

</script>

<script src="js/additional-methods.min.js">

</script>

<script src="js/slick.min.js" defer>

</script>









<!-- ----------testimony slider------- -->

<script>

$(document).ready(function(){

    $('#review-slider').owlCarousel({

  loop: true,

  margin: 10,

  nav: false,  

  autoplay: true,

  autoplayHoverPause: true,

  responsive: {

    0: {

      items: 1

    },

    767: {

      items: 1

    },

    1000: {

      items: 1

    }

  }

})

  })

</script>



<!-- --------case study slider---- -->

<script >

    $(document).ready(function(){

      $("#expertisecarousel").owlCarousel({

      autoplay: true,

      rewind: true, 

      margin: 20,  

      responsiveClass: true,

      autoHeight: true,

      autoplayTimeout: 7000,

      smartSpeed: 800,

      nav: false,

      responsive: {

        0: {

          items: 1

        },



        600: {

          items: 1

        },



        1024: {

          items: 1

        },



        1366: {

          items: 1

        }

      }

      });

    })

</script>



</body>

</html>

