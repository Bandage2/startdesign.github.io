 <?php include('header.php'); ?>

<!--#include file="header.shtml"-->

          <div class="no-touch m-nav-menusocial">

            <div id="menusocial" class="menu--social1">

              <div class="toggle--social">

                <span class="soundspeaker-icon">

                </span>

              </div>

              <ul class="menu--sub">

                <li class="menu__item--facebook"> 

                  <a target="_blank" itemprop="samAs" class="menu-link sub-menu-link social_event_track_cls" data-title="Facebook" href="#">

                    <i>

                    </i>HB on Facebook

                  </a> 

                </li>

                <li class="menu__item--twitter"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Twitter" href="#">

                    <i>

                    </i> HB on Twitter 

                  </a> 

                </li>

                <li class="menu__item--linkdin"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="LinkedIn" href="#">

                    <i>

                    </i>HB on Linkedin

                  </a> 

                </li>

                <li class="menu__item--google-p"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Google Plus" href="#">

                    <i>

                    </i>HB on Google+

                  </a> 

                </li>

                <li class="menu__item--youtube"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="You Tube" href="#">

                    <i>

                    </i>HB on Youtube

                  </a> 

                </li>

                <li class="menu__item--blog"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Blog" href="#">

                    <i>

                    </i>HB on Blog

                  </a> 

                </li>

              </ul>

            </div>

          </div>

        </div>

        <div id="top-container" style="display:none;">

          <div class="centerdiv">

            <div class="left"> 

              <a href="#" title=""> 

                <img src="images/logo.png" width="261" height="51" alt="" class="logo" /> 

              </a> 

            </div>

            <div class="right" style="width:72%;">

              <div class="r-clear menu-display">

                <div class="search-div">

                  <input type="search" placeholder="Search" name="" />

                </div>

                <span class="link-area">

                  <a target="_blank" title="" href="#">Blog

                  </a>

                  <a title="" href="#" target="_blank">Articles

                  </a>

                  <a title="" href="#">FAQ

                  </a>

                  <a title="" href="#">Careers

                  </a> 

                  <a title="Contact" href="#">Contact

                  </a> 

                  <a title="" href="#">Partnership

                  </a>

                </span> 

              </div>

              <div class="r-clear topmenu">

                <div class="mobile-tablet-menu">

                  <a href="#" class="mobile-menu-home-iclass" id="mobile-menu-home-icon">

                  </a>

                  <div class="mobile-menu-home-contner" id="mobile-menu-home">

                    <ul>

                      <li>

                        <a title="Company" href="#">Company

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Services

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Technology

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Products

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Client

                        </a>

                      </li>

                      <li>

                        <a title="Work" class="work-menu" href="#">Work

                        </a>

                      </li>

                      <li>

                        <a title="Inquiry" href="#" id="inquiry-pop-up" class="active">Get Quote

                        </a>

                      </li>

                    </ul>

                  </div>

                </div>

                <ul class="menu-t-menu-new">

                  <li>

                    <a title="startdesigns InfoTech" href="#">

                      <span class="home">

                      </span>

                    </a> 

                  </li>

                  <li>

                    <a title="Company" href="#">Company

                    </a> 

                  </li>

                  <li>

                    <a title="Services" href="#">Services

                    </a> 

                  </li>

                  <li>

                    <a title="Technology" href="#">Technology

                    </a> 

                  </li>

                  <li>

                    <a href="#">Products

                    </a> 

                  </li>

                  <li>

                    <a title="Work" href="#">Work

                    </a> 

                  </li>

                  <li>

                    <a title="Inquiry" href="#">Get Quote

                    </a> 

                  </li>

                </ul>

              </div>

            </div>

          </div>

        </div>

      </div>

    </header>



    <!-- Banner top- contact end -->



    <section class="service-topbanner uiuxbgcolor">

      <div class="container">

          <div class="row service-flex">

              <div class="col-md-6">

                <div class="mainservicetopbanner">

                  <h3>Hire Certified UI/UX Expert</h3>

                  <h1>UI/UX Experts</h1>

                  <p>When your mobile app and website are well designed and interactive, it becomes more efficient and speaks to the user on a personal level. Here at Start Designs, our UI/UX experts design a platform that is an amalgamation of your vision and market trends. Resulting in a masterpiece that will derive you more conversions. </p>

                  <div class="dflex">

                    <a href="#foooter_form" class="btn btn-contactsupport">Contact Support →</a>

                    <a href="#" class="btn btn-startproject" id="projectmodel" data-toggle="modal" data-target="#startproject">Start Project →</a>

                  </div>                  

                </div>

              </div>

              <div class="col-md-6">

                <div class="rightside-topbanner wpbanner-top">

                  <img src="images/ux-ui-designer.png">

                </div>

              </div>

          </div>

      </div>

    </section>



        <!-- why hire ui-ux start -->

     <section class="service-awardwinning ui_award">

      <div class="container">

          <div class="row service-flex">



              <div class="col-md-6">

                <div class="mainservicetopbanner">

                  <!-- <h3>Grow Your eCommerce Business with PrestaShop </h3> -->

                  <h2>Why Hire <span class="sd-web-pink">UI/UX Designer</span></h2>

                  <p class="para">UI/UX is a crucial part of your website or mobile app as it defines the user experience. An amazing user interface develops a sense of trust in the user turning him into a potential consumer of your service or product. Highly experienced UI/UX designers at start designs can help you create an interactive platform keeping your targeted audience in mind to derive more sales for your business.  </p>

                  

                  <div class="advantages-hiring-list">

                    <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                         Faster and more engaging pages

                      </div>

                    </div>

                     <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                        Drive conversion & customer loyalty

                      </div>

                    </div>

                     <div>

                       <div class="advantage-icon">

                        <i class="fa fa-check" aria-hidden="true"></i>

                      </div>

                      <div class="advantage-text">

                        Enhance branding

                      </div>

                    </div>

              

                  </div>               

                </div>

              </div>



            <div class="col-md-6">

                <div class="leftside-img advantages-hiring-img">

                  <img src="images/ux-ui-left.svg" class="responsive floating">

                </div>

              </div>

              

          </div>

      </div>

    </section>

    <!-- why hire ui-ux end -->



    <!-- ui-ux Services we offer start -->

<section class="webflowfeatures_services ui_box">

  <div class="container">

    <div class="title">

      <h2>UI/UX    

        <a href="" class="typewrite" data-period="2000" data-type='[  "Design Solutions" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row weoffer-row1">

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

            <div class="service_icon"><img src="images/ux-design.png"></div>

            <h4>Web UI UX Design</h4>

            <span class="sub-head">Get a well-designed website with the help of our experts. They design based on the latest market trends, consumer behaviour mixed with aesthetics. And will deliver you a website with interactive features that will make the user experience more friendly.             

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

            <div class="service_icon"><img src="images/dashboard-ui.png"></div>

            <h4>Dashboard Interface Design</h4>

            <span class="sub-head">Get a more simplified and comprehensible dashboard with the help of our experts. A dashboard provides key performance indicators related to a particular business or objective. Our designers deliver you a dashboard that presents all the information, trends in a consolidated way.            

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

            <div class="service_icon"><img src="images/custom-development.png"></div>

            <h4>Custom software Interface</h4>

            <span class="sub-head">Get the most original and fresh games developed by our highly creative and talented team. At Start Designs, we work towards creating a great consumer experience that includes imaginative game design, with great art, and technical capabilities. Also, these games are developed by our highly capable developers, which build cross-platform and cross-browser experiences.         

            </span>

          </div>

        </div>

      </div>

    </div>

      <div class="row weoffer-row2">

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

            <div class="service_icon"><img src="images/app-ui.png"></div>

            <h4>Mobile app UI and UX Design</h4>

            <span class="sub-head">Get a simplified mobile application using a UI and UX design for a great user experience for handheld devices. At Start Designs, our designers meet your exact requirements and restrictions. Also, our main focus is on accessibility, discoverability, and efficiency to give customers the most interactive experiences.         

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

            <div class="service_icon"><img src="images/prototype-ui.png"></div>

            <h4>Wireframes And Prototypes</h4>

            <span class="sub-head">At Start Designs, we propose to you the most exclusive website wireframes and prototypes, keeping all your requirements in mind. The developers extensively research and create the most engaging Visual details to get your customers the perfect interaction that they are looking for. Which all together makes your web product more consumer-targeted.       

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

            <div class="service_icon"><img src="images/game-ui.png"></div>

            <h4>Game UI UX Design </h4>

            <span class="sub-head">Get the most original and fresh games developed by our highly creative and talented team. At Start Designs, we work towards creating a great consumer experience that includes imaginative game design, with great art, and technical capabilities. Also, these games are developed by our highly capable developers, which build cross-platform and cross-browser experiences.        

            </span>

          </div>

        </div>

      </div>

     

    </div>

  </div>

</section>



<!-- ui-ux Services we offer  end-->



<!-- ui-design-skill start -->

<section class="design-skills ux_page">

  <div class="container">

    <div class="title">

      <h2>Tools and Technology Used by 



        <a href="" class="typewrite" data-period="2000" data-type='[  "UI/UX Designers" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row design-row1">



      <div class="col-md-3">

        <div class="skillBox newDml">

          <div class="skillContent">

            <div class="skill_icon"><img src="images/photoshop 1.svg"></div>

            <h4>Adobe Photoshop</h4>

          </div>

        </div>

      </div>



      <div class="col-md-3">

        <div class="skillBox newDml">

          <div class="skillContent">

            <div class="skill_icon"><img src="images/adobe-xd 1.svg"></div>

            <h4>Adobe XD</h4>

          </div>

        </div>

      </div>



      <div class="col-md-3">

        <div class="skillBox newDml">

          <div class="skillContent">

            <div class="skill_icon"><img src="images/figma 1.svg"></div>

            <h4>Figma</h4>

          </div>

        </div>

      </div>



      <div class="col-md-3">

        <div class="skillBox newDml">

          <div class="skillContent">

            <div class="skill_icon"><img src="images/invision 1.svg"></div>

            <h4>Invision</h4>

          </div>

        </div>

      </div>

     

    </div>



      <div class="row design-row2">

      <div class="col-md-3">

        <div class="skillBox newDml">

          <div class="skillContent">

            <div class="skill_icon"><img src="images/protopie 1.svg"></div>

            <h4>Protopie</h4>

          </div>

        </div>

      </div>



      <div class="col-md-3">

        <div class="skillBox newDml">

          <div class="skillContent">

            <div class="skill_icon"><img src="images/sketch 1.svg"></div>

            <h4>Sketch</h4>

          </div>

        </div>

      </div>



      <div class="col-md-3">

        <div class="skillBox newDml">

          <div class="skillContent">

            <div class="skill_icon"><img src="images/zeplin 1.svg"></div>

            <h4>Zeplian</h4>

          </div>

        </div>

      </div>



      <div class="col-md-3">

        <div class="skillBox newDml">

          <div class="skillContent">

            <div class="skill_icon"><img src="images/framer 2.svg"></div>

            <h4>Framer</h4>

          </div>

        </div>

      </div>     

    </div>

  </div>

</section>



<!-- ui-ux Services we offer  end-->



  



    <!-- ui-ux Benefits start -->

<section class="webflowfeatures_services ui_benefits">

  <div class="container">

    <div class="title">

      <h2>Benefits Of Hiring    

        <a href="" class="typewrite" data-period="2000" data-type='[  "UI/UX Designer" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row weoffer-row1">

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

            <div class="service_icon"><img src="images/vision.png"></div>

            <h4>Map Out A Journey</h4>

            <span class="sub-head">See your vision come true with us. At start Designs, we help you reach your goal with utmost commitment and a transparent process. We help you set targets and understanding your users more closely. We work with you throughout your journey and make it sleek and simplified in order to achieve your goals.             

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

            <div class="service_icon"><img src="images/web-function.png"></div>

            <h4>Ensure Optimal Function </h4>

            <span class="sub-head">Our highly experienced UI/UX developer ensures the optimal functioning of your web product and letting the user pursue their goal as effectively as possible. Engaging the user for a longer time and make them take the actions benefitting your business.            

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

            <div class="service_icon"><img src="images/client-ui.png"></div>

            <h4>Keep Your Clients Coming </h4>

            <span class="sub-head">At start Designs, our experts work diligently to deliver a product that makes your clients' experience more aesthetic and smooth. Our excellent UI/UX designers work to create a system that holds the attention of the client and creates a sense of trust, making them your constant client.         

            </span>

          </div>

        </div>

      </div>

    </div>

      <div class="row weoffer-row2">

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

            <div class="service_icon"><img src="images/user-ui.png"></div>

            <h4>Understand The User </h4>

            <span class="sub-head">At Start Designs, we not only understand all your requirements, but we also understand what your client wants. Our experts do extensive research on market trends after acknowledging all your requirements. Delivering you a product with an interactive interface that helps you score more conversions.        

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

            <div class="service_icon"><img src="images/transparency-ui.png"></div>

            <h4>Integrity And Transparency </h4>

            <span class="sub-head">Our company runs on Integrity and Transparency. These two are very crucial principles that we follow with absolute sincerity. We don't believe in hidden or unfair charges and you can always monitor the progress of your project with us. We work on the outline decided at the beginning of the project and consider it concluded after your complete satisfaction only.        

            </span>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="damlBox newDml">

          <div class="DamlContent">

            <div class="service_icon"><img src="images/trust-ui.png"></div>

            <h4>Trusted and Skilled </h4>

            <span class="sub-head">At Start Designs, we provide you with highly experienced designers and developers that deliver you a product with the most engaging visual details. We are one of the most trusted companies in this field with numerous positive reviews. Our main goal is to deliver a dynamic and efficient output.         

            </span>

          </div>

        </div>

      </div>

     

    </div>

  </div>

</section>



<!-- ui-ux benefits end-->



<!-- Our Hiring Standards -->

<section class="webflow-platform ui-platform" >

        <div class="container">

           <div class="title">

          <!--  <h3>Get a complete Drupal solution on a single platform.</h3> -->

          <h2>Our Hiring  

            <a href="" class="typewrite" data-period="2000" data-type='[  "Standards" ]'> 

            </a> 

          </h2>

          </div>



        <div class="row alignitemcenter">        

          <div class="col-md-6">

            <div class="mainservicetopbanner">

                  <!-- <h3>Unlimited listing, Multi store management, and Robust</h3> -->

                  <h2>We have flexible hiring modules to choose from that focus on the need of businesses.</h2>

                  

                  <div class="mian_box">

                    <div class="ui_icon"><img src="images/hiring-icon.png" alt=""></div>

                    <div class="ui_datas">

                      <p class="ui_datashead">Fixed Rate Hiring</p>

                      <p class="ui_datasval">You can hire us on the basis of fixed rates. In which, we discuss all the requirements and details at the beginning of the project and quote you a fixed price accordingly. </p>

                    </div>

                  </div>             



                  <div class="mian_box">

                    <div class="ui_icon"><img src="images/hired.png" alt=""></div>

                    <div class="ui_datas">

                      <p class="ui_datashead">Dedicated Hiring </p>

                      <p class="ui_datasval">At Start Designs, we also work on dedicated hiring. You can hire a designer/developer that matches your requirement to bring your project to life.</p>

                    </div>

                  </div>





                  <div class="mian_box">

                    <div class="ui_icon"><img src="images/timely-hire.png" alt=""></div>

                    <div class="ui_datas">

                      <p class="ui_datashead">Hourly Hiring</p>

                      <p class="ui_datasval">You can hire us on an hourly basis also. You only have to pay for the hours the designer/developer was working on your project. You can always monitor them while they are working on your project. </p>

                    </div>

                  </div>



              </div>

           </div>



            <div class="col-md-6">

            <div class="advantages-hiring-img">

              <img src="images/ui-ux-right.svg" class="floating">

            </div>

          </div>

        </div>



      </div>

    </section>



<!-- end-->





<!-- Recent work Ui -->

<section class="recentwork-section ui_recentwork">

  <div class="container">

    <div class="title">

      <h3>Some of our work that impacts clients' business</h3>

      <h2>UI/UX

        <a href="" class="typewrite" data-period="2000" data-type='[  "Recent Works" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row recentworkRow">

      <div class="col-md-3">

        <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/gl-ui-ux.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Goodman Lantern</h4>

                  <span class="sub-head">A London based company which provides content writing services.

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/itfc-ui-ux.png" class="responsive">

            <div class="recentworkContent">

                  <h4>ITFC</h4>

                  <span class="sub-head">A Canada based company which provides robust recruitment option for employers all across Canada.

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

       <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/ft2om-wordpress.png" class="responsive">

            <div class="recentworkContent">

                  <h4>FT2OM</h4>

                  <span class="sub-head">Complete website design for US based financial service business.                  

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/braneloshop-shopify.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Branelo Shop</h4>

                  <span class="sub-head">A France based multi-product e-commerce store design by our company.                  

                  </span>

            </div>

          </div>

        </a>

      </div>

    </div>

  </div>

</section>



<!-- Recent work Ui end-->



 

<!-- Expert review -->

  <section class="section-testimonials reveiw_slide ux_page">

      <div class="container">

        <div class="row">

          <div class="title">

            <h3>Testimony From Our Happy Clients</h3>

            <h2>What do client say about 

              <a href="" class="typewrite" data-period="2000" data-type='[  "UI/UX Expert" ]'> 

              </a>

            </h2>

          </div>

        </div>

       

        <div id="review-slider" class="owl-carousel">

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn18.png" alt="">

                  <div class="user-details-services">

                    <h4>Daniel P.</h4>

                    <p>Goodman Lantern</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "I would gladly pay for StartDesigns responsive website design and development service. The very best. It's incredible."

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn19.png" alt="">

                  <div class="user-details-services">

                    <h4>Amelia</h4>

                    <p>ITFC</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "I have used StartDesigns interactive design and development service a couple of times and I am very happy with the results each time."

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn21.png" alt="">

                  <div class="user-details-services">

                    <h4>Arthur</h4>

                    <p>Branelo Shop</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "Nice work on your StartDesigns desigining services. It's the perfect solution for our business."

                </p>

              </div>

            </div>

          </div>



        </div>        



      </div>

    </section>



<!-- Expert review end -->



<!-- FAQ Ui -->

<section class="webflowfeatures_services grey_faq">

  <div class="container">

    <div class="title">

      <h3>Got questions? We've got answers!</h3>

      <h2>FAQ's 

        <a href="" class="typewrite" data-period="2000" data-type='[  "Frequently Asked Questions" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row">

      <div class="col-md-8 col-md-offset-2 faq-main-parent">

          <button class="accordion-faq">How to hire UI/UX designers?</button>

          <div class="panel-faq">

            <p>To hire a UI/UX designer you only need to share details with us through the simple contact form on the website. You can submit the request after filling in basic information like Name, Mail, Subject, A brief description of your requirement, and contact no.</p>

          </div>



          <button class="accordion-faq">What is your UI/UX designer capable to do?</button>

          <div class="panel-faq">

            <p>We have skilled UI/UX designers with expertise to design the advanced:</p>

            <ul class="faq-navbar">

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> Web UI UX Design </li>

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> Dashboard Interface Design </li>

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> Custom Software Interface </li>

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> Game UI UX Design </li>

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> Mobile app UI and UX Design </li>

            </ul>

          </div>



          <button class="accordion-faq"> Can I hire a dedicated UI/UX designer on an hourly basis?</button>

          <div class="panel-faq">

            <p>Yes, we offer different hiring modules that allow you to choose on your terms and requirements.</p>

            <ul class="faq-navbar">

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> Fixed-Rate Hiring </li>

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> Dedicated Hiring </li>

              <li><i class="fa fa-check-circle" aria-hidden="true"></i> Hourly Hiring  </li>

            </ul>

          </div>



          <button class="accordion-faq">What are the different tools and technologies you are acquainted with?</button>

          <div class="panel-faq">

            <p>Our UI/UX designers are highly skilled to use tools such as Figma, Invision, Protopie, Sketch, Zeplin, Adobe XD, Framer, Sublime, Visual Studio, Slack, and Jira, etc.</p>

          </div>   



          <button class="accordion-faq">Why hire dedicated UI UX designers?</button>

          <div class="panel-faq">

            <p>Dedicated designers work more efficiently so that you get high-performance output. Other benefits are time-saving, cost-effectiveness, ease to handle, quicker process, flexibility, and emergency assistance.</p>

          </div>               

      </div>

    </div>

      



  </div>

</section>



<!-- Webflow FAQ Ui end-->



<!--#include file="footer.shtml"-->

    <a href="javascript:" id="return-to-top">

      <i class="fa fa-angle-double-up  " aria-hidden="true">

      </i>

    </a>



<?php include('footer.php'); ?>



<script type="text/javascript" src="js/jquery.js">

</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js">

</script>

<script src="js/jquery.countup.js">

</script>

<script>

$('.counter').countUp();

</script>

<!-- <script src="js/bootstrap.min.js">

</script> -->

<script src="js/script.js">

</script>

<script src="js/owl.carousel.min.js" defer>

</script>

<script src="js/jquery-1.11.1.min.js">

</script>

<script src="js/jquery.validate.min.js">

</script>

<script src="js/additional-methods.min.js">

</script>

<script src="js/slick.min.js" defer>

</script>



<script >

    $(document).ready(function(){

      $("#expertisecarousel").owlCarousel({

      autoplay: true,

      rewind: true, 

      margin: 20,  

      responsiveClass: true,

      autoHeight: true,

      autoplayTimeout: 7000,

      smartSpeed: 800,

      nav: false,

      responsive: {

        0: {

          items: 1

        },



        600: {

          items: 1

        },



        1024: {

          items: 1

        },



        1366: {

          items: 1

        }

      }

      });

    })

</script>

<!-- ---------testmony slider-------- -->

<script>

  $(document).ready(function(){

    console.log('abc')

    $('#review-slider').owlCarousel({

  loop: true,

  margin: 10,

  nav: false,  

  autoplay: true,

  autoplayHoverPause: true,

  responsive: {

    0: {

      items: 1

    },

    767: {

      items: 1

    },

    1000: {

      items: 1

    }

  }

})

  })

</script>





</body>

</html>

