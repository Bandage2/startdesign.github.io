<?php include('header.php'); ?>
<!--#include file="header.shtml"-->
          <div class="no-touch m-nav-menusocial">
            <div id="menusocial" class="menu--social1">
              <div class="toggle--social">
                <span class="soundspeaker-icon">
                </span>
              </div>
              <ul class="menu--sub">
                <li class="menu__item--facebook"> 
                  <a target="_blank" itemprop="samAs" class="menu-link sub-menu-link social_event_track_cls" data-title="Facebook" href="#">
                    <i>
                    </i>HB on Facebook
                  </a> 
                </li>
                <li class="menu__item--twitter"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Twitter" href="#">
                    <i>
                    </i> HB on Twitter 
                  </a> 
                </li>
                <li class="menu__item--linkdin"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="LinkedIn" href="#">
                    <i>
                    </i>HB on Linkedin
                  </a> 
                </li>
                <li class="menu__item--google-p"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Google Plus" href="#">
                    <i>
                    </i>HB on Google+
                  </a> 
                </li>
                <li class="menu__item--youtube"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="You Tube" href="#">
                    <i>
                    </i>HB on Youtube
                  </a> 
                </li>
                <li class="menu__item--blog"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Blog" href="#">
                    <i>
                    </i>HB on Blog
                  </a> 
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div id="top-container" style="display:none;">
          <div class="centerdiv">
            <div class="left"> 
              <a href="#" title=""> 
                <img src="images/logo.png" width="261" height="51" alt="" class="logo" /> 
              </a> 
            </div>
            <div class="right" style="width:72%;">
              <div class="r-clear menu-display">
                <div class="search-div">
                  <input type="search" placeholder="Search" name="" />
                </div>
                <span class="link-area">
                  <a target="_blank" title="" href="#">Blog
                  </a>
                  <a title="" href="#" target="_blank">Articles
                  </a>
                  <a title="" href="#">FAQ
                  </a>
                  <a title="" href="#">Careers
                  </a> 
                  <a title="Contact" href="#">Contact
                  </a> 
                  <a title="" href="#">Partnership
                  </a>
                </span> 
              </div>
              <div class="r-clear topmenu">
                <div class="mobile-tablet-menu">
                  <a href="#" class="mobile-menu-home-iclass" id="mobile-menu-home-icon">
                  </a>
                  <div class="mobile-menu-home-contner" id="mobile-menu-home">
                    <ul>
                      <li>
                        <a title="Company" href="#">Company
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Services
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Technology
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Products
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Client
                        </a>
                      </li>
                      <li>
                        <a title="Work" class="work-menu" href="#">Work
                        </a>
                      </li>
                      <li>
                        <a title="Inquiry" href="#" id="inquiry-pop-up" class="active">Get Quote</a>
                        <!--<a title="Inquiry" href="get-quote.html" id="inquiry-pop-up" class="active">Get Quote</a>-->
                      </li>
                    </ul>
                  </div>
                </div>
                <ul class="menu-t-menu-new">
                  <li>
                    <a title="startdesigns InfoTech" href="#">
                      <span class="home">
                      </span>
                    </a> 
                  </li>
                  <li>
                    <a title="Company" href="#">Company
                    </a> 
                  </li>
                  <li>
                    <a title="Services" href="#">Services
                    </a> 
                  </li>
                  <li>
                    <a title="Technology" href="#">Technology
                    </a> 
                  </li>
                  <li>
                    <a href="#">Products</a> 
                    <!--<a href="our-products.html">Products</a> -->
                  </li>
                  <li>
                    <a title="Work" href="#">Work
                    </a> 
                  </li>
                  <li>
                    <a title="Inquiry" href="#">Get Quote</a> 
                    <!--<a title="Inquiry" href="get-quote.html">Get Quote</a> -->
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
    <div class="" id="particles-js">
      <div class=" heading-particjs" >
        <div class="title">
          <h1 class="text-center">About 
            <a href="" class="typewrite" data-period="2000" data-type='[  "Us!" ]'>
            </a>
          </h1>
        </div>
      </div>
    </div>
    <!-- Banner top- contact end -->
    <section class="about-sd bg-gray-white">
      <div class="container">
        <div class="row">
          <div class="col-sm-6">
            <div class="about-tp-images">
              <img src="images/thumb-2.jpg" class="img-responsive img-width100">
              <div class="contant-onimages-about">
                <div class="col-md-6 col-sm-6">
                  <div class="project-client-section">
                    <h1 class="counter">
                      <b>500 
                      </b>
                    </h1>
                    <p>Projects Done
                    </p>
                  </div>
                </div>
                <div class="col-md-6 col-sm-6">
                  <div class="project-client-section">
                    <h1 class="counter">
                      <b>150
                      </b>
                    </h1>
                    <p>Happy Clients 
                    </p>
                  </div>
                </div>
                <div class="col-md-6 col-sm-6">
                  <div class="project-client-section">
                    <h1 class="counter">
                      <b>10000
                      </b>
                    </h1>
                    <p>Working Hours
                    </p>
                  </div>
                </div>
                <div class="col-md-6 col-sm-6">
                  <div class="project-client-section">
                    <h1 class="counter after-none">
                      <b>10
                      </b>
                    </h1>
                    <p> Awards
                    </p>
                  </div>
                </div>
              </div> 
            </div>
          </div>
          <div class="col-sm-6">
            <div class="wars-low aboutpage_contant">
              <h5 class="blog-sub-tp-heading">| About us |
              </h5>
              <h1 class="header Blog-heading-tp"> About  
                <span>Start Designs
                </span> 
              </h1>
              <p>  
                Start Designs is enterprise web & mobile app development company based out in India, provides Web Development services in France and USA with 4+ years and we have a skilled professional team with 290+ collective years of experience in web & mobile app  Solutions.  
                <br>
                We can convert your ideas into reality. We create cost-effective, award-winning solutions for our clients to grab digital space & create new business opportunities.
                <br>
                Just like every success story we started small and skilled. Gradually, Our hard work paid off and we have served over hundreds of satisfied customers.
                <br>
                We have also won several accolades over the years for our work. Each & every solution that we produced is worth multiple awards but the biggest award of them all is seeing our clients satisfied & successful.
                <br>
                <br>
                </p>
                  <p class="motto-txt">
                <span class="our-moto-txt">
                  <b>Our Motto
                  </b>
                  “ To provide superior products & service solutions, engaged employees,  disciplined work to create happy and successful clients ”.
                </span> 
               </p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="our-team-bgimg">
      <div class="container">
        <div class="row ">
          <div class="title">
            <h3>Our 
              <a href="" class="typewrite" data-period="2000" data-type='[  "Team" ]'> 
              </a>
            </h3>
            <span class="sub-head spc-bt-sub-head">Our team of tech evangelists & strong rationalist
            </span>
          </div>
        </div>

        

        <div class="row  section-sd-team sd-team-manage">
          <div class="our-team-post">
            <h3>Founder</h3>
          </div>
          <div class="col-md-3 col-sm-3"></div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team">
              <div class="pic">
                <img src="images/vijay-sir.jpg" alt="">
              </div>
              <h3 class="team-title"> Vijay soni
              </h3>
              <span class="post">co-founder
              </span>
              <!-- <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team">
              <div class="pic">
                <img src="images/our-team.jpeg" alt="">
              </div>
              <h3 class="team-title"> vipin agarwal
              </h3>
              <span class="post">co-founder
              </span>
             <!--  <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          <div class="col-md-3 col-sm-3"></div>
          <!-- <div class="col-md-3 col-sm-3">
            <div class="our-team">
              <div class="pic">
                <img src="images/user-img.png" alt="">
              </div>
              <h3 class="team-title"> Vijay soni
              </h3>
              <span class="post">co-founder
              </span>
              <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team spc-bt-0">
              <div class="pic">
                <img src="images/user-img.png" alt="">
              </div>
              <h3 class="team-title"> vipin agarwal
              </h3>
              <span class="post">co-founder
              </span>
              <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul>
            </div>
          </div> -->
        </div>

        <div class="row  section-sd-team sd-team-manage">
          <div class="our-team-post">
            <h3>management</h3>
          </div>
          <div class="col-md-3 col-sm-3"></div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team">
              <div class="pic">
                <img src="images/anju-sir.jpg" alt="">
              </div>
              <h3 class="team-title">Anuj
              </h3>
              <span class="post">Business Analyst
              </span>
              <!-- <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team">
              <div class="pic">
                <img src="images/user-img.png" alt="">
              </div>
              <h3 class="team-title"> Monu
              </h3>
              <span class="post">Human Resource
              </span>
             <!--  <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          <div class="col-md-3 col-sm-3"></div>
          <!-- <div class="col-md-3 col-sm-3">
            <div class="our-team">
              <div class="pic">
                <img src="images/user-img.png" alt="">
              </div>
              <h3 class="team-title"> Vijay soni
              </h3>
              <span class="post">co-founder
              </span>
              <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team spc-bt-0">
              <div class="pic">
                <img src="images/user-img.png" alt="">
              </div>
              <h3 class="team-title"> vipin agarwal
              </h3>
              <span class="post">co-founder
              </span>
              <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul>
            </div>
          </div> -->
        </div>

        

        <div class="row  section-sd-team">
            <div class="our-team-post">
              <h3>Backend Developers</h3>
            </div>
            <div class="col-md-3 col-sm-3">
              <div class="our-team">
                <div class="pic">
                  <img src="images/user-img.png" alt="">
                </div>
                <h3 class="team-title">Anil Sahu
                </h3>
                <span class="post">Lead Backend Developer 
                </span>
                <!-- <ul class="icon-team">
                  <li>
                    <a href="#" class="fa fa-facebook">
                    </a>
                  </li>
                  <li>
                    <a href="#" class="fa fa-skype">
                    </a>
                  </li>
                  <li>
                    <a href="#" class="fa fa-linkedin">
                    </a>
                  </li>
                </ul> -->
              </div>
            </div>
            <div class="col-md-3 col-sm-3">
              <div class="our-team">
                <div class="pic">
                  <img src="images/guarav-sir.jpg" alt="">
                </div>
                <h3 class="team-title">Gaurav Kumar
                </h3>
                <span class="post">Lead Backend Developer 
                </span>
                <!-- <ul class="icon-team">
                  <li>
                    <a href="#" class="fa fa-facebook">
                    </a>
                  </li>
                  <li>
                    <a href="#" class="fa fa-skype">
                    </a>
                  </li>
                  <li>
                    <a href="#" class="fa fa-linkedin">
                    </a>
                  </li>
                </ul> -->
              </div>
            </div>
            <div class="col-md-3 col-sm-3">
              <div class="our-team">
                <div class="pic">
                  <img src="images/ankit-sir.jpg" alt="">
                </div>
                <h3 class="team-title"> Ankit 
                </h3>
                <span class="post">Backend developer
                </span>
               <!--  <ul class="icon-team">
                  <li>
                    <a href="#" class="fa fa-facebook">
                    </a>
                  </li>
                  <li>
                    <a href="#" class="fa fa-skype">
                    </a>
                  </li>
                  <li>
                    <a href="#" class="fa fa-linkedin">
                    </a>
                  </li>
                </ul> -->
              </div>
            </div>
            
            <div class="col-md-3 col-sm-3">
              <div class="our-team">
                <div class="pic">
                  <img src="images/abhay-sir.jpg" alt="">
                </div>
                <h3 class="team-title"> Abhay
                </h3>
                <span class="post">Backend developer
                </span>
                <!-- <ul class="icon-team">
                  <li>
                    <a href="#" class="fa fa-facebook">
                    </a>
                  </li>
                  <li>
                    <a href="#" class="fa fa-skype">
                    </a>
                  </li>
                  <li>
                    <a href="#" class="fa fa-linkedin">
                    </a>
                  </li>
                </ul> -->
              </div>
            </div>
            
        </div>
        <div class="row sd-team-manage">  
          <div class="col-md-3 col-sm-3">
              <div class="our-team spc-bt-0">
                <div class="pic">
                  <img src="images/user-img.png" alt="">
                </div>
                <h3 class="team-title"> Vikas
                </h3>
                <span class="post">Backend developer
                </span>
                <!-- <ul class="icon-team">
                  <li>
                    <a href="#" class="fa fa-facebook">
                    </a>
                  </li>
                  <li>
                    <a href="#" class="fa fa-skype">
                    </a>
                  </li>
                  <li>
                    <a href="#" class="fa fa-linkedin">
                    </a>
                  </li>
                </ul> -->
              </div>
            </div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team spc-bt-0">
              <div class="pic">
                <img src="images/user-img.png" alt="">
              </div>
              <h3 class="team-title"> Rohit
              </h3>
              <span class="post">Backend developer
              </span>
              <!-- <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team spc-bt-0">
              <div class="pic">
                <img src="images/guarav-sir-2.jpg" alt="">
              </div>
              <h3 class="team-title"> Gaurav
              </h3>
              <span class="post">Backend developer
              </span>
              <!-- <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team">
              <div class="pic">
                <img src="images/mukesh-sir-img.jpg" alt="">
              </div>
              <h3 class="team-title">Mukesh
              </h3>
              <span class="post">Lead Backend Developer 
              </span>
              <!-- <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
        </div>

        <div class="row  section-sd-team">
          <div class="our-team-post">
            <h3>Mobile App</h3>
          </div>
          
          <div class="col-md-3 col-sm-3">
            <div class="our-team">
              <div class="pic">
                <img src="images/user-img.png" alt="">
              </div>
              <h3 class="team-title">Rinku
              </h3>
              <span class="post">Lead Mobile app Developer  
              </span>
              <!-- <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team">
              <div class="pic">
                <img src="images/abhishek-sir.jpg" alt="">
              </div>
              <h3 class="team-title"> Abhishek  
              </h3>
              <span class="post">IOS Developer
              </span>
             <!--  <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          
          <div class="col-md-3 col-sm-3">
            <div class="our-team">
              <div class="pic">
                <img src="images/user-img.png" alt="">
              </div>
              <h3 class="team-title"> Manish 
              </h3>
              <span class="post">IOS Developer
              </span>
              <!-- <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team spc-bt-0">
              <div class="pic">
                <img src="images/user-img.png" alt="">
              </div>
              <h3 class="team-title"> Deepak
              </h3>
              <span class="post">Android Developer
              </span>
              <!-- <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
        </div>
        <div class="row sd-team-manage">
          <div class="col-md-3 col-sm-3 d-none-col"></div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team spc-bt-0">
              <div class="pic">
                <img src="images/user-img.png" alt="">
              </div>
              <h3 class="team-title"> Mohit
              </h3>
              <span class="post">Android Developer
              </span>
              <!-- <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team spc-bt-0">
              <div class="pic">
                <img src="images/user-img.png" alt="">
              </div>
              <h3 class="team-title"> Gautam 
              </h3>
              <span class="post">Android Developer
              </span>
              <!-- <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          <div class="col-md-3 col-sm-3"></div>
        </div>

        <div class="row  section-sd-team sd-team-manage">
          <div class="our-team-post">
            <h3>Web and graphic</h3>
          </div>
          
          <div class="col-md-3 col-sm-3">
            <div class="our-team">
              <div class="pic">
                <img src="images/uttam.png" alt="">
              </div>
              <h3 class="team-title">Uttam 
              </h3>
              <span class="post">UI/UX Designer 
              </span>
              <!-- <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team">
              <div class="pic">
                <img src="images/gulshan-sir.jpg" alt="">
              </div>
              <h3 class="team-title"> Gulshan   
              </h3>
              <span class="post">Front End Designer
              </span>
             <!--  <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team spc-bt-0">
              <div class="pic">
                <img src="images/mahesh_photo.webp" alt="">
              </div>
              <h3 class="team-title"> Mahesh 
              </h3>
              <span class="post">Front End Designer
              </span>
              <!-- <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team">
              <div class="pic">
                <img src="images/shubhi_d.png" alt="">
              </div>
              <h3 class="team-title"> Shubhangi  
              </h3>
              <span class="post">Front End Designer
              </span>
              <!-- <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          
        </div>

        <div class="row  section-sd-team sd-team-manage">
          <div class="our-team-post">
            <h3>marketing</h3>
          </div>
          
          <div class="col-md-3 col-sm-3">
            <div class="our-team">
              <div class="pic">
                <img src="images/user-img.png" alt="">
              </div>
              <h3 class="team-title">Konika 
              </h3>
              <span class="post">Digital Marketing expert
              </span>
              <!-- <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team">
              <div class="pic">
                <img src="images/user-img.png" alt="">
              </div>
              <h3 class="team-title"> Nitin   
              </h3>
              <span class="post">Social media marketing 
              </span>
             <!--  <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          
          <div class="col-md-3 col-sm-3">
            <div class="our-team">
              <div class="pic">
                <img src="images/user-img.png" alt="">
              </div>
              <h3 class="team-title"> Monika  
              </h3>
              <span class="post">Content Writer
              </span>
              <!-- <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team spc-bt-0">
              <div class="pic">
                <img src="images/ashutosh-sir.jpg" alt="">
              </div>
              <h3 class="team-title"> Ashutosh 
              </h3>
              <span class="post">Digital Marketing
              </span>
              <!-- <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
        </div>
         <div class="row  section-sd-team sd-team-manage">
        <!--   <div class="our-team-post">
            <h3>marketing</h3>
          </div> -->
          
          <div class="col-md-3 col-sm-3">
            <div class="our-team">
              <div class="pic">
                <img src="images/user-img.png" alt="">
              </div>
              <h3 class="team-title">Hemant Sharma
              </h3>
              <span class="post">Digital Marketing expert
              </span>
              <!-- <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team">
             <!--  <div class="pic">
                <img src="images/user-img.png" alt="">
              </div>
              <h3 class="team-title"> Nitin   
              </h3>
              <span class="post">Social media marketing 
              </span> -->
             <!--  <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
          
          <div class="col-md-3 col-sm-3">
           <!--  <div class="our-team">
              <div class="pic">
                <img src="images/user-img.png" alt="">
              </div>
              <h3 class="team-title"> Monika  
              </h3>
              <span class="post">Content Writer
              </span> -->
              <!-- <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            <!-- </div> -->
          </div>
          <div class="col-md-3 col-sm-3">
            <div class="our-team spc-bt-0">
            <!--   <div class="pic">
                <img src="images/ashutosh-sir.jpg" alt="">
              </div>
              <h3 class="team-title"> Ashutosh 
              </h3>
              <span class="post">Digital Marketing
              </span>
              <ul class="icon-team">
                <li>
                  <a href="#" class="fa fa-facebook">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-skype">
                  </a>
                </li>
                <li>
                  <a href="#" class="fa fa-linkedin">
                  </a>
                </li>
              </ul> -->
            </div>
          </div>
        </div>



      </div>
    </section> 
    <!--  -->
    <section class="our-process pad-bt-60 bg-gray-white">
      <div class="container">
        <div class="title">
          <h1>Our 
            <a href="" class="typewrite" data-period="2000" data-type="[  &quot;Process&quot; ]">
              <span class="wrap">Process
              </span>
            </a>
          </h1>
          <span class="sub-head spc-bt-sub-head">A smooth sailing project experience
          </span>
        </div>
        <div class="process-slide-conainer">
          <div class="slide-inner">
            <div class="main-slide-show">
              <div>
                <div class="flex-row"> 
                  <div class="slide-imgs">
                    <img src="images/servicesimg/meeting.png" alt="">
                  </div>
                  <div class="process-slide-content">
                    <div class="slider-head">
                      <h4>metting &amp; research
                      </h4>
                    </div>
                    <div class="timeline-container">
                      <div class="timeline-inner orange-circle">
                        <div class="  time-row">
                          <div class="col-xs-6">
                            <div class="header-ttl sd wow slideInLeft">
                              Start Designs
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="header-ttl  clent wow slideInRight">
                              Client
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="circle-1 crcle">
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl f-right wow slideInLeft" data-wow-duration="1s">
                              <span >
                                Understand Requirement
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right wow slideInRight" data-wow-duration="1s">
                              <span>
                                Requirement Brief
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="circle-2 crcle">
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl f-right wow slideInLeft" data-wow-duration="1.8s">
                              <span  >
                                Research & Assessment
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right wow slideInRight" data-wow-duration="1s">
                              <span>
                                Assessment Feedback
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="circle-3 crcle">
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl f-right wow slideInLeft" data-wow-duration="2.5s">
                              <span >
                                Create Site Map
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right wow slideInRight" data-wow-duration="2.5s">
                              <span>
                                Site Map Review
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="circle-4 crcle">
                          </div>
                          <div class="col-xs-6 ">
                            <div class="time-ttl f-right wow slideInLeft" data-wow-duration="3s">
                              <span  >
                                Proposal
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right wow slideInRight" data-wow-duration="3s">
                              <span>
                                Approval
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                      </div>
                    </div>
                    <a onclick="document.getElementById('id01').style.display='block'" style="width:auto;" class="getqut">get a quote
                    </a>
                  </div>
                </div>
              </div>
              <!------>
              <div>
                <div class="flex-row"> 
                  <div class="slide-imgs">
                    <img src="banner-sd/img/mobile.png" alt="">
                  </div>
                  <div class="process-slide-content">
                    <div class="slider-head">
                      <h4>Design & Develop
                      </h4>
                    </div>
                    <div class="timeline-container">
                      <div class="timeline-inner orange-circle">
                        <div class="  time-row">
                          <div class="col-xs-6">
                            <div class="header-ttl sd">
                              Start Designs
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="header-ttl  clent">
                              Client
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="circle-1 crcle">
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl f-right">
                              <span>
                                List Required Content
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right">
                              <span>
                                Submission Content & Photos
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="circle-2 crcle">
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl f-right">
                              <span>
                                Homepage Design
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right">
                              <span>
                                Homepage Review and Feedback
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="circle-3 crcle">
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl f-right">
                              <span>
                                Inner Pages Design
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right">
                              <span>
                                Inner Pages Review and Feedback
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="no-lft-arrow crcle">
                          </div>
                          <div class="col-xs-6 ">
                            <div class="time-ttl f-right">
                              <span>
                                Frontend & Backend Coding
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right">
                              <span>
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="no-lft-arrow crcle">
                          </div>
                          <div class="col-xs-6 ">
                            <div class="time-ttl f-right">
                              <span>
                                Content Uploading
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right">
                              <span>
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                      </div>
                    </div>
                    <a onclick="document.getElementById('id01').style.display='block'" style="width:auto;" class="getqut">get a quote
                    </a>
                  </div>
                </div>
              </div>
              <div>
                <div class="flex-row"> 
                  <div class="slide-imgs">
                    <img src="banner-sd/img/testing.png" alt="">
                  </div>
                  <div class="process-slide-content">
                    <div class="slider-head">
                      <h4>QA Testing
                      </h4>
                    </div>
                    <div class="timeline-container">
                      <div class="timeline-inner orange-circle">
                        <div class="  time-row">
                          <div class="col-xs-6">
                            <div class="header-ttl sd">
                              Start Designs
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="header-ttl  clent">
                              Client
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="circle-1 crcle no-lft-arrow">
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl f-right">
                              <span>
                                Cross Browser & Device Testing
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right">
                              <span>
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="circle-2 crcle no-lft-arrow">
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl f-right">
                              <span>
                                Code Validation Testing
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right">
                              <span>
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="circle-3 crcle">
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl f-right">
                              <span>
                                Review & Testing
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right">
                              <span>
                                Review and Feedback
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="circle-4 crcle">
                          </div>
                          <div class="col-xs-6 ">
                            <div class="time-ttl f-right">
                              <span>
                                Refinement
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right">
                              <span>
                                Final Approval
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                      </div>
                    </div>
                    <a onclick="document.getElementById('id01').style.display='block'" style="width:auto;" class="getqut">get a quote
                    </a>
                  </div>
                </div>
              </div>
              <div>
                <div class="flex-row"> 
                  <div class="slide-imgs">
                    <img src="banner-sd/img/seo.png" alt="">
                  </div>
                  <div class="process-slide-content">
                    <div class="slider-head">
                      <h4> SEO Friendly Updates
                      </h4>
                    </div>
                    <div class="timeline-container">
                      <div class="timeline-inner orange-circle">
                        <div class="  time-row">
                          <div class="col-xs-6">
                            <div class="header-ttl sd">
                              Start Designs
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="header-ttl  clent">
                              Client
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="  crcle no-lft-arrow">
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl f-right">
                              <span>
                                Webpages Speed Optimizing
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right">
                              <span>
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="circle-2 crcle no-lft-arrow">
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl f-right">
                              <span>
                                Onpage SEO Optimization
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right">
                              <span>
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="circle-3 crcle no-lft-arrow">
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl f-right">
                              <span>
                                Generate Sitemap
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right">
                              <span>
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                      </div>
                    </div>
                    <a onclick="document.getElementById('id01').style.display='block'" style="width:auto;" class="getqut">get a quote
                    </a>
                  </div>
                </div>
              </div>
              <div>
                <div class="flex-row"> 
                  <div class="slide-imgs">
                    <img src="images/servicesimg/rocket.svg" alt="">
                  </div>
                  <div class="process-slide-content">
                    <div class="slider-head">
                      <h4>Launch
                      </h4>
                    </div>
                    <div class="timeline-container">
                      <div class="timeline-inner orange-circle">
                        <div class="  time-row">
                          <div class="col-xs-6">
                            <div class="header-ttl sd">
                              Start Designs
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="header-ttl  clent">
                              Client
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="circle-1 crcle no-lft-arrow">
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl f-right">
                              <span>
                                Upload on Server
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right">
                              <span>
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="circle-2 crcle no-lft-arrow">
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl f-right">
                              <span>
                                Testing on Live Environment
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right">
                              <span>
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                        <div class="  time-row">
                          <div class="circle-3 crcle no-lft-arrow">
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl f-right">
                              <span>
                                Backend Training
                              </span>
                            </div>
                          </div>
                          <div class="col-xs-6">
                            <div class="time-ttl text-right">
                              <span>
                              </span>
                            </div>
                          </div>
                          <div class="clearfix">
                          </div>
                        </div>
                      </div>
                    </div>
                    <a onclick="document.getElementById('id01').style.display='block'" style="width:auto;" class="getqut">get a quote
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>  
    </section> 
<?php include('footer.php'); ?>
