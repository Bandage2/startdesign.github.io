 <?php include('header.php'); ?>

<!--#include file="header.shtml"-->

          <div class="no-touch m-nav-menusocial">

            <div id="menusocial" class="menu--social1">

              <div class="toggle--social">

                <span class="soundspeaker-icon">

                </span>

              </div>

              <ul class="menu--sub">

                <li class="menu__item--facebook"> 

                  <a target="_blank" itemprop="samAs" class="menu-link sub-menu-link social_event_track_cls" data-title="Facebook" href="#">

                    <i>

                    </i>HB on Facebook

                  </a> 

                </li>

                <li class="menu__item--twitter"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Twitter" href="#">

                    <i>

                    </i> HB on Twitter 

                  </a> 

                </li>

                <li class="menu__item--linkdin"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="LinkedIn" href="#">

                    <i>

                    </i>HB on Linkedin

                  </a> 

                </li>

                <li class="menu__item--google-p"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Google Plus" href="#">

                    <i>

                    </i>HB on Google+

                  </a> 

                </li>

                <li class="menu__item--youtube"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="You Tube" href="#">

                    <i>

                    </i>HB on Youtube

                  </a> 

                </li>

                <li class="menu__item--blog"> 

                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Blog" href="#">

                    <i>

                    </i>HB on Blog

                  </a> 

                </li>

              </ul>

            </div>

          </div>

        </div>

        <div id="top-container" style="display:none;">

          <div class="centerdiv">

            <div class="left"> 

              <a href="#" title=""> 

                <img src="images/logo.png" width="261" height="51" alt="" class="logo" /> 

              </a> 

            </div>

            <div class="right" style="width:72%;">

              <div class="r-clear menu-display">

                <div class="search-div">

                  <input type="search" placeholder="Search" name="" />

                </div>

                <span class="link-area">

                  <a target="_blank" title="" href="#">Blog

                  </a>

                  <a title="" href="#" target="_blank">Articles

                  </a>

                  <a title="" href="#">FAQ

                  </a>

                  <a title="" href="#">Careers

                  </a> 

                  <a title="Contact" href="#">Contact

                  </a> 

                  <a title="" href="#">Partnership

                  </a>

                </span> 

              </div>

              <div class="r-clear topmenu">

                <div class="mobile-tablet-menu">

                  <a href="#" class="mobile-menu-home-iclass" id="mobile-menu-home-icon">

                  </a>

                  <div class="mobile-menu-home-contner" id="mobile-menu-home">

                    <ul>

                      <li>

                        <a title="Company" href="#">Company

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Services

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Technology

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Products

                        </a>

                      </li>

                      <li>

                        <a title="" href="#">Client

                        </a>

                      </li>

                      <li>

                        <a title="Work" class="work-menu" href="#">Work

                        </a>

                      </li>

                      <li>

                        <a title="Inquiry" href="#" id="inquiry-pop-up" class="active">Get Quote

                        </a>

                      </li>

                    </ul>

                  </div>

                </div>

                <ul class="menu-t-menu-new">

                  <li>

                    <a title="startdesigns InfoTech" href="#">

                      <span class="home">

                      </span>

                    </a> 

                  </li>

                  <li>

                    <a title="Company" href="#">Company

                    </a> 

                  </li>

                  <li>

                    <a title="Services" href="#">Services

                    </a> 

                  </li>

                  <li>

                    <a title="Technology" href="#">Technology

                    </a> 

                  </li>

                  <li>

                    <a href="#">Products

                    </a> 

                  </li>

                  <li>

                    <a title="Work" href="#">Work

                    </a> 

                  </li>

                  <li>

                    <a title="Inquiry" href="#">Get Quote

                    </a> 

                  </li>

                </ul>

              </div>

            </div>

          </div>

        </div>

      </div>

    </header>

    

    <!-- Banner top- contact end -->

    

    <section class="service-topbanner paypalbgcolor">

      <div class="container">

          <div class="row service-flex">

              <div class="col-md-6">

                <!-- --------language toogle----- -->

                <!-- <div class="language-chnge">      

                  <div class="container lang-fr">

                    <p>Switch language</p>

                    <div class="lang-boxs">

                      <a href="#" class="enn lang-select">En</a>

                      <a href="#" class="frr">Fr</a>                    

                    </div>

                  </div>                   

                </div> -->

                <!-- --------language toogle ends----- -->

                <div class="mainservicetopbanner">

                  <h3>PayPal Payment Gateway Integration Solution</h3>

                  <h1>PayPal Integration Solutions</h1>

                  <p>We provide advanced PayPal integration solutions for all e-commerce platforms or CMSs and customize e-commerce websites. PayPal is the world's most trusted and preferred payment gateway. PayPal has 360+ million active users, 200+ markets worldwide with 100+ currencies options. We have expertise in the integration of PayPal with e-commerce platforms such as Shopify, Webflow, Magento, Drupal, WooCommerce, etc.</p>

                  <div class="dflex">

                    <a href="#foooter_form" class="btn btn-contactsupport">Contact Support →</a>

                    <a href="#" class="btn btn-startproject" id="projectmodel" data-toggle="modal" data-target="#startproject">Start a Project →</a>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <div class="paypal-bg-topimage">

                  <img src="images/paypal_banner.png">

                </div>

              </div>

          </div>

      </div>

    </section>





    <!-- Integration of PayPal payment  -->

    <section class="alma_Integration_services paypal_page">

      <div class="container">



         <div class="title">

             <!--  <h3>Alma module installation and custom integration</h3> -->

              <h2>Our PayPal Integration

                <a href="" class="typewrite" data-period="2000" data-type='[  "Solutions" ]'> </a>

              </h2>

            </div>



            <div class="row integrationRow1">

               <div class="col-md-6">

                  <div class="Integration_features_new newDml">

                    <div class="headerpanel-Integration">

                      <div class="service_icon"><img src="images/refund.png"></div>

                      <h3>PayPal Integration Development</h3>

                    </div>

                    <div class="Integration_contant_new">

                      <p>We offer PayPal API integration solutions with different payment methods like Express checkout, Adaptive payments, Recurring payments, and Direct payment. Custom development of REST APIs to test working and functionalities.</p>

                    </div>

                  </div>

               </div>

               <div class="col-md-6">

                <div class="Integration_features_new newDml">

                    <div class="headerpanel-Integration">

                      <div class="service_icon"><img src="images/payment-proces.png"></div>

                      <h3>PayPal Payment Processing Solutions</h3>

                    </div>

                    <div class="Integration_contant_new">

                      <p>We provide custom payment processing solutions that allow your customers to pay from bank accounts, cards, and PayPal wallets. We develop modules for different methods like Express checkout, Adaptive payments, etc.</p>

                    </div>

                  </div>

               </div>

            </div>



            <div class="row integrationRow2">

               <div class="col-md-6">

                  <div class="Integration_features_new newDml">

                    <div class="headerpanel-Integration">

                      <div class="service_icon"><img src="images/ecommm.png"></div>

                      <h3>PayPal eCommerce Integration Solutions</h3>

                    </div>

                    <div class="Integration_contant_new">

                      <p>Our developers have hands-on experience integrating PayPal to various e-commerce platforms such as Shopify, Magento, Drupal, WooCommerce, Salesforce commerce cloud, etc. We have integrated  REST APIs based on JSON and OAuth to over 100+ stores.</p>

                    </div>

                  </div>

               </div>

               <div class="col-md-6">

                <div class="Integration_features_new newDml">

                    <div class="headerpanel-Integration">

                      <div class="service_icon"><img src="images/mobile-app.png"></div>

                      <h3>PayPal Mobile Application Integration</h3>

                    </div>

                    <div class="Integration_contant_new">

                      <p>Our developers have experience in integrating PayPal on Android and iOS applications. We set up PayPal using Android SDK and iOS SDK with zero hassle. So, you can create invoices, receipts and capture customer signatures.</p>

                    </div>

                  </div>

               </div>

            </div>



      </div>

    </section>

    <!-- Integration of PayPal payment end -->





    <!-- Benefit start -->

     <section class="service-awardwinning bg-gray-white paypal_page">

      <div class="container">

        <div class="title">

          <!-- <h5>Some of our work that impacts clients' business</h5> -->

          <h2>Benefits of PayPal Payment 

            <a href="" class="typewrite" data-period="2000" data-type='[  "Gateway Integration" ]'> 

            </a>

          </h2>

        </div>

          <div class="row service-flex">            

              <div class="col-md-6">

                <div class="mainservicetopbanner features-title">                  

                  <h2>Increase sales and process much <span class="sd-web-pink">faster with PayPal</span></h2>

                  <p class="para1">PayPal increases sales by enhancing the conversion rate of your eCommerce store. PayPal has captured 200+ markets globally and allows transactions in 100+ currencies. So, when you choose PayPal, it gives confidence to your buyer, enhances brand value, and makes the process much faster than other payment gateways.                  

                  </p>

                  <div class="advantages-hiring-list">

                <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                     Increase sales

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                    Faster process

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                    100+ currencies

                  </div>

                </div>                            

                  </div>                  

                </div>

              </div>



               <div class="col-md-6">

                <div class="almaleftimages">

                  <img src="images/paypal_img1.png" class="responsive floating">

                </div>

              </div>              

          </div>



          <div class="row service-flex flex2">      

           <div class="col-md-6">

                <div class="almaleftimages">

                  <img src="images/pay-gatewaay.png" class="responsive floating">

                </div>

              </div> 



              <div class="col-md-6">

                <div class="mainservicetopbanner features-title">                  

                  <h2>Spend safely with<span class="sd-web-pink"> PayPal Credits </span></h2>

                  <p class="para1">PayPal credits is an open-end credit card that allows buyers to buy now, pay overtime option. PayPal Credit is available everywhere PayPal is accepted and has no annual fees. This feature gives buyers the freedom to buy things or services even if they are not within the budget. Hence, buyers purchase more simultaneously and the sellers get more sales.                  

                  </p>

                  <div class="advantages-hiring-list">

                <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                     No annual fees

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                    Open-end credit card

                  </div>

                </div>

                 <div>

                   <div class="advantage-icon">

                    <i class="fa fa-check" aria-hidden="true"></i>

                  </div>

                  <div class="advantage-text">

                    Buy now, pay over time

                  </div>

                </div>                            

                  </div>                  

                </div>

              </div>                           

          </div>

      </div>

    </section>

    <!-- Benefit end -->





    

<!-- Features of payment  -->

<section class="payementfeatures_services paypal_page">

  <div class="container">

            <div class="title">          

          <h2>Why opt for

            <a href="" class="typewrite" data-period="2000" data-type='[  "PayPal  Payment Gateway" ]'> 

            </a>

          </h2>

        </div>

       

        <div class="row dflex-features">            

          <div class="col-md-6">

            <div class="mainservicetopbanner features-title">

                  <!-- <h3>Why should you choose the Mangopay payment gateway solution? It's bundled with advanced features </h3> -->

                  <!-- <h2>Mangopay <span class="sd-web-pink">Features</span></h2> -->

                  <ul class="features-lisiting-payment">

                    <li>

                      <div class="features-of-payments">

                        <span class="feat-icon"><img src="images/secure-payment (2).png"></span>

                        <div class="contant-features">

                          <h3>Fast and Secure Payment</h3>

                          <div class="tool_tip">

                          <p class="toop_tip_hide">PayPal makes the transaction fast and protects both shoppers and buyers.</p>

                          <!-- <div class="tooltip_feature">

                            It supports hundreds of payment methods. So you can choose which suits your business and what your customers like. No matter whether your business is international or local Mangopay API supports several local and international payment methods.

                            It supports one-click payments, card preauthorizations, refunds, 3DS, and recurring transactions.

                          </div> -->

                          </div>

                          

                        </div>

                      </div>

                    </li>

                    <li>

                      <div class="features-of-payments">

                        <span class="feat-icon"><img src="images/save-time.png"></span>

                        <div class="contant-features">

                          <h3>Best Payment Gateway Worldwide</h3>

                           <div class="tool_tip">

                              <p class="toop_tip_hide">Most trusted payment gateway with 360 million active users worldwide.</p>

                          <!-- <div class="tooltip_feature">

                            You can create unlimited e-wallets for users for endless escrowing time and attach them with French or Luxembourg IBANs. These extensive features of Mangopay give additional security and speed up the payment process between french users and companies.

                          Escrow any amount on e-wallets, transfer funds free, pay through IBAN into an e-wallet, and simplified recurring methods.

                          </div> -->

                           </div>

                         

                        </div>

                      </div>

                    </li>

                    <li>

                      <div class="features-of-payments">

                        <span class="feat-icon"><img src="images/smartphone (1).png"></span>

                        <div class="contant-features">

                          <h3>Support 100+ Currencies</h3>

                           <div class="tool_tip">

                             <p class="toop_tip_hide">PayPal allows transactions in 100+ currencies. Attract more local buyers.</p>

                          <!-- <div class="tooltip_feature">

                            Mangopay automates the user identity verification process as per European anti-money laundering regulations. It sends the necessary information through API that prevents money laundering, fraudulent behavior, and transparent process.

                            Mangopay just simplified the KYC process for your customers. It offers one-time document verification for unlimited transactions and speeds the process.

                          </div> -->

                           </div>                           

                          

                        </div>

                      </div>

                    </li>

                    <li>

                      <div class="features-of-payments">

                        <span class="feat-icon"><img src="images/online-shopping.png"></span>

                        <div class="contant-features">

                          <h3>Advanced Data Protection</h3>

                           <div class="tool_tip">

                             <p class="toop_tip_hide">Every transactional and financial detail is kept secure and protected. Never shared.</p>                          

                           </div>                          

                        </div>

                      </div>

                    </li>

                    <li>

                      <div class="features-of-payments">

                        <span class="feat-icon"><img src="images/bill (1).png"></span>

                        <div class="contant-features">

                          <h3>24/7 Monitoring</h3>

                          <div class="tool_tip">

                            <p class="toop_tip_hide">PayPal monitors all transactions 24/7 that protect buyers from fraud and fishing.</p>                           

                          </div>                                  

                        </div>

                      </div>

                    </li>

                  </ul>

                </div>

          </div>



          <div class="col-md-6">

              <div class="image-widthmanage">

                <img src="images/paypage.png" class="responsive floating">

              </div>

          </div> 

    </div>

      </div>

    </section>

<!-- Features of payment end -->



<!-- Solutions Section -->

<section class="soluction-section service-include bg-gray-white paypal_page">

  <div class="container">

    <div class="title">

          <!-- <h3>Hire Alma integration service to increase sales today</h3> -->

          <h2>Why Buyers Love Websites

            <a href="" class="typewrite" data-period="2000" data-type='[  "Offer PayPal" ]'> </a>

          </h2>

        </div>

   



        <div class="row">

      <div class="col-md-8 col-md-offset-2">

          <ul class="timeline">

            <li>

              <span>1</span>

              <h4>Get refunded on return shipping</h4>

              <p>PayPal offers a refund on the return shipping. So, buyers can leverage the benefit of refund on return policy from e-commerce websites that use PayPal. This feature gives buyers more freedom to purchase.</p>

            </li>

            <li>

              <span>2</span>

              <h4>Pay with the preferred card</h4>

             <p>PayPal accepts payments from most banks. So, buyers can pay through preferred credit or debit cards. Websites or e-commerce stores integrated with PayPal support a more buyer base to make a hassle-free experience.</p>

            </li>

            <li>

              <span>3</span>

              <h4>Offer reward points</h4>

             <p>PayPal offers rewards, coupons, and benefit points to buyers when they purchase through PayPal. Buyers from any country or elsewhere in the world love to buy things or services where they get discounts.</p>

            </li>

            

          </ul>

      </div>

    </div>



  </div>

</section>

<!-- Solutions Section End -->



 <!-- Platforms  -->

<section class="Platforms_section almma">

  <div class="container">

    <div class="title">

      <h2>Available 

        <a href="" class="typewrite" data-period="2000" data-type='[  "Platforms" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row ">

      <div class="col-md-12">

          <ul class="logo-platform-listing">

            <li><div class="logo-platforms"><img src="images/platform-Magento.png"></div></li>

            <li><div class="logo-platforms"><img src="images/platform-PrestaShop_Logo.png"></div></li>

            <li><div class="logo-platforms"><img src="images/platform-Shopify-Logo1.png"></div></li>

            <li><div class="logo-platforms"><img src="images/platform-wizishoplogo.png"></div></li>

            <li><div class="logo-platforms"><img src="images/platform-woocommerce.png"></div></li>

          </ul>

      </div>

     

    </div>

  </div>

</section>

<!-- Platforms end-->

  

<!-- Recent work Ui -->

<section class="recentwork-section wp-recent bg-gray-white">

  <div class="container">

    <div class="title">

      <h5>Pour a brew and peruse our goods</h5>

      <h2>Paypal Integration

        <a href="" class="typewrite" data-period="2000" data-type='[  "Recent Works" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row recentworkRow">

      <div class="col-md-3 col-sm-6">

        <a href="#" class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/vkng-shopify.png" class="responsive">

            <div class="recentworkContent">

                  <h4>VKNG Jewelry</h4>

                  <span class="sub-head">France based jewelry store Shopify website design and development.                  

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

        <a href="#" class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/sistersrepublic-shopify.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Sisters Republic</h4>

                  <span class="sub-head">France based women's lingerie brand fully functional Shopify store setup.                  

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

       <a href="#" class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/ft2om-wordpress.png" class="responsive">

            <div class="recentworkContent">

                  <h4>FT2OM</h4>

                  <span class="sub-head">Complete website design for US based financial service business.

                  </span>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3 col-sm-6">

        <a href="#" class="recentworkBox">

          <div class="recentworkImg">

            <img src="images/braneloshop-shopify.png" class="responsive">

            <div class="recentworkContent">

                  <h4>Branelo Shop</h4>

                  <span class="sub-head">France based multi-product e-commerce Shopify store design and development.                  

                  </span>

            </div>

          </div>

        </a>

      </div>

    </div>

  </div>

</section>



<!-- Recent work Ui end-->



<!-- Expert review -->

  <section class="section-testimonials reveiw_slide bg-white">

      <div class="container">

        <div class="row">

          <div class="title">

            <h3>Testimony from our happy clients</h3>

            <h2>What do client say about 

              <a href="" class="typewrite" data-period="2000" data-type='[  "WordPress Expert" ]'> 

              </a>

            </h2>

          </div>

        </div>

       

        <div id="review-slider" class="owl-carousel">

                    <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn12.png" alt="">

                  <div class="user-details-services">

                    <h4>Britani I</h4>

                    <p>Loewenhof Immobilien</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "StartDesigns is worth much more than I paid. Not able to tell you how happy I am with WordPress design and development services by StartDesigns."

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn14.png" alt="">

                  <div class="user-details-services">

                    <h4>Cloris G</h4>

                    <p>All Campus Security</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "I was amazed at the quality of WordPress website design. Definitely worth the investment. We were treated like royalty."

                </p>

              </div>

            </div>

          </div>

          <div class="testimonial">

                <div class="row dflex services-client-main">

              <div class="col-md-6"> 

                <div class="services-userimages">

                  <img src="images/personnn16.png" alt="">

                  <div class="user-details-services">

                    <h4>Brewster H.</h4>

                    <p>FT2OM</p>

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <p class="description">

                  "StartDesigns has completely surpassed our expectations. I couldn't have asked for more than this. I have gotten at least 50 times the value from StartDesigns. The WordPress solution by StartDesigns is worth much more than I paid."

                </p>

              </div>

            </div>

          </div>



        </div>        



      </div>

    </section>

<!-- Expert review end -->



<!-- FAQ Ui -->

<section class="webflowfeatures_services presta_faq">

  <div class="container">

    <div class="title">

      <h3>Got questions? We've got answers!</h3>

      <h2>FAQ's 

        <a href="" class="typewrite" data-period="2000" data-type='[  "Frequently Asked Questions" ]'> 

        </a>

      </h2>

    </div>

    

    <div class="row">

      <div class="col-md-8 col-md-offset-2 faq-main-parent">

          <button class="accordion-faq">What types of payment does PayPal offer?</button>

          <div class="panel-faq">

            <p>PayPal commonly offers four payment types: Sell products, Sell subscription, User-defined amounts, and collect donations. These payment types are available in PayPal.</p>

          </div>



          <button class="accordion-faq">Is PayPal available in my country?</button>

          <div class="panel-faq">

            <p>PayPal is available in 200+ countries/regions to date and supports 25+ currencies. PayPal is available worldwide you can check here that your country is on the list.</p>

          </div>



          <button class="accordion-faq">Does PayPal accept credit/debit card payments?</button>

          <div class="panel-faq">

            <p>Yes, PayPal accepts credit/debit payments. You can enable this payment option through the PayPal account setting.</p>            

          </div>

      </div>

    </div>

      



  </div>

</section>

<!-- FAQ Ui end-->





<!--#include file="footer.shtml"-->

    <a href="javascript:" id="return-to-top">

      <i class="fa fa-angle-double-up  " aria-hidden="true">

      </i>

    </a>

<?php include('footer.php'); ?>

<script type="text/javascript" src="js/jquery.js">

</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js">

</script>

<script src="js/jquery.countup.js">

</script>

<script>

$('.counter').countUp();

</script>

<!-- <script src="js/bootstrap.min.js">

</script> -->

<script src="js/owl.carousel.min.js" defer>

</script>

<script src="js/script.js">

</script>

<script src="js/jquery-1.11.1.min.js">

</script>

<script src="js/jquery.validate.min.js">

</script>

<script src="js/additional-methods.min.js">

</script>

<script src="js/slick.min.js" defer>

</script>







<!-- -testimony silder- -->

<script>

  $(document).ready(function(){

    $('#review-slider').owlCarousel({

  loop: true,

  margin: 10,

  nav: false,  

  autoplay: true,

  autoplayHoverPause: true,

  responsive: {

    0: {

      items: 1

    },

    767: {

      items: 1

    },

    1000: {

      items: 1

    }

  }

})

  })

</script>

</body>

</html>

