<?php include('header.php'); ?>
<!--#include file="header.shtml"-->
          <div class="no-touch m-nav-menusocial">
            <div id="menusocial" class="menu--social1">
              <div class="toggle--social">
                <span class="soundspeaker-icon">
                </span>
              </div>
              <ul class="menu--sub">
                <li class="menu__item--facebook"> 
                  <a target="_blank" itemprop="samAs" class="menu-link sub-menu-link social_event_track_cls" data-title="Facebook" href="#">
                    <i>
                    </i>HB on Facebook
                  </a> 
                </li>
                <li class="menu__item--twitter"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Twitter" href="#">
                    <i>
                    </i> HB on Twitter 
                  </a> 
                </li>
                <li class="menu__item--linkdin"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="LinkedIn" href="#">
                    <i>
                    </i>HB on Linkedin
                  </a> 
                </li>
                <li class="menu__item--google-p"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Google Plus" href="#">
                    <i>
                    </i>HB on Google+
                  </a> 
                </li>
                <li class="menu__item--youtube"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="You Tube" href="#">
                    <i>
                    </i>HB on Youtube
                  </a> 
                </li>
                <li class="menu__item--blog"> 
                  <a target="_blank" itemprop="samAs"  class="menu-link sub-menu-link social_event_track_cls" data-title="Blog" href="#">
                    <i>
                    </i>HB on Blog
                  </a> 
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div id="top-container" style="display:none;">
          <div class="centerdiv">
            <div class="left"> 
              <a href="#" title=""> 
                <img src="images/logo.png" width="261" height="51" alt="" class="logo" /> 
              </a> 
            </div>
            <div class="right" style="width:72%;">
              <div class="r-clear menu-display">
                <div class="search-div">
                  <input type="search" placeholder="Search" name="" />
                </div>
                <span class="link-area">
                  <a target="_blank" title="" href="#">Blog
                  </a>
                  <a title="" href="#" target="_blank">Articles
                  </a>
                  <a title="" href="#">FAQ
                  </a>
                  <a title="" href="#">Careers
                  </a> 
                  <a title="Contact" href="#">Contact
                  </a> 
                  <a title="" href="#">Partnership
                  </a>
                </span> 
              </div>
              <div class="r-clear topmenu">
                <div class="mobile-tablet-menu">
                  <a href="#" class="mobile-menu-home-iclass" id="mobile-menu-home-icon">
                  </a>
                  <div class="mobile-menu-home-contner" id="mobile-menu-home">
                    <ul>
                      <li>
                        <a title="Company" href="#">Company
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Services
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Technology
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Products
                        </a>
                      </li>
                      <li>
                        <a title="" href="#">Client
                        </a>
                      </li>
                      <li>
                        <a title="Work" class="work-menu" href="#">Work
                        </a>
                      </li>
                      <li>
                        <a title="Inquiry" href="#" id="inquiry-pop-up" class="active">Get Quote
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
                <ul class="menu-t-menu-new">
                  <li>
                    <a title="startdesigns InfoTech" href="#">
                      <span class="home">
                      </span>
                    </a> 
                  </li>
                  <li>
                    <a title="Company" href="#">Company
                    </a> 
                  </li>
                  <li>
                    <a title="Services" href="#">Services
                    </a> 
                  </li>
                  <li>
                    <a title="Technology" href="#">Technology
                    </a> 
                  </li>
                  <li>
                    <a href="#">Products
                    </a> 
                  </li>
                  <li>
                    <a title="Work" href="#">Work
                    </a> 
                  </li>
                  <li>
                    <a title="Inquiry" href="#">Get Quote
                    </a> 
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
    <!-- Banner top- contact end -->
    <div class="" id="particles-js" style="margin-bottom: 0;">
      <div class=" heading-particjs" >
        <div class="title">
          <h1 class="text-center">Our   
            <a href="" class="typewrite" data-period="2000" data-type='[  "Portfolio" ]'>
            </a>
          </h1>
        </div>
      </div>
    </div>
    <section class="gallery">
      <div>
        <!-- Nav tabs -->
        <ul class="nav nav-tabs material-ui" role="tablist" id="myTabs">
          <li role="presentation" class="active">
            <a href="#tab1" aria-controls="tab1" role="tab" data-toggle="tab" class=" ">all
            </a>
          </li>
          <li role="presentation" class="">
            <a href="#tab2" aria-controls="tab2" role="tab" data-toggle="tab" class=" ">web / app
            </a>
          </li>
          <li role="presentation">
            <a href="#tab3" aria-controls="tab3" role="tab" data-toggle="tab">  Branding
            </a>
          </li>
          <li role="presentation">
            <a href="#tab4" aria-controls="tab4" role="tab" data-toggle="tab">E-commerce
            </a>
          </li>
          <!--  <li role="presentation"><a href="#tab5" aria-controls="tab5" role="tab" data-toggle="tab">E-commerce</a></li> -->
        </ul>
        <div class="tab-content">
          <div role="tabpanel" class="tab-pane fade in active" id="tab1">
            <div class="tab-content--inner">
              <div class="row no-gutters">
                <div class="col-md-3 col-sm-6 spc-bt-15-md">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal">
                          <img src="images/portfolio/tab-autopart.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Auto Counsel Market
                            </h5>
                            <p>Web and App Development
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/auto_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>  
                  </div>
                </div>
                <div class="col-md-3 col-sm-6 spc-bt-15-md">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal2"> 
                          <img src="images/portfolio/tab-signerpay.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Signerpay
                            </h5>
                            <p>UI \ UX Design
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/signerpay_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal3"> 
                          <img src="images/portfolio/tab-ecomm.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Ecommerce Invest 
                            </h5>
                            <p>Wordpress
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/ecomm_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6 spc-bt-15-sm">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal4">
                          <img src="images/portfolio/tab-book.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Book Serve
                            </h5>
                            <p>Graphic, Ilustrator, App Design
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/book_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>    
                  </div>
                </div>
                <div class="col-md-3 col-sm-6">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal5"> 
                          <img src="images/portfolio/tab-bach.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Bach Fitness
                            </h5>
                            <p>UI \ UX Design
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal5" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/bach_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal6"> 
                          <img src="images/portfolio/tab-yuvika.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Yuvika Fashion
                            </h5>
                            <p>App, Graphic, Illustrator
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal6" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/yuvika_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <!-- all proj row -->
              <div class="row no-gutters all-proj-row-2">
                <div class="col-md-3 col-sm-6 spc-bt-15-md">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal01">
                          <img src="images/portfolio/tab-studio.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>
                              studio thrive
                            </h5>
                            <p>Graphic, Branding, Logo
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal01" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/studio_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>  
                  </div>
                </div>
                <div class="col-md-3 col-sm-6 spc-bt-15-md">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal6"> 
                          <img src="images/portfolio/tab-yuvika.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Yuvika Fashion
                            </h5>
                            <p>App, Graphic, Illustrator
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal02" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/yuvika_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal03"> 
                          <img src="images/portfolio/tab-ecomm.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Ecommerce Invest 
                            </h5>
                            <p>Wordpress
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal03" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/ecomm_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6 spc-bt-15-sm">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal04">
                          <img src="images/portfolio/tab-msgtutor.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Message Tutor
                            </h5>
                            <p>Web / App, UI \ UX Design
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal04" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/msgtutor_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>    
                  </div>
                </div>
                <div class="col-md-3 col-sm-6">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal05"> 
                          <img src="images/portfolio/tab-martial.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Martial Craft
                            </h5>
                            <p>Graphic, Branding
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal05" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/martial_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal06"> 
                          <img src="images/portfolio/tab-huge.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Huge Logo Design
                            </h5>
                            <p>UI \ UX Design, Graphic, Branding
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal06" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/huge_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <!-- last row -->
              <div class="row no-gutters all-proj-row-3">
                <div class="col-md-3 col-sm-6 spc-bt-15-md">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal07">
                          <img src="images/portfolio/tab-ecoapp.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Ecommerce App
                            </h5>
                            <p>Shopify, Ux Design
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal07" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/ecoapp_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>  
                  </div>
                </div>
                <div class="col-md-3 col-sm-6 spc-bt-15-md">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal08"> 
                          <img src="images/portfolio/tab-com.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Computer Store
                            </h5>
                            <p>Ecommerce, Shopify, Web Design
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal08" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/com_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal09"> 
                          <img src="images/portfolio/tab-yuvika.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Yuvika Fashion
                            </h5>
                            <p>App, Graphic, Illustrator
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal09" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/yuvika_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6 spc-bt-15-sm">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal010">
                          <img src="images/portfolio/tab-alan.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Alan group
                            </h5>
                            <p>Wordpress, UI Design
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal010" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/alangroup_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>    
                  </div>
                </div>
                <div class="col-md-3 col-sm-6 ">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal011"> 
                          <img src="images/portfolio/tab-dog.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Doggear
                            </h5>
                            <p>Wordpress, UI Design
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal011" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/dog_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal012"> 
                          <img src="images/portfolio/tab-ecomm.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Ecommerce Invest 
                            </h5>
                            <p>Wordpress
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal012" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/ecomm_full.png" class="img-responsive"> 
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div role="tabpanel" class="tab-pane fade " id="tab2">
            <div class="tab-content--inner">
              <div class="row no-gutters">
                <div class="col-md-3 col-sm-6 spc-bt-15-md">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal7">
                          <img src="images/portfolio/tab-msgtutor.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Message Tutor
                            </h5>
                            <p>Web / App, UI \ UX Design
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal7" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/msgtutor_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>  
                  </div>
                </div>
                <div class="col-md-3 col-sm-6 spc-bt-15-md">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal8"> 
                          <img src="images/portfolio/tab-bach.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Bach Fitness
                            </h5>
                            <p>UI \ UX Design, Web Designs
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal8" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/bach_full.png" class="img-responsive"> 
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal9"> 
                          <img src="images/portfolio/tab-ecomm.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Ecommerce Invest 
                            </h5>
                            <p>Wordpress
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal9" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/ecomm_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6 spc-bt-15-sm">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal10">
                          <img src="images/portfolio/tab-autopart.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Auto Counsel Market
                            </h5>
                            <p>UI \ UX Design, Web Designs
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal10" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/auto_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>    
                  </div>
                </div>
                <div class="col-md-3 col-sm-6">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal11"> 
                          <img src="images/portfolio/tab-signerpay.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Signerpay
                            </h5>
                            <p>UI \ UX Design, Web Designs
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal11" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/signerpay_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal12"> 
                          <img src="images/portfolio/tab-yuvika.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Yuvika Fashion
                            </h5>
                            <p> Graphic, web Designs
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal12" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/yuvika_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!--//.-tab1---->  
          <div role="tabpanel" class="tab-pane fade  " id="tab3">
            <div class="tab-content--inner">
              <div class="row no-gutters">
                <div class="col-md-3 col-sm-6 spc-bt-15-md">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal13">
                          <img src="images/portfolio/tab-studio.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>
                              studio thrive
                            </h5>
                            <p>Graphic, Branding, Logo
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal13" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/studio_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>  
                  </div>
                </div>
                <div class="col-md-3 col-sm-6 spc-bt-15-md">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal14"> 
                          <img src="images/portfolio/tab-huge.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Huge Logo Design
                            </h5>
                            <p>UI \ UX Design, Graphic, Branding
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal14" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/huge_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal15"> 
                          <img src="images/portfolio/tab-ecomm.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Ecommerce Invest 
                            </h5>
                            <p>Wordpress
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal15" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/ecomm_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6 spc-bt-15-sm">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal16">
                          <img src="images/portfolio/tab-book.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Book Serve
                            </h5>
                            <p>Graphic, Ilustrator, App Design
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal16" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/book_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>    
                  </div>
                </div>
                <div class="col-md-3 col-sm-6">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal17"> 
                          <img src="images/portfolio/tab-martial.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Martial Craft
                            </h5>
                            <p>Graphic, Branding
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal17" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/martial_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal18"> 
                          <img src="images/portfolio/tab-yuvika.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Yuvika Fashion
                            </h5>
                            <p>App, Graphic, Illustrator
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal18" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/yuvika_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!--//.-tab1----> 
          <div role="tabpanel" class="tab-pane fade  " id="tab4">
            <div class="tab-content--inner">
              <div class="row no-gutters">
                <div class="col-md-3 col-sm-6 spc-bt-15-md">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal19">
                          <img src="images/portfolio/tab-ecoapp.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Ecommerce App
                            </h5>
                            <p>Shopify, Ux Design
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal19" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/ecoapp_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>  
                  </div>
                </div>
                <div class="col-md-3 col-sm-6 spc-bt-15-md">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal20"> 
                          <img src="images/portfolio/tab-com.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Computer Store
                            </h5>
                            <p>Ecommerce, Shopify, Web Design
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal20" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/com_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal21"> 
                          <img src="images/portfolio/tab-ecomm.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Ecommerce Invest 
                            </h5>
                            <p>Wordpress
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal21" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/ecomm_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6 spc-bt-15-sm">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal22">
                          <img src="images/portfolio/tab-alan.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Alan group
                            </h5>
                            <p>Wordpress, UI Design
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal22" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/alangroup_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>    
                  </div>
                </div>
                <div class="col-md-3 col-sm-6 ">
                  <div class="tab-img-inner">
                    <ul>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal23"> 
                          <img src="images/portfolio/tab-dog.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Doggear
                            </h5>
                            <p>Wordpress, UI Design
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal23" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/dog_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                      <li>
                        <a href="javascript:;" data-toggle="modal" data-target="#myModal24"> 
                          <img src="images/portfolio/tab-yuvika.png" alt="">
                          <div class="tab-bottom-box">
                            <h5>Yuvika Fashion
                            </h5>
                            <p>App, Graphic, Illustrator
                            </p>
                          </div>
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="myModal24" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">X
                                  </span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="tab-img-mdl">
                                  <img src="images/portfolio/yuvika_full.png" class="img-responsive">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!--//.-tab1----> 
        </div>
      </div> 
      <!-- / row -->
    </section>
    </div>
  </section> 
<!-- / projects -->
<section class="our-process pad-bt-60 bg-gray-white">
  <div class="container">
    <div class="title">
      <h2>Our 
        <a href="" class="typewrite" data-period="2000" data-type="[  &quot;Process&quot; ]">
          <span class="wrap">Process
          </span>
        </a>
      </h2>
      <span class="sub-head spc-bt-sub-head">A smooth sailing project experience
      </span>
    </div>
    <div class="process-slide-conainer">
      <div class="slide-inner">
        <div class="main-slide-show">
          <div>
            <div class="flex-row"> 
              <div class="slide-imgs">
                <img src="images/servicesimg/meeting.png" alt="">
              </div>
              <div class="process-slide-content">
                <div class="slider-head">
                  <h4>metting &amp; research
                  </h4>
                </div>
                <div class="timeline-container">
                  <div class="timeline-inner orange-circle">
                    <div class="  time-row">
                      <div class="col-xs-6">
                        <div class="header-ttl sd wow slideInLeft">
                          Start Designs
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="header-ttl  clent wow slideInRight">
                          Client
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="circle-1 crcle">
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl f-right wow slideInLeft" data-wow-duration="1s">
                          <span >
                            Understand Requirement
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right wow slideInRight" data-wow-duration="1s">
                          <span>
                            Requirement Brief
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="circle-2 crcle">
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl f-right wow slideInLeft" data-wow-duration="1.8s">
                          <span  >
                            Research & Assessment 
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right wow slideInRight" data-wow-duration="1s">
                          <span>
                            Assessment Feedback
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="circle-3 crcle">
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl f-right wow slideInLeft" data-wow-duration="2.5s">
                          <span >
                            Create Site Map
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right wow slideInRight" data-wow-duration="2.5s">
                          <span>
                            Site Map Review
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="circle-4 crcle">
                      </div>
                      <div class="col-xs-6 ">
                        <div class="time-ttl f-right wow slideInLeft" data-wow-duration="3s">
                          <span  >
                            Proposal
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right wow slideInRight" data-wow-duration="3s">
                          <span>
                            Approval
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                  </div>
                </div>
                <a onclick="document.getElementById('id01').style.display='block'" style="width:auto;" class="getqut">get a quote
                </a>
              </div>
            </div>
          </div>
          <!------>
          <div>
            <div class="flex-row"> 
              <div class="slide-imgs">
                <img src="banner-sd/img/mobile.png" alt="">
              </div>
              <div class="process-slide-content">
                <div class="slider-head">
                  <h4>Design & Develop
                  </h4>
                </div>
                <div class="timeline-container">
                  <div class="timeline-inner orange-circle">
                    <div class="  time-row">
                      <div class="col-xs-6">
                        <div class="header-ttl sd">
                          Start Designs
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="header-ttl  clent">
                          Client
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="circle-1 crcle">
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl f-right">
                          <span>
                            List Required Content
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right">
                          <span>
                            Submission Content & Photos
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="circle-2 crcle">
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl f-right">
                          <span>
                            Homepage Design
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right">
                          <span>
                            Homepage Review and Feedback
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="circle-3 crcle">
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl f-right">
                          <span>
                            Inner Pages Design
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right">
                          <span>
                            Inner Pages Review and Feedback
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="no-lft-arrow crcle">
                      </div>
                      <div class="col-xs-6 ">
                        <div class="time-ttl f-right">
                          <span>
                            Frontend & Backend Coding
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right">
                          <span>
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="no-lft-arrow crcle">
                      </div>
                      <div class="col-xs-6 ">
                        <div class="time-ttl f-right">
                          <span>
                            Content Uploading
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right">
                          <span>
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                  </div>
                </div>
                <a onclick="document.getElementById('id01').style.display='block'" style="width:auto;" class="getqut">get a quote
                </a>
              </div>
            </div>
          </div>
          <div>
            <div class="flex-row"> 
              <div class="slide-imgs">
                <img src="banner-sd/img/testing.png" alt="">
              </div>
              <div class="process-slide-content">
                <div class="slider-head">
                  <h4>QA Testing
                  </h4>
                </div>
                <div class="timeline-container">
                  <div class="timeline-inner orange-circle">
                    <div class="  time-row">
                      <div class="col-xs-6">
                        <div class="header-ttl sd">
                          Start Designs
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="header-ttl  clent">
                          Client
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="circle-1 crcle no-lft-arrow">
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl f-right">
                          <span>
                            Cross Browser & Device Testing
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right">
                          <span>
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="circle-2 crcle no-lft-arrow">
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl f-right">
                          <span>
                            Code Validation Testing
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right">
                          <span>
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="circle-3 crcle">
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl f-right">
                          <span>
                            Review & Testing
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right">
                          <span>
                            Review and Feedback
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="circle-4 crcle">
                      </div>
                      <div class="col-xs-6 ">
                        <div class="time-ttl f-right">
                          <span>
                            Refinement
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right">
                          <span>
                            Final Approval
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                  </div>
                </div>
                <a onclick="document.getElementById('id01').style.display='block'" style="width:auto;" class="getqut">get a quote
                </a>
              </div>
            </div>
          </div>
          <div>
            <div class="flex-row"> 
              <div class="slide-imgs">
                <img src="banner-sd/img/seo.png" alt="">
              </div>
              <div class="process-slide-content">
                <div class="slider-head">
                  <h4> SEO Friendly Updates
                  </h4>
                </div>
                <div class="timeline-container">
                  <div class="timeline-inner orange-circle">
                    <div class="  time-row">
                      <div class="col-xs-6">
                        <div class="header-ttl sd">
                          Start Designs
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="header-ttl  clent">
                          Client
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="  crcle no-lft-arrow">
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl f-right">
                          <span>
                            Webpages Speed Optimizing
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right">
                          <span>
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="circle-2 crcle no-lft-arrow">
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl f-right">
                          <span>
                            Onpage SEO Optimization
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right">
                          <span>
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="circle-3 crcle no-lft-arrow">
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl f-right">
                          <span>
                            Generate Sitemap
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right">
                          <span>
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                  </div>
                </div>
                <a onclick="document.getElementById('id01').style.display='block'" style="width:auto;" class="getqut">get a quote
                </a>
              </div>
            </div>
          </div>
          <div>
            <div class="flex-row"> 
              <div class="slide-imgs">
                <img src="images/servicesimg/rocket.svg" alt="">
              </div>
              <div class="process-slide-content">
                <div class="slider-head">
                  <h4>Launch
                  </h4>
                </div>
                <div class="timeline-container">
                  <div class="timeline-inner orange-circle">
                    <div class="  time-row">
                      <div class="col-xs-6">
                        <div class="header-ttl sd">
                          Start Designs
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="header-ttl  clent">
                          Client
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="circle-1 crcle no-lft-arrow">
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl f-right">
                          <span>
                            Upload on Server
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right">
                          <span>
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="circle-2 crcle no-lft-arrow">
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl f-right">
                          <span>
                            Testing on Live Environment
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right">
                          <span>
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                    <div class="  time-row">
                      <div class="circle-3 crcle no-lft-arrow">
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl f-right">
                          <span>
                            Backend Training
                          </span>
                        </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="time-ttl text-right">
                          <span>
                          </span>
                        </div>
                      </div>
                      <div class="clearfix">
                      </div>
                    </div>
                  </div>
                </div>
                <a onclick="document.getElementById('id01').style.display='block'" style="width:auto;" class="getqut">get a quote
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>  
</section> 

<?php include('footer.php'); ?>